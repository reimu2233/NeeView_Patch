# -*- coding: utf-8 -*-
"""
临时脚本 · 一键生成 NeeView 魔改【两个版本】的编译成品到 E 盘
(供你压缩后发到 GitHub 发行版)

两个版本(默认都生成,可在下方开关里关掉其一):
  A) 需装运行时版(framework-dependent,体积小)—— 运行需用户先装 .NET 10 桌面运行时
  B) 免装运行时版(self-contained,体积大)     —— 自带 .NET 运行时,解压即用、无需安装任何东西

流程:
  1) 全新克隆上游 NeeView + 拉取 4 个子模块,钉到你已同步/测过的 commit(默认 32d892c19)
  2) 用你的 build.py 打全部补丁(出 A 版时顺带 MSBuild 编译;只出 B 版时仅打补丁)
  3) A 版 = build.py 的 MSBuild 成品;B 版 = dotnet publish 自包含
  4) 两个版本都剥 .pdb(调试符号、方便逆向)、删 Profile(防泄露你的密码/历史)
  5) 落到  E:\\NeeView β\\{NeeView1.0-β(NET10)=需装NET10·体积小, NeeView1.0-β=免装运行时·体积大}\\

⚠ 重要:这是【未混淆】成品。.NET(含 WPF)编译后是 IL 字节码,能被 ILSpy/dnSpy 反编译回近似源码。
   要“不易被反编译”,必须在这一步【之后】再用混淆器处理里面的 NeeView.dll(见对话里的说明)。

用法:本文件就放在【魔改包】目录(build.py / patches.py 所在处),命令行运行:
        python 生成发布成品_到E盘.py
环境:Windows + VS2026(MSBuild)+ .NET 10 SDK(dotnet 命令)+ git + 联网(克隆+拉子模块、首次还原 NuGet / 下运行时)。
"""
import os, sys, shutil, subprocess, stat

# ===================== 可改配置 =====================
PIN_COMMIT   = "32d892c19"                         # 钉到这个上游 commit;留空 "" = 用 master 最新
UPSTREAM_URL = "https://github.com/neelabo/NeeView.git"
PARENT_DIR   = r"E:\NeeView β"                     # 成品总目录(两个版本各一子文件夹;会按需清理)
TMP_CLONE    = r"E:\_neeview_build_tmp"            # 临时克隆/编译目录(结束后默认删)
CONFIG       = "Release"
RID          = "win-x64"                           # 自包含版的运行时标识

BUILD_FRAMEWORK_DEPENDENT = True                   # A) 需装运行时版(体积小)
BUILD_SELF_CONTAINED      = True                   # B) 免装运行时版(体积大)

KEEP_TMP     = False                               # True = 保留临时目录(排错用)
STRIP_PDB    = True                                # 剥掉 .pdb 调试符号
# ====================================================

PKG_DIR = os.path.dirname(os.path.abspath(__file__))   # 本脚本所在 = 魔改包目录
OUT_FD  = os.path.join(PARENT_DIR, "NeeView1.0-β(NET10)")   # A) 需装 .NET 10 运行时(framework-dependent,体积小)
OUT_SC  = os.path.join(PARENT_DIR, "NeeView1.0-β")          # B) 免装运行时(self-contained,体积大,解压即用)


def run(cmd, cwd=None):
    # stdin=DEVNULL:子进程读 stdin 立刻 EOF。build.py 结尾的 input("按回车键退出…") 会触发 EOFError,
    # 而它自己 except EOFError: pass → 跑完直接退出、不再卡住等你回车。git/dotnet 不读 stdin、无影响。
    print("\n> " + " ".join(cmd))
    subprocess.run(cmd, check=True, cwd=cwd, stdin=subprocess.DEVNULL)


def force_rmtree(path):
    """删目录,能处理 git 在 Windows 下生成的只读文件(.git\\objects 里的 pack 等)。
    shutil.rmtree 默认删不掉只读文件(PermissionError),ignore_errors 又会静默跳过留下残渣;
    这里在出错时把文件改成可写再重删,保证彻底清掉(否则下次 git clone 报“目录已存在且非空”)。"""
    if not os.path.isdir(path):
        return
    def _onerr(func, p, _exc):
        try:
            os.chmod(p, stat.S_IWRITE)
            func(p)
        except Exception:
            pass
    try:
        shutil.rmtree(path, onexc=_onerr)        # Python 3.12+
    except TypeError:
        shutil.rmtree(path, onerror=_onerr)      # 旧版 Python


def clean_output(path, label):
    """剥 .pdb + 删 Profile(防泄露密码/历史)。"""
    if not os.path.isdir(path):
        return
    n_pdb = 0
    for root, dirs, files in os.walk(path):
        if "Profile" in dirs:
            force_rmtree(os.path.join(root, "Profile"))
            dirs.remove("Profile")
            print(f"[安全] {label}:已删除 Profile(避免泄露密码/历史)")
        if STRIP_PDB:
            for fn in files:
                if fn.lower().endswith(".pdb"):
                    try:
                        os.remove(os.path.join(root, fn)); n_pdb += 1
                    except OSError:
                        pass
    if STRIP_PDB and n_pdb:
        print(f"[清理] {label}:剥掉 {n_pdb} 个 .pdb")


def dir_stats(path):
    files = size = 0
    for r, _, fs in os.walk(path):
        for f in fs:
            files += 1
            try:
                size += os.path.getsize(os.path.join(r, f))
            except OSError:
                pass
    return files, size


def write_readme(path, title, need_runtime):
    if need_runtime:
        note = ("运行前请先安装 .NET 10 桌面运行时(Desktop Runtime x64):\n"
                "  https://dotnet.microsoft.com/download/dotnet/10.0\n"
                "装好后双击 NeeView.exe 即可。\n")
    else:
        note = "已自带运行时,解压后直接双击 NeeView.exe 即可,无需安装任何东西。\n"
    try:
        with open(os.path.join(path, "读我.txt"), "w", encoding="utf-8") as f:
            f.write(f"{title}\n\n{note}\n基于 neelabo/NeeView(MIT 许可)修改。\n")
    except OSError:
        pass


def main():
    if os.name != "nt":
        sys.exit("❌ 必须在 Windows 上运行(需要 MSBuild / dotnet 编译 WPF)。")
    for f in ("build.py", "patches.py"):
        if not os.path.isfile(os.path.join(PKG_DIR, f)):
            sys.exit(f"❌ 同目录找不到 {f}。请把本脚本放进【魔改包】目录"
                     f"(build.py/patches.py 所在处)再运行。\n   当前目录:{PKG_DIR}")
    if not (BUILD_FRAMEWORK_DEPENDENT or BUILD_SELF_CONTAINED):
        sys.exit("❌ 两个版本都关了。把 BUILD_FRAMEWORK_DEPENDENT / BUILD_SELF_CONTAINED 至少开一个。")
    if BUILD_SELF_CONTAINED and not shutil.which("dotnet"):
        sys.exit("❌ 找不到 dotnet 命令(自包含版需要 .NET 10 SDK)。装了 VS2026 通常自带;"
                 "或单独装 SDK:https://dotnet.microsoft.com/download")

    # 1) 全新克隆 + 钉 commit(完整历史克隆,保证能 checkout 指定 commit)
    if os.path.exists(TMP_CLONE):
        print(f"[清理] 删旧临时目录 {TMP_CLONE}")
        force_rmtree(TMP_CLONE)
    run(["git", "clone", UPSTREAM_URL, TMP_CLONE])
    if PIN_COMMIT:
        run(["git", "-C", TMP_CLONE, "checkout", PIN_COMMIT])
    # 拉取子模块:NeeView 用 SevenZipSharp / NeeLaboratory.IO.Search / Vlc.DotNet / AnimatedImage 这 4 个子模块,
    # NeeView.sln 引用了这些子项目。普通 git clone 不含子模块,必须 init+update 到【当前 commit 钉定】的状态,
    # 否则 MSBuild/dotnet 会报 “未找到项目文件 …SevenZip.csproj / …Vlc.DotNet…” 之类。首次需联网下载,稍等。
    print("[子模块] 初始化并拉取 4 个子模块(首次需联网,约几十秒~数分钟)…")
    run(["git", "-C", TMP_CLONE, "submodule", "update", "--init", "--recursive"])
    head = subprocess.check_output(
        ["git", "-C", TMP_CLONE, "rev-parse", "--short", "HEAD"], text=True).strip()
    print(f"[源码] 上游 HEAD = {head}（含子模块）")

    csproj = os.path.join(TMP_CLONE, "NeeView", "NeeView.csproj")

    # 2) A 版:build.py 全流程(reset→打补丁→MSBuild→收集)→ OUT_FD,并把 TMP 留在补丁态;
    #    若不出 A 版,则仅 --patch-only 打补丁(供 B 版 publish 用)
    if BUILD_FRAMEWORK_DEPENDENT:
        if os.path.exists(OUT_FD):
            force_rmtree(OUT_FD)
        run([sys.executable, "build.py", "--src", TMP_CLONE,
             "--out", OUT_FD, "--config", CONFIG], cwd=PKG_DIR)
        clean_output(OUT_FD, "需装运行时版")
        write_readme(OUT_FD, "NeeView 魔改版(需装 .NET 10 运行时 / 体积小)", need_runtime=True)
    else:
        run([sys.executable, "build.py", "--patch-only", "--src", TMP_CLONE], cwd=PKG_DIR)

    # 3) B 版:dotnet publish 自包含 → OUT_SC(TMP 已是补丁态;-r 不再隐含自包含,故显式 SelfContained=true)
    if BUILD_SELF_CONTAINED:
        if os.path.exists(OUT_SC):
            force_rmtree(OUT_SC)
        run(["dotnet", "publish", csproj, "-c", CONFIG, "-r", RID,
             "-p:SelfContained=true", "-o", OUT_SC,
             "-p:DebugType=none", "-p:DebugSymbols=false"])
        clean_output(OUT_SC, "免装运行时版")
        write_readme(OUT_SC, "NeeView 魔改版(免装运行时 / 自带 .NET / 体积大)", need_runtime=False)

    # 4) 收尾
    if not KEEP_TMP:
        print(f"[清理] 删临时目录 {TMP_CLONE}")
        force_rmtree(TMP_CLONE)

    print("\n" + "=" * 62)
    print(f"✅ 完成。总目录:{PARENT_DIR}   (上游 {head} + 全部补丁)")
    if BUILD_FRAMEWORK_DEPENDENT:
        n, s = dir_stats(OUT_FD)
        print(f"   A) 需装运行时版:{OUT_FD}")
        print(f"      {n} 文件 · {s/1024/1024:.1f} MB · 运行前需装 .NET 10 桌面运行时")
    if BUILD_SELF_CONTAINED:
        n, s = dir_stats(OUT_SC)
        print(f"   B) 免装运行时版:{OUT_SC}")
        print(f"      {n} 文件 · {s/1024/1024:.1f} MB · 解压即用")
    print("   ⚠ 两个都是【未混淆】版,仍可被反编译——发布前请先混淆里面的 NeeView.dll(见对话说明)。")
    print("=" * 62)


if __name__ == "__main__":
    main()
