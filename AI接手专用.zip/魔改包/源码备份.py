#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
NeeView 源码备份脚本(去魔改化 → 复制到 E 盘)
==============================================
把 D:\\000\\NeeView 的源码导出一份【干净原版】副本到 E 盘,供你压缩上传网盘。

它做什么:
  · 复制一份【完整原版源码 + git 版本管理】到 E 盘,工作区还原为干净原版 → 不含你的魔改改动。
  · 自动【不含】编译产物(bin/obj/_build_out)和 Profile。
  · 主仓库 + 4 个子模块都带上,得到一份和 GitHub clone 等效、可直接编译、可继续版本管理的源码树。
  · 因为带 git,以后对它可直接用 build.py --reset 反复魔改/改补丁/重编,与 D:\\000\\NeeView 用法一致。

它【不动】什么:
  · 你的 D:\\000\\NeeView 原封不动(魔改、Profile、编译产物都保留)。本脚本只读源码目录。

用法(默认有 Python;命令行运行):
    python 源码备份.py                       # 默认带 git,导出到 E:\\NeeView源码备份_日期
    python 源码备份.py --src D:\\000\\NeeView --out E:\\NeeView源码备份
    python 源码备份.py --no-git              # 不带 .git(纯源码、体积更小;但对它不能用 build.py --reset)

完成后:E 盘出现一个干净原版源码文件夹(自带 git)。你自己右键压缩成 zip 上传网盘即可。
之后在任意设备:解压 → 放入 build.py + patches.py → python build.py --reset → 一键最新魔改版。
"""

import os
import sys
import shutil
import argparse
import subprocess
import datetime

# ---- 彩色(与 build.py 一致;Win10/11 自动开 VT)----
def _vt():
    if os.name == "nt":
        try:
            import ctypes; k = ctypes.windll.kernel32
            k.SetConsoleMode(k.GetStdHandle(-11), 7)
        except Exception:
            pass
_vt()
RESET="\033[0m"; B="\033[1m"; DIM="\033[2m"; G="\033[92m"; R="\033[91m"; Y="\033[93m"; C="\033[96m"
def col(t,c="",b=False): p=(B if b else "")+c; return f"{p}{t}{RESET}" if p else t
def log(m): print(m, flush=True)

DEFAULT_SRC = r"D:\000\NeeView"


def run(cmd, cwd=None, check=True):
    return subprocess.run(cmd, cwd=cwd, check=check, capture_output=True, text=True)


def is_git_repo(path):
    r = subprocess.run(["git", "-C", path, "rev-parse", "--is-inside-work-tree"],
                       capture_output=True, text=True)
    return r.returncode == 0


def _ignore_build_artifacts(dirpath, names):
    """copytree 的忽略规则:跳过编译产物和 Profile(其余都复制,含 .git)。"""
    skip = set()
    base = os.path.basename(dirpath)
    for n in names:
        full = os.path.join(dirpath, n)
        if os.path.isdir(full):
            if n in ("bin", "obj", "_build_out", "Profile", ".vs"):
                skip.add(n)
    return skip


def export_with_git(src, out):
    """带 git:复制整个工作树(含 .git、子模块,排除编译产物),再在副本里 git 还原成干净原版。"""
    log(col("[1/3] 复制完整源码树(含 git,排除编译产物)...", C, True))
    head = run(["git", "-C", src, "rev-parse", "--short", "HEAD"]).stdout.strip()
    log(f"      基准 commit: {head}")
    shutil.copytree(src, out, ignore=_ignore_build_artifacts, dirs_exist_ok=True)
    log(f"      {col('[OK]', G)} 已复制(含 .git / 子模块,不含 bin/obj/_build_out/Profile)")

    # 在副本里把工作区还原成原版(撤销魔改改动)。主仓库 + 子模块递归。
    log(col("[2/3] 在副本里还原为干净原版(撤销魔改)...", C, True))
    if not is_git_repo(out):
        log(f"      {col('[注意]', Y)} 副本不是 git 仓库,跳过还原(应不会发生)")
        return
    run(["git", "-C", out, "checkout", "--", "."], check=False)
    run(["git", "-C", out, "submodule", "foreach", "--recursive", "git checkout -- ."], check=False)
    # 清掉可能残留的未跟踪魔改文件(本项目魔改全是改已有文件,这步通常无操作;-d 不删 .git)
    run(["git", "-C", out, "clean", "-fdq", "-e", ".git"], check=False)
    log(f"      {col('[OK]', G)} 工作区已还原为原版(魔改改动已撤销)")

    log(col("[3/3] 完成(副本自带 git,可直接 build.py --reset)", C, True))


def export_archive_only(src, out):
    """不带 git(--no-git):用 git archive 仅导出源码内容(主仓库 + 子模块),无版本管理。"""
    import tarfile, io
    log(col("[1/3] 导出主仓库原版源码(--no-git)...", C, True))
    head = run(["git", "-C", src, "rev-parse", "--short", "HEAD"]).stdout.strip()
    log(f"      基准 commit: {head}")
    os.makedirs(out, exist_ok=True)
    archive = subprocess.run(["git", "-C", src, "archive", "--format=tar", "HEAD"],
                             stdout=subprocess.PIPE, check=True)
    with tarfile.open(fileobj=io.BytesIO(archive.stdout)) as tar:
        tar.extractall(out)
    log(f"      {col('[OK]', G)} 主仓库源码已导出")

    log(col("[2/3] 导出子模块源码...", C, True))
    sm = run(["git", "-C", src, "submodule", "status"], check=False).stdout.strip()
    if not sm:
        log(f"      {col('[注意]', Y)} 没检测到子模块状态。若副本无法编译,请确认原仓库子模块已初始化。")
    for line in sm.splitlines():
        parts = line.strip().split()
        if len(parts) < 2:
            continue
        sub_path = parts[1]
        sub_full = os.path.join(src, sub_path.replace("/", os.sep))
        dst_full = os.path.join(out, sub_path.replace("/", os.sep))
        if not is_git_repo(sub_full):
            log(f"      {col('[跳过]', Y)} {sub_path}(未初始化?)")
            continue
        os.makedirs(dst_full, exist_ok=True)
        a = subprocess.run(["git", "-C", sub_full, "archive", "--format=tar", "HEAD"],
                          stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        if a.returncode != 0 or not a.stdout:
            log(f"      {col('[跳过]', Y)} {sub_path}(子模块未初始化或为空;"
                f"如需可编译副本,请先在原仓库执行 git submodule update --init --recursive)")
            continue
        try:
            with tarfile.open(fileobj=io.BytesIO(a.stdout)) as tar:
                tar.extractall(dst_full)
            log(f"      {col('[OK]', G)} 子模块 {sub_path}")
        except tarfile.TarError:
            log(f"      {col('[跳过]', Y)} {sub_path}(导出内容异常,已跳过)")
    log(col("[3/3] 完成(纯源码,无 git;对它请用 build.py 不加 --reset)", C, True))


def main():
    ap = argparse.ArgumentParser(description="NeeView 源码去魔改化备份到 E 盘")
    ap.add_argument("--src", default=DEFAULT_SRC, help=f"源码目录(默认 {DEFAULT_SRC})")
    ap.add_argument("--out", default=None, help="输出目录(默认 E:\\NeeView源码备份_日期)")
    ap.add_argument("--no-git", action="store_true", help="不带 .git(纯源码、更小;但对它不能用 build.py --reset)")
    args = ap.parse_args()

    src = os.path.abspath(args.src)
    if args.out:
        out = os.path.abspath(args.out)
    else:
        stamp = datetime.datetime.now().strftime("%Y%m%d")
        out = os.path.join("E:\\", f"NeeView源码备份_{stamp}")

    log(col("=" * 60, C))
    log(f"源码(只读,不会修改): {src}")
    log(f"导出到              : {out}")
    log(col("=" * 60, C))

    # 前置检查
    if not os.path.isdir(src):
        raise FileNotFoundError(f"源码目录不存在:{src}(用 --src 指定)")
    if not is_git_repo(src):
        raise RuntimeError(f"{src} 不是 git 仓库,无法用本脚本去魔改化导出。\n"
                           f"  (本脚本靠 git 还原原版;若不是 git 仓库请手动处理。)")
    out_drive = os.path.splitdrive(out)[0]
    if out_drive and not os.path.isdir(out_drive + "\\"):
        raise FileNotFoundError(f"目标盘 {out_drive} 不存在,请确认 E 盘可用,或用 --out 指定其它位置。")

    # 若目标已存在,先清空(避免新旧混杂)
    if os.path.isdir(out):
        log(col(f"[清理] 目标已存在,先删除旧的:{out}", Y))
        shutil.rmtree(out)

    if args.no_git:
        export_archive_only(src, out)
    else:
        export_with_git(src, out)

    # 统计体积
    total = 0
    for root, _, files in os.walk(out):
        for f in files:
            try: total += os.path.getsize(os.path.join(root, f))
            except OSError: pass
    mb = total / 1024 / 1024

    log(col("=" * 60, G))
    log(col("✅ 完成!干净原版源码已导出。", G, True))
    log(col(f"   位置: {out}", G))
    log(col(f"   体积: {mb:.1f} MB", G))
    log("   说明:这份是【去魔改的原版源码】,不含你的魔改/编译产物/Profile。")
    log("   下一步:右键该文件夹 →“压缩为 zip”→ 上传网盘即可。")
    log("   你的 D:\\000\\NeeView 原封未动(魔改和设置都还在)。")
    log(col("=" * 60, G))


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print(col("\n已取消。", Y))
    except Exception as e:
        print(); print(col("=" * 60, R))
        print(col("❌ 出错了:", R, True)); print(col(f"   {e}", R))
        print(col("=" * 60, R))
        print("(把上面的报错发给 AI 可帮你诊断)")
    finally:
        if os.name == "nt":
            try: input("\n按回车键退出…")
            except EOFError: pass
