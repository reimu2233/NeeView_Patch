#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
NeeView 魔改 · 一键打补丁 + 编译【引擎】
========================================
★ 这个文件是固定的"引擎",一般不用改。
   所有补丁定义都在同目录的 patches.py 里;加新功能只改 patches.py,
   不要动本文件,也不要新建别的脚本 —— 引擎永远只有 build.py 这一个。

做三件事:
  1) 把 patches.py 里的补丁打进源码(可重复执行;已打过的自动跳过)
  2) 调用 Visual Studio 的 MSBuild 编译(仅 Windows)
  3) 把编译出来的成品拷到输出目录

用法(在装了 VS2026 的 Windows 上):
    python build.py                       # 平时:自动还原+打补丁+编译(git仓库会自动还原,不联网,最快)
    python build.py --pull                # 想更新作者新版时:先 git pull 拉上游,再打补丁编译(git pull 需联网)
    python build.py --src D:\\000\\NeeView  # 指定源码目录
    python build.py --out D:\\APP\\NeeView_mod   # 指定成品输出目录
    python build.py --patch-only          # 只打补丁不编译(接手AI在非Windows上复现源码用)
    python build.py --config Debug        # 编译配置(默认 Release)
    python build.py --no-reset            # 跳过自动还原(仅当你手动改过源码、想保留时;一般用不到)

· 自动还原:源码是 git 仓库时,每次会先把补丁涉及的文件 checkout 回原版,再整体重打,保证
  "干净原版 + 当前补丁",不会越叠越乱,也无需再手动加 --reset。非 git 的纯源码目录会自动跳过还原。
· 更新源码且保持魔改:python build.py --pull(自动 还原→pull→打补丁→编译)。魔改存在 patches.py 里,
  源码每次被还原成干净基线,所以 pull 永远顺畅、魔改也不会丢。
· 全程彩色输出:成功=绿色,跳过=黄色,出错=红色。
· 运行结束或出错都会暂停等回车,不会一闪而过(双击运行也看得到结果)。
· 重新编译时会自动【保留旧输出目录里的 Profile】(你的密码/历史/设置不会被重建清掉)。
· 收集成品前,若输出目录的 NeeView 正在运行,会【自动强制结束它】(NeeView 有托盘常驻行为,
  优雅关闭常无效,故直接强制结束),避免 Cache.db 被占用导致收集失败;
  只针对输出目录那个 exe,不会误杀别处的 NeeView。
"""

import os
import sys
import glob
import shutil
import argparse
import subprocess
import tempfile
import atexit

# 不生成 __pycache__/*.pyc 缓存(导入 patches.py 时 Python 默认会写;关掉保持目录干净)
sys.dont_write_bytecode = True


# ===== 彩色输出(Windows 10/11 自动开启 VT 终端;无第三方依赖)=====
def _enable_win_vt():
    if os.name == "nt":
        try:
            import ctypes
            k = ctypes.windll.kernel32
            k.SetConsoleMode(k.GetStdHandle(-11), 7)  # ENABLE_VIRTUAL_TERMINAL_PROCESSING
        except Exception:
            pass


_enable_win_vt()

RESET = "\033[0m"; BOLD = "\033[1m"; DIM = "\033[2m"
GREEN = "\033[92m"; RED = "\033[91m"; YELLOW = "\033[93m"; CYAN = "\033[96m"


def c(text, color="", bold=False):
    """给文字加颜色。"""
    pre = (BOLD if bold else "") + color
    return f"{pre}{text}{RESET}" if pre else text


def log(msg):
    print(msg, flush=True)


# ===== 单实例锁:禁止两个 build.py 同时运行 =====
# 机制:在临时目录放一个锁文件,内含当前进程 PID。启动时检查:
#   锁文件存在 且 里面的 PID 仍在运行 → 已有实例,提示并退出;
#   否则(无锁/锁是死进程留下的残锁)→ 写入自己 PID,占用锁,退出时自动删除。
_LOCK_PATH = os.path.join(tempfile.gettempdir(), "neeview_build_py.lock")


def _pid_alive(pid):
    """判断 PID 对应的进程是否还活着。"""
    try:
        if os.name == "nt":
            import ctypes
            PROCESS_QUERY_LIMITED_INFORMATION = 0x1000
            STILL_ACTIVE = 259
            k = ctypes.windll.kernel32
            h = k.OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, False, int(pid))
            if not h:
                return False
            code = ctypes.c_ulong()
            ok = k.GetExitCodeProcess(h, ctypes.byref(code))
            k.CloseHandle(h)
            return bool(ok) and code.value == STILL_ACTIVE
        else:
            os.kill(int(pid), 0)
            return True
    except Exception:
        return False


def acquire_single_instance_lock():
    """获取单实例锁。已有实例在跑则返回 False(应退出);成功占用返回 True。"""
    # 已存在锁文件:看里面的 PID 是否仍在运行
    if os.path.exists(_LOCK_PATH):
        try:
            with open(_LOCK_PATH, "r", encoding="utf-8") as f:
                old_pid = f.read().strip()
            if old_pid and old_pid.isdigit() and _pid_alive(old_pid):
                return False  # 真的有另一个实例在跑
        except Exception:
            pass  # 读不出来就当残锁,继续覆盖
        # 残锁(进程已死):忽略,下面覆盖
    # 占用锁:写入自己的 PID,注册退出时删除
    try:
        with open(_LOCK_PATH, "w", encoding="utf-8") as f:
            f.write(str(os.getpid()))
        atexit.register(_release_single_instance_lock)
    except Exception:
        pass  # 锁文件写不了也不阻断正常运行
    return True


def _release_single_instance_lock():
    """退出时删除自己的锁文件(只删属于自己的)。"""
    try:
        if os.path.exists(_LOCK_PATH):
            with open(_LOCK_PATH, "r", encoding="utf-8") as f:
                pid = f.read().strip()
            if pid == str(os.getpid()):
                os.remove(_LOCK_PATH)
    except Exception:
        pass


# 载入补丁数据(同目录的 patches.py)
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
try:
    from patches import PATCHES
    import patches as _patches_module   # [新] 供 OBSOLETE_FILES 等可选顶层变量取用(老 patches.py 没有也兼容)
except ImportError:
    sys.exit(c("错误:同目录下找不到 patches.py(补丁数据)。请确保 build.py 和 patches.py 放在一起。", RED, True))

DEFAULT_SRC = r"D:\000\NeeView"   # 源码根目录(改成你本地的路径,或用 --src)


# ===== 改动概览(基建增强:每次运行都把 patches.py 的真实内容摆出来,防止改了代码忘更 MD)=====
# 原理:PATCHES 的 dict 本身不带"魔改编号",编号写在 patches.py 的注释标题里
#   (两种格式:  # ---- 0Xy. ... ----   和   #  魔改 NN: ...)。
#   这里解析 patches.py 源文件的注释,把每条补丁按出现顺序归到最近的标题,统计每个魔改改了哪些文件。
# 这是【确定性】的:只如实打印 patches.py 的事实,不做对错判断;打印结果若与 MD 对不上 = 改了代码忘更 MD。
# 【铁律】此函数任何异常都不得中断编译:整段在 main 里用 try/except 兜住,出错只静默跳过概览。
import re as _re


def _group_patches_by_mod():
    """解析 patches.py 注释,返回 (OrderedDict{mod: [(file, mode), ...]}, total_files)。
    解析失败时抛异常,由调用方兜住。"""
    from collections import OrderedDict
    here = os.path.dirname(os.path.abspath(__file__))
    with open(os.path.join(here, "patches.py"), encoding="utf-8") as f:
        lines = f.read().split("\n")

    # 收集注释标题行号 → 魔改编号
    labels = []  # (line_idx, modnum)
    for i, ln in enumerate(lines):
        s = ln.strip()
        m_big = _re.match(r"#\s+魔改\s*(\d+)\s*[:：]", s)
        m_small = _re.match(r"#\s*-+\s*(.+?)\s*-+\s*$", s)
        if m_big:
            labels.append((i, m_big.group(1)))
        elif m_small:
            mm = _re.match(r"(\d+)", m_small.group(1))
            if mm:
                labels.append((i, mm.group(1)))

    # 每条补丁的 "file": 行号
    file_idxs = [i for i, ln in enumerate(lines) if _re.match(r"\s*[\"']file[\"']\s*:", ln)]
    if len(file_idxs) != len(PATCHES):
        raise ValueError(f"解析到 {len(file_idxs)} 个 file 行,与 PATCHES({len(PATCHES)}) 不符")

    def nearest(idx):
        best = "?"
        for li, mod in labels:
            if li < idx:
                best = mod
            else:
                break
        return best

    groups = OrderedDict()
    all_files = set()
    for p, fidx in zip(PATCHES, file_idxs):
        mod = nearest(fidx)
        rel = p["file"].replace("\\", "/")
        short = rel[len("NeeView/"):] if rel.startswith("NeeView/") else rel
        all_files.add(short)
        groups.setdefault(mod, []).append((short, p["mode"]))
    return groups, len(all_files)


def print_change_overview():
    """打印『改动概览』:每个魔改几条补丁、碰了哪些文件。每次运行都打,用来对照 MD 核对。"""
    groups, total_files = _group_patches_by_mod()
    log("")
    log(c("[改动概览] 本次 patches.py 实际改了什么(请对照《补丁清单》MD §1/§4 核对是否一致):", CYAN, True))
    for mod in sorted(groups, key=lambda x: (len(x), x)):
        items = groups[mod]
        files = sorted(set(f for f, _ in items))
        has_create = any(m == "create" for _, m in items)
        tag = c(" [含新建文件]", DIM) if has_create else ""
        label = f"魔改{mod}" if mod != "?" else c("未归类(无注释标题!)", RED)
        log(f"  {c(label, BOLD)}  {c(str(len(items)) + '条', GREEN)}{tag}")
        log(c(f"        {', '.join(files)}", DIM))
    log(c(f"  ── 合计 {len(PATCHES)} 条补丁 · {total_files} 个文件", CYAN))
    log(c("  ⚠️  若某魔改这里显示的文件/条数与 MD 记载对不上 → 多半是改了代码忘更 MD,请补 MD 后再发布(见 §6 铁律)。", YELLOW))
    log("")


def apply_patches(src):
    """打补丁。可重复执行:已打过的跳过;锚点找不到则报错。返回 (applied, skipped)。
    mode:
      replace = 把 anchor 替换成 text(文件须存在)
      append  = 把 text 追加到文件末尾(文件须存在)
      create  = 新建文件,内容为 text(文件须【不】存在;已存在则视为已打过而跳过)
    """
    applied = skipped = 0
    for p in PATCHES:
        if p.get("enabled", True) is False:
            log(f"  {c('[停用]', DIM)} {p['file']}  {c('(enabled=False,跳过;其 create 文件会在还原时清除)', DIM)}")
            continue
        rel = p["file"].replace("\\", os.sep)   # Windows 反斜杠 → 当前平台分隔符
        path = os.path.join(src, rel)
        mode = p["mode"]

        # create 模式:新建文件。文件已存在 = 已打过,跳过;不存在则创建。
        if mode == "create":
            if os.path.isfile(path):
                log(f"  {c('[跳过]', YELLOW)} {p['file']}  {c('(文件已存在)', DIM)}")
                skipped += 1
                continue
            os.makedirs(os.path.dirname(path), exist_ok=True)
            with open(path, "w", encoding="utf-8") as f:
                f.write(p["text"])
            log(f"  {c('[新建]', GREEN)} {p['file']}")
            applied += 1
            continue

        # replace / append:文件必须存在
        if not os.path.isfile(path):
            raise FileNotFoundError(f"找不到要改的文件:{path}\n  → 源码目录(--src)是否正确?是否完整 clone(含子模块)?")

        with open(path, "r", encoding="utf-8") as f:
            content = f.read()

        if p["marker"] in content:
            log(f"  {c('[跳过]', YELLOW)} {p['file']}  {c('(已打过补丁)', DIM)}")
            skipped += 1
            continue

        if mode == "replace":
            if p["anchor"] not in content:
                raise RuntimeError(
                    f"[锚点失配] {p['file']}\n"
                    f"  找不到下面这段原文(可能上游改写了这里):\n"
                    f"  ----\n{p['anchor']}\n  ----\n"
                    f"  → 请打开《魔改补丁清单》§4 看该处的机制说明,手工把逻辑放到新位置。"
                )
            new_content = content.replace(p["anchor"], p["text"], 1)

        elif mode == "append":
            tail = content if content.endswith("\n") else content + "\n"
            new_content = tail + p["text"]

        else:
            raise ValueError(f"未知 mode: {mode}")

        with open(path, "w", encoding="utf-8") as f:
            f.write(new_content)
        log(f"  {c('[已打]', GREEN)} {p['file']}")
        applied += 1

    return applied, skipped


def is_git_repo(path):
    r = subprocess.run(["git", "-C", path, "rev-parse", "--is-inside-work-tree"],
                       capture_output=True, text=True)
    return r.returncode == 0


def reset_files(src):
    """把补丁涉及的文件还原到原版。
    · replace/append 的文件:git checkout 回原版。
    · create 的新文件:直接删除(它们不在 git 里;删掉让下次能重新创建)。
    保证源码始终是"原版 + 当前补丁",不会越叠越乱。只动补丁涉及的文件。"""
    if not is_git_repo(src):
        raise RuntimeError(f"{src} 不是 git 仓库,无法还原。请手动还原文件,或重新 clone 源码。")

    # 分类:被任何 create 补丁创建的文件 = 新增文件(删除);其余被 replace/append 改的 = 改动文件(git checkout)。
    # 注意:同一文件可能既有 create 又有 replace 补丁(先创建再改),这种归为"新增文件",删除即可,不能 git checkout(git 里没有它)。
    create_files = sorted(set(p["file"].replace("\\", os.sep) for p in PATCHES if p["mode"] == "create"))
    create_set = set(create_files)
    edit_files = sorted(set(
        p["file"].replace("\\", os.sep) for p in PATCHES
        if p["mode"] != "create" and p["file"].replace("\\", os.sep) not in create_set
    ))

    log(c("[reset] 把补丁涉及的文件还原到原版...", CYAN, True))
    if edit_files:
        subprocess.run(["git", "-C", src, "checkout", "--"] + edit_files, check=True)
        for f in edit_files:
            log(f"  {c('[还原]', CYAN)} {f}")
    # 删除 create 新增的文件(不在 git 中,git checkout 不管它们)
    for f in create_files:
        fp = os.path.join(src, f)
        if os.path.isfile(fp):
            os.remove(fp)
            log(f"  {c('[删除]', CYAN)} {f}  {c('(新增文件,还原即删除)', DIM)}")
    # [新] 废弃文件清单:历史上 create 过、后来从 PATCHES 移除的文件,记在 patches.OBSOLETE_FILES 里,
    #      还原时一并删除——这样"删掉一个 create 补丁"也能让旧机器上的残留文件被自动清干净,零手工。
    #      (replace/append 类补丁删条目则无需任何登记:还原本来就把原文件 checkout 回原版。)
    obsolete = [f.replace("\\", os.sep) for f in getattr(_patches_module, "OBSOLETE_FILES", [])]
    for f in sorted(set(obsolete)):
        fp = os.path.join(src, f)
        if os.path.isfile(fp):
            os.remove(fp)
            log(f"  {c('[清除]', CYAN)} {f}  {c('(OBSOLETE_FILES 废弃文件)', DIM)}")
    # [新] 废弃改动清单:历史上被 replace/append 补丁改过、现已没有任何补丁涉及的文件。
    #      还原阶段把它们 git checkout 回原版——这样"删掉一个 replace/append 补丁"后,
    #      旧机器上该文件里的历史改动也会被自动撤干净(同 OBSOLETE_FILES 之于 create)。
    obsolete_edits = sorted(set(
        f.replace("\\", os.sep) for f in getattr(_patches_module, "OBSOLETE_EDITS", [])
        if f.replace("\\", os.sep) not in create_set
    ))
    obsolete_edits = [f for f in obsolete_edits if os.path.isfile(os.path.join(src, f))]
    if obsolete_edits:
        subprocess.run(["git", "-C", src, "checkout", "--"] + obsolete_edits, check=True)
        for f in obsolete_edits:
            log(f"  {c('[还原]', CYAN)} {f}  {c('(OBSOLETE_EDITS 废弃改动,checkout 回原版)', DIM)}")


def find_msbuild():
    """用 vswhere 找 VS 自带的 MSBuild.exe。"""
    pf86 = os.environ.get("ProgramFiles(x86)", r"C:\Program Files (x86)")
    vswhere = os.path.join(pf86, "Microsoft Visual Studio", "Installer", "vswhere.exe")
    if not os.path.isfile(vswhere):
        raise FileNotFoundError(
            "找不到 vswhere.exe,说明 Visual Studio 可能没装好。\n"
            f"  期望位置:{vswhere}\n"
            "  请确认已安装 VS2026 +「.NET 桌面开发」+「使用 C++ 的桌面开发」工作负载。"
        )
    out = subprocess.check_output([
        vswhere, "-latest", "-prerelease", "-products", "*",
        "-requires", "Microsoft.Component.MSBuild",
        "-find", r"MSBuild\**\Bin\MSBuild.exe",
    ], text=True).strip()
    msbuild = out.splitlines()[0].strip() if out else ""
    if not msbuild or not os.path.isfile(msbuild):
        raise FileNotFoundError("vswhere 没找到 MSBuild.exe,请确认 VS 安装了 MSBuild 组件。")
    return msbuild


def build(src, config):
    """调 MSBuild 还原 + 编译。"""
    sln = os.path.join(src, "NeeView.sln")
    if not os.path.isfile(sln):
        raise FileNotFoundError(f"找不到解决方案:{sln}")
    msbuild = find_msbuild()
    log(f"  MSBuild: {msbuild}")
    log(f"  配置: {config} / x64  (首次编译会还原 NuGet 包;已缓存则直接编译)")
    cmd = [msbuild, sln, "/restore", "/m",
           f"/p:Configuration={config}", "/p:Platform=x64",
           "/v:minimal", "/nologo"]
    try:
        subprocess.run(cmd, check=True)
    except subprocess.CalledProcessError:
        # 编译/还原失败时才提示:多半是首次还原 NuGet 但连不上网,或需要代理才能访问 nuget.org
        log("")
        log("  [提示] 编译失败。若是首次编译且卡在 NuGet 还原,通常是网络问题:")
        log("         · 确认能访问 nuget.org(首次需联网下载依赖包,之后用本地缓存不再需要)")
        log("         · 若你的网络需要代理才能上网,请先开启代理再重试")
        log("         · 若依赖已缓存过,则与网络无关,请看上面 MSBuild 的具体报错")
        raise


def close_running_neeview(out):
    """编译收集前,若 out 目录里的 NeeView.exe 正在运行,先关掉它(否则 Cache.db 等被占用,收集会失败)。
    只针对 out 目录下的那个 exe(按完整路径匹配),绝不误杀系统里别处的 NeeView。
    策略:直接强制结束(/F)→ 等进程退出 + 句柄释放。仅 Windows 生效。"""
    if os.name != "nt":
        return
    exe_path = os.path.join(os.path.abspath(out), "NeeView.exe")
    if not os.path.isfile(exe_path):
        return  # 还没有输出目录/exe,首次编译,无需关闭

    import time
    # 用 tasklist 找所有 NeeView.exe 进程的 PID + 可执行路径,只挑路径等于 out\NeeView.exe 的
    def running_pids():
        try:
            # /FO CSV /NH:CSV无表头;tasklist 不直接给路径,用 wmic/PowerShell 拿路径更稳
            r = subprocess.run(
                ["powershell", "-NoProfile", "-Command",
                 "Get-CimInstance Win32_Process -Filter \"name='NeeView.exe'\" | "
                 "ForEach-Object { \"$($_.ProcessId)|$($_.ExecutablePath)\" }"],
                capture_output=True, text=True, timeout=15)
            pids = []
            for line in r.stdout.splitlines():
                line = line.strip()
                if "|" not in line:
                    continue
                pid, _, path = line.partition("|")
                pid = pid.strip(); path = path.strip()
                if path and os.path.normcase(os.path.abspath(path)) == os.path.normcase(exe_path):
                    if pid.isdigit():
                        pids.append(pid)
            return pids
        except Exception:
            return []

    pids = running_pids()
    if not pids:
        return  # 没在运行,直接继续

    log(c(f"[关闭] 检测到 NeeView 正在运行(PID {', '.join(pids)}),强制结束它…", YELLOW, True))
    # 直接强制结束(NeeView 有托盘常驻行为,优雅关闭常无效且白等;故直接 /F)
    for pid in pids:
        subprocess.run(["taskkill", "/PID", pid, "/F"], capture_output=True, text=True)
    # 等进程退出 + 文件句柄释放(最多 ~5 秒)
    for _ in range(10):
        time.sleep(0.5)
        if not running_pids():
            log(c("[关闭] 已结束 NeeView 进程。", GREEN))
            time.sleep(0.5)  # 多等半秒让 Cache.db 等句柄彻底释放
            return
    log(c("[关闭] 警告:NeeView 进程可能仍在,若收集失败请手动关闭后重试。", RED))


def collect(src, config, out):
    """找到编译出的 NeeView.exe 所在文件夹,整个拷到 out。"""
    # 先关掉正在运行的(out 目录的)NeeView,否则 Profile\Cache.db 等被占用会导致收集失败
    close_running_neeview(out)

    pattern = os.path.join(src, "NeeView", "bin", "**", "NeeView.exe")
    hits = [h for h in glob.glob(pattern, recursive=True)
            if config.lower() in h.lower() and "x64" in h.lower()]
    if not hits:  # 放宽:只要找到 NeeView.exe
        hits = glob.glob(pattern, recursive=True)
    if not hits:
        raise FileNotFoundError(f"编译完成但没找到 NeeView.exe,检查路径:{pattern}")
    exe = max(hits, key=os.path.getmtime)   # 取最新修改的那个
    build_dir = os.path.dirname(exe)

    # [Profile 保留] 若旧输出目录里有 Profile(你的密码/历史/设置),先临时移出,重建后再放回
    # 暂存目录放在 out 的【外面】(同级),否则会被下面 rmtree(out) 一起删掉
    saved_profile = None
    old_profile = os.path.join(out, "Profile")
    if os.path.isdir(old_profile):
        saved_profile = os.path.join(os.path.dirname(os.path.abspath(out)),
                                     "_neeview_profile_keep_tmp")
        if os.path.isdir(saved_profile):
            shutil.rmtree(saved_profile)
        shutil.move(old_profile, saved_profile)
        log(f"  {c('[保留]', CYAN)} 暂存旧 Profile(密码/历史/设置)")

    if os.path.isdir(out):
        shutil.rmtree(out)
    shutil.copytree(build_dir, out)
    log(f"  成品目录: {build_dir}")
    log(f"  已拷到  : {out}")

    # 还原 Profile:把暂存的旧 Profile 放回新输出目录(覆盖新编出来的空 Profile)
    if saved_profile:
        new_profile = os.path.join(out, "Profile")
        if os.path.isdir(new_profile):
            shutil.rmtree(new_profile)
        shutil.move(saved_profile, new_profile)
        log(f"  {c('[保留]', CYAN)} 已还原旧 Profile,设置/密码不丢")

    return out


def main():
    ap = argparse.ArgumentParser(description="NeeView 魔改一键打补丁+编译(引擎;补丁数据在 patches.py)")
    ap.add_argument("--src", default=DEFAULT_SRC, help=f"源码根目录 (默认 {DEFAULT_SRC})")
    ap.add_argument("--out", default=None, help="成品输出目录 (默认 <src>\\_build_out)")
    ap.add_argument("--config", default="Release", help="编译配置 Release/Debug (默认 Release)")
    ap.add_argument("--patch-only", action="store_true", help="只打补丁,不编译")
    ap.add_argument("--pull", action="store_true", help="想更新作者新版时加这个:先 git pull 拉上游再打补丁")
    ap.add_argument("--no-reset", action="store_true", help="跳过自动还原(仅当你手动改过源码、想保留时才用;一般不需要)")
    args = ap.parse_args()

    # 单实例:禁止两个 build.py 同时跑(避免同时改源码/编译互相打架)
    if not acquire_single_instance_lock():
        log(c("=" * 60, YELLOW))
        log(c("⚠️ 已经有一个 build.py 正在运行了!", YELLOW, True))
        log(c("   请等它跑完,或关掉那个窗口后再启动。", YELLOW))
        log(c("   (若确认没有其他实例还在跑,可能是上次异常退出残留;", DIM))
        log(c("    手动删除这个文件即可:" + _LOCK_PATH + ")", DIM))
        log(c("=" * 60, YELLOW))
        return

    src = os.path.abspath(args.src)
    out = args.out or os.path.join(src, "_build_out")

    log(c("=" * 60, CYAN))
    log(f"源码目录: {src}")
    log(f"补丁条目: {len(PATCHES)} 条 (来自 patches.py)")
    log(c("=" * 60, CYAN))

    # 改动概览:每次运行都打印 patches.py 真实内容,供对照 MD 核对(防止改代码忘更 MD)。
    # 铁律:概览出错绝不影响编译 —— 任何异常都吞掉、只静默跳过。
    try:
        print_change_overview()
    except Exception as _e:
        log(c(f"[提示] 改动概览生成失败(不影响编译,可忽略):{_e}", YELLOW))

    # 自动还原:补丁涉及的文件 git checkout 回原版,保证"干净原版 + 当前补丁",不会越叠越乱。
    # 仅当源码是 git 仓库时还原(纯源码备份等非 git 目录本就干净,自动跳过);--no-reset 可强制跳过。
    do_reset = (not args.no_reset) and is_git_repo(src)

    if args.pull:
        # 更新作者新版:必须先还原成干净(否则 git pull 会因工作区有魔改改动而冲突),再 pull
        if do_reset:
            reset_files(src)
        log(c("[git] 拉取上游更新 (git pull)...", CYAN, True))
        subprocess.run(["git", "-C", src, "pull"], check=True)
        log(c("[1/3] 打补丁", CYAN, True))
        a, s = apply_patches(src)
    else:
        if do_reset:
            reset_files(src)
        elif not args.no_reset and not is_git_repo(src):
            log(c("[提示] 源码不是 git 仓库,跳过还原(干净源码无需还原)。", YELLOW))
        log(c("[1/3] 打补丁", CYAN, True))
        a, s = apply_patches(src)
    log(f"      → 新打 {c(str(a), GREEN)} 处,跳过 {c(str(s), YELLOW)} 处")

    if args.patch_only:
        log(c("[完成] 仅打补丁模式,未编译。", GREEN, True))
        return

    if os.name != "nt":
        log(c("[2/3] 跳过编译:当前不是 Windows。补丁已打好,请到 Windows + VS2026 上编译。", YELLOW))
        return

    log(c("[2/3] 编译 (MSBuild)", CYAN, True))
    build(src, args.config)

    log(c("[3/3] 收集成品", CYAN, True))
    dest = collect(src, args.config, out)

    log(c("=" * 60, GREEN))
    log(c("✅ 全部成功!", GREEN, True))
    log(c(f"   带魔改的 NeeView 在: {dest}", GREEN))
    log("   提示:首次运行会在 exe 旁生成 Profile;若要沿用旧设置,把旧 Profile 拷过去即可。")
    log(c("=" * 60, GREEN))


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print(c("\n已取消。", YELLOW))
    except Exception as e:
        print()
        print(c("=" * 60, RED))
        print(c("❌ 出错了:", RED, True))
        print(c(f"   {e}", RED))
        print(c("=" * 60, RED))
        print("(把上面的完整输出 / 报错发给 AI,可帮你诊断)")
    finally:
        # 不闪退:运行结束或出错都暂停,等用户看完再关(仅 Windows;双击运行也看得到结果)
        if os.name == "nt":
            try:
                input("\n按回车键退出…")
            except EOFError:
                pass
