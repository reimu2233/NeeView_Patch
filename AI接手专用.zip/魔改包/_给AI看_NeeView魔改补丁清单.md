# NeeView 魔改 · 补丁与接手清单

> **这份文档给"下一个接手的 AI"看。** 它记录的是 **"在原版源码上改了什么"**。
> 这份文档**自包含**接手所需的一切:项目是什么、技术栈与魔改分层(§3)、基准 commit(§2)、已经改了什么(§1/§4)、怎么编译与怎么判断上游更新(§5/§6)。开工只读这一份即可,不依赖任何外部文档。

**状态图例**:🔧 待实现 ／ 🚧 已实现待 Windows 实测 ／ ✅ 已实现并实测可用、随 `build.py` 发布

---

## 0. 为什么需要这份文档(接手前先懂这一件事)

用户本地的源码 = **原版上游源码 + 下面登记的若干补丁**。

如果你(接手的 AI)直接从 GitHub 拉源码,拿到的是**干净的原版**,会和用户本地的**改版**对不上。**本文档就是这道桥**:它告诉你改了哪几处、基于哪个版本、怎么一步步复现用户的状态。**别靠猜、别拿整个项目去比对——读这里。**

---

## 1. 当前魔改状态一览

> ✅ **历史/统计/已读完口径已统一(2026-06-06 实现并 worktree 验证零失配)**:① 历史只记「**F11 全屏下打开的单文件**」(mod18);② **统计(mod17)已过滤文件夹**(打开文件夹浏览不计时长/不进排行);③ 已读完(mod16)随历史已只剩单文件。补丁仍 110 条(均为改现有补丁内容、未新增条目)。详见 §4 魔改 17 / 18。✅ **已 Windows 编译实测通过(2026-06-06 用户确认)**。

| # | 功能 | 状态 | 改动文件 | 应用方式 |
|---|------|------|----------|----------|
| 01 | 压缩包**密码池**:打开加密包时先静默逐个试用户保存的密码,全失败才弹手动输入框;设置里编辑、明文保存、支持含空格/超长 | ✅ 已实现 | `ArchiveConfig.cs` / `ArchiveKey.cs` / `SettingPageFileTypes.cs` / `SettingItemCollectionControl.xaml.cs` / `en.restext` / `zh-Hans.restext` | `build.py` |
| 02 | 封面**预生成**:打开文件夹时一次性给全部项排缩略图任务(不只可见项),已缓存的秒铺满。设置里开关控制,默认开。**【2026-06-08 修复】可见项优先排队 + 滚动时重新置顶**(原先按列表顺序一次性排、不重排,导致大文件夹里屏幕上的封面要等前面几百个处理完才出;现在屏幕封面立即出、其余后台预生成)。配合 04-N 池容量提升,大文件夹封面不再频繁变灰 | ✅ 已实现并实测可用(02-live 2026-06-09 实测通过) | `ThumbnailConfig.cs` / `ListBoxThumbnailLoader.cs` / `SettingPageGeneral.cs` / `en.restext` / `zh-Hans.restext` | `build.py` |
| 03 | **加密 ZIP 自动转 7-Zip**:标准 ZIP 开着时,加密的 zip 自动改走 7-Zip 打开(密码池生效),普通 zip 仍走标准解压保持原生速度 | ✅ 已实现 | `ArchiveManager.cs` | `build.py` |
| 04 | **默认预设(合集)**:文件操作默认开 / 默认字体(Comic Sans MS·130%·菜单115%) / 性能(JobWorker12·缓存1024MB·预读10) / SQLite WAL / 恢复书架位置默认开 / 顶栏面板自动隐藏延迟0秒 / 书架内容样式(图标原样·120·名称换行) / 补译「系统托盘常驻」 / 缩略图分辨率512·质量90 / 视频作为书籍打开默认关 / 补译书架右键缩略图子菜单(04-K) / 补译清缓存对话框(04-L) / 默认关闭已读绿勾(04-M) / **书架缩略图内存池容量200→2000(04-N,大文件夹封面常驻不变灰)** | ✅ 已实现并实测可用(04-N 2026-06-09 实测通过) | `SystemConfig.cs` / `FontsConfig.cs` / `PerformanceConfig.cs` / `Database.cs` / `StartUpConfig.cs` / `AutoHideConfig.cs` / `PanelListItemProfile.cs` / `zh-Hans.restext` / `ThumbnailConfig.cs` / `MediaArchiveConfig.cs` | `build.py` |
| 05 | **清理缓存按钮显示体积 + 全部删除后自动重启**:①设置→常规→缩略图 的"清理缩略图缓存"按钮标题显示当前缓存大小,如「清理缩略图缓存(当前为 320.5 MB)」(静态快照,打开设置页时读取);②上游已把清缓存重写为「全部删除/清理无效项/取消」三选一对话框,本魔改让「全部删除」成功后自动保存设置并重启 NeeView 重建缓存、「清理无效项」不重启(05c);对话框/结果消息的中文补译见 04-L | ✅ 已实现 | `SettingPageGeneral.cs` | `build.py` |
| 06 | **手动隐藏**:右键漫画文件/文件夹 →「隐藏」→ 从书架移除(硬盘文件不动);按完整路径标识、持久化、重启仍隐藏;设置→面板→书架 里有「编辑」按钮开独立窗口管理隐藏项(06-k) | ✅ 已实现 | `BookshelfConfig.cs` / `BookshelfExcludeFilter.cs` / `FolderListBox.xaml.cs` / `SettingPagePanels.cs` / `_Mod/HiddenPathsEditWindow.cs` / `zh-Hans.restext` / `en.restext` | `build.py` |
| 07 | **书架右键菜单完整编辑器**:设置→面板→书架→「右键菜单」可视化编辑普通文件/文件夹的右键菜单,TreeView拖拽排序/分组,增删项/分隔/分组/重命名/恢复默认;A类静态项自由编排,B类动态项(带▸)可显隐不可入组 | ✅ 已实现 | `BookshelfConfig.cs` / `FolderListBox.xaml.cs` / `SettingPagePanels.cs` / `SettingItem.cs` / `_Mod/*.cs` / `Setting/BookshelfMenuEditControl.xaml(.cs)` / `*.restext` | `build.py`(create mode) |
| 08 | **完整版预缓存(递归封面)**:书架右键文件夹→「预缓存封面(含子文件夹)」,递归遍历所有压缩包/PDF 逐个真实生成封面存入 Cache.db;自定义进度窗口(可隐藏成右下角可拖拽浮条、跨重启记住位置);预缓存期间静默试密码池、不弹框(防打断批量)。详见 §4。 | ✅ 已实现 | `_Mod/BookshelfPrecacheRunner.cs` / `_Mod/PrecacheProgressWindow.cs` / `FolderListBox.xaml.cs` / `_Mod/BookshelfMenuCommandTable.cs` / `SystemConfig.cs` / `*.restext` | `build.py`(create mode + reset修复) |
| 09 | **老板键(全局热键版)**:Alt+X一键切换隐藏/恢复。用系统级RegisterHotKey全局热键(隐藏在后台也能用同键叫回,NeeView命令体系快捷键做不到这点)。含修复AppState.ShowWindow恢复bug(IsHideWindow态优先ResumeAsync)。**焦点 bug**:隐藏期间在外部按键(如回车)后再Alt+X恢复,滚轮/Esc/F11需手点窗口才接管;前4次(强抢前台/延迟重试/FocusOnLoaded/多重抢前台)均未果;2026-06-05 内置诊断日志拿到真实数据,**推翻"前台"假设**(`fg/active` 全程为真)→ **真正根因=HWND 没拿到 Win32 键盘焦点**(WPF Hide/Show 坑;键/滚轮都投给"焦点窗口"非"前台窗口")。attempt5 补 **`SetFocus(hwnd)`**(触发 WM_SETFOCUS 让 WPF 接管)修好了"按回车"case,但外部牢占前台(点链接跳转)的 case 还坏;**attempt6 = 强抢前台(attempt4 那套)+ `SetFocus`,两半都补**,2026-06-05 用户编译实测通过、bug 已修复(诊断日志已关)。详见§4。固定Alt+X(键不可改);**2026-06-22 加专用设置页「老板键」**(启用开关=动态注册/注销热键 + 禁止恢复=Alt+X 只藏不还原·经托盘恢复,归入「其他」可折叠分类;详见 §2 当日条) | ✅ 已实现并实测可用;**新设置页待编译实测** | `_Mod/BossKeyHotKey.cs` / `_Mod/BossKeySettingPage.cs` / `_Mod/SettingPageOther.cs` / `Config/SystemConfig.cs` / `Setting/SettingWindowModel.cs` / `NativeMethods.txt` / `MainWindow.xaml.cs` / `System/AppState.cs` | `build.py`(create mode) |
| 10 | **加密包封面修复**:ArchivePageThumbnail生成缩略图时Decrypt=false→true,加密包(配合密码池)也能生成/显示封面(原本是空图);只改缩略图路径不动正文 | ✅ 已实现 | `Page/ArchivePageThumbnail.cs` | `build.py` |
| 11 | **设置窗口里按 F11 切全屏**:设置窗口是独立 Window,原本吞掉 F11(主窗口全屏命令收不到);在其 KeyDown 加 F11→调主窗口全屏切换 | ✅ 已实现 | `Setting/SettingWindow.xaml.cs` | `build.py` |
| 12 | **全屏时 Esc 退出全屏(等价 F11)**:主窗口处于全屏(F11)状态时,按 Esc 等价于按 F11——退出全屏;非全屏时 Esc 行为不变(仍取消待处理项)。硬编码行为,不走快捷键系统、不依赖 Profile,编译后立即生效。只改主窗口,浮动主视图窗口的 Esc=关窗保持原样 | ✅ 已实现 | `MainWindow/MainWindow.xaml.cs` | `build.py` |
| 13 | **书架阅读进度百分比(自包含)**:书架文件名后显示 `(95%)`。NeeView 历史只存当前页名、不存页码/总数,故在 `Book.CreateMemento()` 把当前页序号+总页数记进自己的 `ReadProgress.json`(放 History.json 同目录,**不碰** NeeView 历史)。只记**点开读过**的书;**停在第一页/未读不显示**;1–99% 淡灰(同日期行)、**100% 绿色**;显示在 Normal/Content 两视图文件名后。实时刷新挂翻页事件(`Book_CurrentPageChanged`→`RecordLive`+刷新);Banner/Thumbnail 视图暂未加。**【13b 续读位置解耦 2026-06-07】窗口模式(非 F11)拖进度条/翻页后退出,重启能恢复到该页**——续读位置不再受 mod18「历史只记 F11 全屏」闸门影响,但历史列表那套(mod18)一个字不动(详见 §4 mod13 末)。 | ✅ 百分比/实时刷新实测可用;**13b 已实测**;**【13c v2 路径无关:进度存储改身份(文件名+大小)主键,移动文件后 %/续读自动认得;✅ 2026-06-07 实测通过,详见 §4 mod13 末】** | `_Mod/ReadProgressStore.cs`(新建·v2 身份主键) / `Book/Book.cs` / `FolderItem.cs` / `FolderListBox.xaml` / `BookMementoControl.cs`(翻页hook #91 + 13b 记页名) / `BookHub.cs`(13b 开书覆盖恢复页) | `build.py`(create+replace) |
| 14 | **文件大小单位智能显示**:书架等处文件大小从写死 KB 改为智能单位——≥1GB 用 GB(2位小数)、≥1MB 用 MB(1位小数,如 214.6 MB)、更小仍 KB(避免 `0 MB`)。改 `FileSizeToStringConverter.ByteToDisplayString`(全局:书架/页列表/文件卡/导出预览都生效) | ✅ 已实测正常 | `Converters/FileSizeToStringConverter.cs` | `build.py` |
| 15 | **隐藏右上角 Dev/版本水印 + 标题去版本号**:① Dev/Alpha/Beta 包会在菜单栏右上角显示版本水印(`Dev` 徽标);把 `MenuBarView.xaml.cs` 里 `Watermark.Visibility = Environment.Watermark ? Visible : Collapsed` 改成恒 `Collapsed`,水印永不显示。② **窗口标题(没开书时)** `WindowTitle.cs` 的 `_defaultWindowTitle = $"{ApplicationName} {DisplayVersion}"` 改成 `string.Empty` → 没开书时标题**留空**(连「NeeView」也不显示;开书时标题用可配置格式、显示书名) | ✅ 已实现(水印随 13~16 批次编译;标题去版本号 2026-06-09 新增、✅ 2026-06-19 用户实测通过) | `MenuBar/MenuBarView.xaml.cs` / `MainWindow/WindowTitle.cs` | `build.py` |
| 16 | **「已读完」侧边面板**:左栏历史图标(绿勾)下面新增面板,**外观仿历史**——顶部「数量 + 「…」菜单」+ 列表(封面缩略图+日期+书名)。**Ctrl/Shift 多选**,双击/回车打开,**右键「标记为未读」**(对所有选中项)移出 + 把续读页归零(下次从第一页开),仅本面板、不进设置。「…」菜单(复用 `MoreMenuButton`,**复刻历史那一整套**):视图样式(列表/内容/横幅/缩略图)、排序(按读完时间/按最后打开时间 × 倒序/正序,二级)、显示项目数量、显示搜索框(按名过滤)、删除无效项/清空已读完。判定用**黏性「读完过」**(翻到过末页就永久算读完,翻回 99% 不掉,与书架实时%分开);存储加「读完时刻」供排序。实现:列表=历史项里被标读完的(`BookHistoryCollection.Items` 按 `GetFinishedPaths()` 过滤),缩略图复用 `PanelListContentImage`+`ListBoxThumbnailLoader`(视图实现 `IPageListPanel`),行模板 `XamlReader.Parse` 运行时套(不新增 XAML 编译单元),「…」图标取自 `MoreButtonIcons.xaml`。注册:`_defaultDocs` 左栏+`SidePanelFactory` 各一处;`Restore()` 会补进已有 Profile | ✅ 已实现并实测可用(面板/缩略图/四视图样式/排序二级菜单/搜索/删除等全套;2026-06-06 用户编译实测)**【v2 2026-06-07:面板改身份驱动脱离历史、扛文件移动,封面复用 mod17;2a✅。2b 设置里加「自定义扫描」页(进度条 + 扫描找回 + 同步 NeeView 历史路径)修复打开路径,✅ 2026-06-08 实测通过。详见 §4 mod16 末】** | `_Mod/ReadFinishedPanel.cs`(新建) / `_Mod/ReadFinishedView.cs`(新建,头部+排序) / `ReadProgressStore.cs`(黏性+读完时刻+ClearFinished) / `SidePanelFactory.cs` / `CustomLayoutPanelManager.cs` | `build.py`(create+replace) |
| 17 | **阅读统计侧边面板**:左栏「已读完」**上方**新增「统计」面板(顺序 历史→统计→已读完),折线图图标。仿阅读 APP:日/周/月/年/总 + 总时长 + 在读/读完 + 柱状图 + 阅读时长排行(只显示去后缀文件名)。**计时**:只在【F11 全屏 且 未被老板键隐藏 且 有书】时计;**新书 1 分钟冷静期**(从没记录过的书要连续全屏满 60 秒才转正、这 60 秒一起计入,中途退全屏/切书/隐藏则清零重来);转正后**永久免冷静期**(写盘,重启仍记得,以后看 5 秒记 5 秒);累计满 **3 分钟**才真正显示;统一 5 秒采样、冷静期内只内存计数不写盘。**同一本书** = 去后缀书名+页数+大小差≤5MB(zip/rar 视为一本)。**读完** = 进度条翻到末页。时长 时+分、**截断不四舍五入**、超 24h 仍用「小时」、不足 1 分钟显「0 分钟」。「…」可导出/导入(替换)/清空,存自包含 `ReadingStats.json`(History.json 同目录,**不碰** NeeView 数据)。**【v2 升级】**① 挂机暂停:停在一页超过 1 分钟没翻页就停表、翻页恢复;② 阅读时长排行升级为多样式(列表/内容/缩略图)+ 进度条背景(列表内容横向·缩略图竖向从下到上·淡蓝;进度取自 mod13)+ 双击/回车打开原书、原书不存在弹 NeeView 通知框(Toast);③「…」改用原生 `MoreMenuButton`(修全屏下点「…」左栏消失的 bug)。**【17-fix 2026-06-06】排行缩略图改为「历史里有就用历史的、没有就按路径自造临时 Page」,不再因 mod18 收紧历史而显空白(详见 §4 mod17 末)。**【17-cover 2026-06-06】排行封面随统计数据持久化(`BookStat.Cover` base64):浏览面板时自动抓存,导出/导入自动带图片,删原文件/清缓存后仍显示。**【17-live 2026-06-07】排行那条淡蓝进度条改为实时跟随翻页**(翻页即更新当前书那行 `ProgressRatio`,复用 mod13 的 #91 钩子,不必重开面板;详见 §4 mod17 末)。**** | ✅ 核心实测可用(不卡死/能进界面/缩略图/三样式/进度条/点击打开/Toast/**已过滤文件夹**),淡蓝进度条已实测实时跟随翻页(17-live-2);新书1分钟冷静期/累计5分钟门槛仍长期观察 | `_Mod/ReadingStatsStore.cs`(新建) / `_Mod/StatisticsPanel.cs`(新建) / `_Mod/StatisticsView.cs`(新建) / `SidePanelFactory.cs` / `CustomLayoutPanelManager.cs` / `MainWindow.xaml.cs` / `BookMementoControl.cs` / `SettingWindowModel.cs` | `build.py`(create+replace) |
| 18 | **历史记录只记单个文件**:NeeView 原生历史会把打开过的「文件夹/盘符/系列目录」(如 `E:\`、`APP`、`[系列][Vol.01-Vol.26]` 这种目录)也当「书」记进历史,与真正在读的单本压缩包混在一起。本魔改在历史登记总闸门 `BookMementoControl.CanHistory(book)` 判定链末尾加 `&& !System.IO.Directory.Exists(book.Path)`——**路径是目录就不记、且仅 F11 全屏阅读时打开的单文件才记**(全屏判断 = mod17 第236行同款 `MainWindow.Current?.WindowStateManager?.IsFullScreen`);两个写入点共用 CanHistory 故一处生效。**连带(2026-06-09 修正)**:原以为「已读完」(mod16)从历史筛、会随历史只剩单文件;实测「已读完」是从 mod13 `ReadProgressStore`(每翻页就记、不分全屏、不排除文件夹)取数 → 文件夹型书读到 100% 会漏进面板。已在 `ReadFinishedView.UpdateList` 加 `.Where(路径不是目录)` 排除文件夹(详见 §4「18-2」)。**只管之后新打开的**(旧历史不动);UNC/压缩包内项另有 NeeView 开关、不冲突。副作用 = 打开文件夹浏览不再进历史(预期行为)。**统计(mod17)也已过滤文件夹**(随本次一起做,见 §4)。 | ✅ 已实测可用(2026-06-06 用户 Windows 编译实测通过) | `BookMementoControl.cs`(mod13/17 之外第三次碰它,replace 1 条) | `build.py`(replace) |
| 19 | **海报墙(v4 定型)= 书架第五种样式**:书架「···」菜单 → 列表/内容/横幅/缩略图/**海报墙样式**;地址栏(分段可点+换盘)/搜索/排序/F11/窗口按钮/右键/双击/拖拽全为**作者原生**(v1~v3 覆盖层的贴靠布局误命中、设置窗打不开、F11 失灵整类问题随方案消失)。瓦片=深底圆角整图(Uniform/Fant)+悬停白框与渐变书名+作者 FolderListIcon 角标+右下徽章(**直接绑 mod13 的 ReadProgressText/IsReadFinished**,%/绿✓ 即时刷新);`VirtualizingWrapPanel` 同管线虚拟化(吃 mod02 可见优先+04-N 池);**Ctrl+滚轮 140~400 即时缩放**(存 `SystemConfig.PosterWallTileWidth`);设置→面板 默认样式下拉自动含之;旧 v1~v3 覆盖层三文件壳化清场 | 🚧 v5.7 待实测(2026-06-11;v5.6 墙闪✅消除;v5.7=Root 显形帧抢先全屏,Normal 黑框零帧化;剩余:书装载期全屏深底一瞬属耗时非闪框) | `PanelListItemStyle.cs` / `PanelsConfig.cs` / `SystemConfig.cs`(×2) / `FolderListViewModel.cs` / `FolderListBox.xaml`(资源+双渲染触发) / `FolderListBox.xaml.cs`(滚轮+宿主标志DP) / `FolderListBoxViewModel.cs`(×3) / `FolderList.cs` / `FolderListBoxInsertDropAssist.cs` / `MainWindow.xaml.cs`(挂接+F11/Esc/焦点自愈) / `_Mod/PosterWallCenterHost.cs`(中央宿主) / zh+en restext｜另:`_Mod/BossKeyHotKey.cs`(mod05,承载 F11 焦点修复与闪屏抑制)｜退役:旧覆盖层 `_Mod/PosterWall*.cs`×3→OBSOLETE_FILES、撑满 `SidePanelFrameView.xaml.cs`→OBSOLETE_EDITS | `build.py`(create+replace+append) |
| 20 | **预缓存原图封面(每本书独立·高清/小图隔离)**:书架右键第 2 行(「预缓存封面」之下)。与 mod08「预缓存封面」**同目标**(右键文件夹→递归缓存内含 zip/pdf 等压缩包漫画封面),「原图封面」生成 **2048 高清**(2026-06-18 六续起:源图不足 2048 也插值放大撑满 2048²,详见 §2/§4 末「六续」;512 档与普通浏览仍不放大、避免小图放糊)、「预缓存封面」生成 **512 小图**,且**每本书各自独立、可同屏并存**(对 B 跑原图、对 C 跑小图 → B 高清 C 小图并存、互不影响)。**实现(核心=绕开 NeeView 全局分辨率限制)**:新建 `_Mod/HiResCoverStore.cs` 维护 `path→分辨率` 持久映射(`HiResCovers.json`,放 History.json 同目录);**封面缓存键 ghash 与生成尺寸都改为按本书路径取分辨率**——① `Thumbnail` 构造按 `entry.TargetPath` 查 `HiResCoverStore.GetResolution()` 算 ghash(普通书=全局默认→ghash 与原版一致、**旧缓存不失效**;高清书=2048 自成一套缓存键);② 生成尺寸 `ThumbnailProfile.GetThumbnailSize` 改读 `HiResCoverStore.OverrideResolution`(AsyncLocal);③ `PageThumbnail.LoadAsync`(全部缩略图生成的**唯一总闸**)生成前把本书 `Thumbnail.Resolution` 设进该 AsyncLocal(随 await/Task.Run 流动、并发各自独立)、`finally` 还原;④ `ThumbnailConfig.GetThumbnailImageGenerateHash` 加 `(int resolution)` 重载。两命令共用运行器 `BookshelfPrecacheRunner.Run(path, resolution)`(默认512/原图2048):收集压缩包后先 `HiResCoverStore.SetResolution(files, resolution)` 标记、再 `IsCacheReadEnabled=false` 强制重生成。**不动全局 `ImageWidth`**。代价:2048 约 512 的 16 倍面积,Cache.db 涨(只涨被标高清的)。原生改分辨率不自动重载已显示封面 → 跑完进/重进文件夹才见新封面,其它文件夹完全不受影响。确认框=作者 MessageDialog。菜单只在文件夹显示。 | ✅ 2026-06-19 用户实测通过(每本书 2048高清/512小图 隔离;含六续『源图不足2048也放大撑满2048』) | **新建** `_Mod/HiResCoverStore.cs` / **改核心** `Thumbnail/Thumbnail.cs`(构造算 ghash+存 Resolution)、`Config/ThumbnailConfig.cs`(ghash 重载)、`Thumbnail/ThumbnailProfile.cs`(生成尺寸)、`Page/PageThumbnail.cs`(总闸设分辨率) / `_Mod/BookshelfPrecacheRunner.cs`(改造 mod08 运行器:标记+强制覆盖) / `FolderListBox.xaml.cs`(命令声明+绑定+确认处理+菜单case,×4) / `_Mod/BookshelfMenuCommandTable.cs` / `_Mod/BookshelfMenuDefault.cs` / `Config/BookshelfConfig.cs`(旧菜单配置自动补 PrecacheFolder 项) / zh+en restext | `build.py`(create+replace+append) |
| 21 | **双页模式末页页码显示**:双页(跨页)模式下页码显示当前**跨页的尾页**号(最后一个跨页 → 显示总页数),纯显示、不碰翻页导航。改 `TitleStringFormatter.GetPageWord`(标题/页码格式)、`PageSelector` 加 `SelectedIndexMax`、`PageSlider` 改 `SelectedIndexRaw` getter | ✅ 2026-06-19 用户实测通过 | `MainWindow/TitleStringFormatter.cs` / `PageSelect/PageSelector.cs` / `PageSelect/PageSlider/PageSlider.cs` | `build.py`(replace) |
| hd-db<br>(概览=魔改22) | **高清封面库 + 单 .db 备份导入导出 + 已读完/统计封面都抓(含 17b)**:在 mod16/17 基础上加 `_Mod/ReadingBackup.cs`——`StatCoverDb`(高清封面 SQLite 库 `ReadingCovers.db`)+ `ReadingBackup`(单 `.db` 备份编排,导出文件名带当天日期 `NeeView阅读备份_yyyy-MM-dd.db`);统计与已读完面板都把「文件还在、源够大」的书封面按 ≤2048 存进库,扛文件移动/删除。**17b**:抓取覆盖统计+已读完两面板、直存键 `CoverKey(名,大小)`;**门槛 640→256**(默认分辨率≈512 的封面也备份、仅挡 160px 兜底),修复「已读完 14 本只导出 7 张」。**注:`build.py` 概览把这条显示为「魔改22(1条)」。** | ✅ 2026-06-15 用户 Windows 实编实测通过(14 本封面全导出 / 导出名带日期 / 移动·删文件后已读完封面仍高清) | **新建** `_Mod/ReadingBackup.cs` / 就地改 `_Mod/StatisticsView.cs`、`_Mod/ReadingStatsStore.cs`(mod17)、`_Mod/ReadFinishedView.cs`(mod16) | `build.py`(create+replace) |
| 23 | **WebDAV / Alist 流式阅读 zip/cbz**:让 NeeView 经 Alist(挂 115 网盘)**流式**打开 115 上的 zip/cbz 漫画——不下整包即可出封面/逐页翻(HTTP Range;已实测 Alist `/d` 链接 302→115 CDN 返回 206 + Accept-Ranges)。原理:NeeView 的 ZipArchive 底层 = .NET `System.IO.Compression.ZipArchive`,只绑死 `FileStream(Path)` / `ZipFile.Open(Path)` 两处,换成远程 Range 流即真流式(只取尾部中央目录 + 所看页)。~~pdf 本期不流式~~ **PDF 已流式(2026-06-17):初版用 PdfiumViewer `PdfDocument.Load` 但其 Load 时 eager 读所有页尺寸→扫描版整本下载,已改为直接 P/Invoke `pdfium.dll`(`FPDF_GetPageCount`+逐页 `FPDF_GetPageSizeByIndex`+按需 `FPDF_RenderPageBitmap`,读块回调挂 `RemoteRangeStream`)→ 封面只读第0页、翻到哪读到哪,真·部分流式。见 §2 最新¹²。****分阶段**:A 引擎(`RemoteRangeStream` + `WebDavClient`/`WebDavRangeFetcher`)→ B 接线(`NvDavZipArchive` + 3 路由补丁 + 路径放行 + 粘 URL 打开,首个可测)→ C 书架浏览+封面+设置 UI → D 打磨+PDF。详见 §4 魔改23。 | 🚧/✅(部分) **【2026-06-19 实测分界】✅ 已通过**:Stage A 引擎、Stage B 接线(zip 流式打开)、Stage C 书架挂载/浏览/设置页/根下拉挂载/测试连接、C2 离线缓存、C3 持久内容缓存(离线阅读)、Issue A/B/C 三连、原图统一2048(本地+dav)·封面分档·清缓存复位2048、流式 PDF(P/Invoke pdfium)、dav 文件夹清除缓存、NvDavDirFolderItem(文件夹自定义封面显示)、方案A、dav 自定义封面三连、文件夹「自定义封面」、设置页 UI 精简/重构、**按挂载独立右键菜单**、六续(预缓存放大2048·清缓存关书+清子文件夹·落盘q95;**裁剪色斑用户反馈仍有问题→待澄清**)。 **🚧 仍待测**:dav 三连(格式白名单/dav书进度·已读完·统计/清缓存归零续读)、**流式 RAR/CBR**、**加密 RAR+ZIP 流式**、**dav 八连其余项**(dav 重命名 Alist→115 MOVE·文件夹自动封面·预缓存增量防风控·内容缓存「确定」·隐藏「重置」)、修 dav 预缓存风控误判。〔注:按挂载独立右键菜单已通过→其底座 Feature3「dav 独立右键菜单」实际亦生效;Feature1「文件夹自动封面」与已通过的 NvDavDirFolderItem 共用渲染路径,但「取夹内首书首封」行为本身待单独确认。〕 ——以下为原始交付记录—— **Stage A 引擎已编译通过(2026-06-16)**;Stage B/C 已交付。**Stage C2 离线缓存(目录结构+封面持久缓存,每挂载隔离、抗 115 风控空文件夹)+ Stage C3 内容缓存(看过的页块持久落盘、每挂载独立上限默认5GB+LRU、Alist 离线可翻看过的页)已交付**。沙箱侧:补丁 **186/0 双基准零失配**、文件生成、括号配平、anchor+API 对真实源码逐一核实。**【2026-06-18 dav 三连·计数不变仍 201】**:① 格式白名单(只显示/路由用户指定后缀,缺省 zip,cbz,pdf,设置页「格式」框失焦即存)→ 从源头不给打不开的 rar/7z 取 115 直链、降风控;② dav 书现能记**进度% / 进「已读完」/ 计入阅读统计**(身份用服务器字节 `LoadCachedLength`,已读完+统计封面补了 `DavThumb` 回退);③ 清缓存连带**归零续读位置**(重开从第 1 页,保留进度%/已读完/统计)+ 清缓存右键菜单也支持 **dav 单本书**。沙箱双基准 201/0、9 文件配平、详见 §4 魔改23 末「dav 三连」。**【2026-06-18 续 · 流式 RAR/CBR(SharpCompress)201→203】**:dav 远程 RAR/CBR 现可流式(store/非固实;固实会被明确拒绝)。新增 `_Mod/NvDavRarArchive.cs`(SharpCompress `RarArchive` 开在 `RemoteRangeStream` 上)+ `NeeView.csproj` 加 `SharpCompress 0.48.1`(首个 NuGet 依赖)+ ArchiveManager 分流 `.rar/.cbr`→RarArchive。**代价**:RAR 无尾部目录→每次开/列表/出封面要走一遍文件头(首开约数十 MB,首开后 C3 块缓存兜住),故 **rar/cbr 不进白名单缺省、需「格式」框手动加 `rar,cbr`**。只用 `OpenEntryStream`(规避 zip-slip CVE)。沙箱双基准 203/0、详见 §4 魔改23 末「流式 RAR」。**【2026-06-18 再续 · 加密 RAR + 加密 ZIP 流式,计数不变仍 203】**:dav 加密压缩包也能流式——复用 mod01 密码池(保存密码→缓存→弹框)。之前都不支持(.NET ZipArchive 不能解密、rar 没传密码)。ZIP 零回归 hybrid(明文仍 .NET、仅加密切 SharpCompress、探测失败回退);RAR 数据/头加密都覆盖、固实仍拒。验证用一次性档、拿到密码重开干净档(避 #230);只 OpenEntryStream(避 CVE)。⚠ rar 错误密码检测不可靠(catch 广泛、弱口令池自动试可能不稳、手动框兜底)。只改两个 create 文件内容、不增条,详见 §4 魔改23 末「加密 RAR/ZIP」 **【2026-06-18 本会话 dav 八连,总数 203→220】**:dav 重命名(右键→重命名 = WebDAV MOVE 改 Alist/115 真实名,魔改23 +5;挂载根除外、412=同名已存在)+ dav **独立右键菜单**(魔改23 +12:dav 项走一套独立可配置菜单、WebDAV 设置加【右键菜单】按钮编辑、普通菜单「添加」清单移除「清除缓存」、过长标题精简为「右键菜单」)+ Feature1 dav 文件夹自动封面(取夹内首书首封)+ bug2 预缓存改增量逐个防 115 风控 + Check1 内容缓存小窗「确定」才生效/「清除封面」连带清自动封面 + Check2 隐藏本页无效「重置」按钮;沙箱双基准(`4dbe593eb` / `764fea1a7`)各 220/0;详见 §2 最新「dav 体验八连」与 §4 魔改23 末 | **已交付** Stage A `_Mod/RemoteRangeStream.cs`/`_Mod/WebDavClient.cs` + Stage B `_Mod/NvDavZipArchive.cs` + `ArchiveType.cs`/`ArchiveManager.cs`(×3)/`ArchiveEntryUtility.cs`/`QueryPath.cs`(×2)/`Archive.cs`;**Stage C 已交付** `_Mod/NvDavMountStore.cs`/`WebDavFolderCollection.cs`/`SettingPageWebDav.cs` + `FolderCollectionFactory.cs`/`FolderEntryCollection.cs`/`ArchiveEntryUtility.cs`/`SettingWindowModel.cs`;**Stage D:PDF 流式已交付(2026-06-17,`_Mod/NvDavPdfiumArchive.cs` + ArchiveManager 路由按 .pdf 分流)**;待加 书架自动刷新 + HttpClient 复用 | `build.py`(create+replace) |
| 24 | **自定义封面(右键文件夹/单本书)**:右键「自定义封面」→ 弹窗;若是书→直接铺开所有页缩略图、选一张;若是文件夹→逐级下钻(双击子文件夹/书)直到进入一本漫画→铺开其所有页→选一张设为该文件夹封面。被右键项在书架显示选中图。**复用既有封面体系**:仅新增选图弹窗,写入调 `FolderConfigTools.SetThumbnailTarget`(存 `FolderConfig.Thumbs`)、渲染 `ArchivePageUtility.SelectAlternativeEntry` 自动读取(文件夹与书都生效);仿 mod20 加菜单命令。详见 §4 魔改24。 | ✅ **2026-06-19 用户实测通过**(基础下钻选页/dav 裁剪/容器全分辨率/选择器四连均 OK)。原:已交付+二轮完善(套原生暗色窗体样式 ChromeDialogStyle/CaptionBar + 主题画刷、修右侧空白 CanContentScroll、去黄字、容器显封面、随老板键隐藏)。沙箱 185/0、API 对 HEAD 核实;**待用户编译实测**。**【2026-06-18 bug1】**选中【容器(文件夹/书)】作封面时改为按其代表页**全分辨率重解码**(`ResolveCoverEntryAsync`/`DecodeThumbnailAsync(coverEntry,0)`,失败回退网格缩略图)+ `ImageIsHiRes` 标记,不再落低清网格缩略图;dav 容器优先用其已自定义的全分辨率封面。不增条,详见 §2 最新「dav 体验八连」①(✅ 2026-06-19 实测通过) **【2026-06-19 续·裁剪/自定义封面落盘改无损 PNG,🚧 待编译实测】**:用户截图证明色斑来自 q95 JPEG 在高频肌理上的额外伪影(放大暴露、缩小掩盖),故自定义封面/裁剪落盘从 q95 JPEG 改为无损 PNG(`NvDavCache.SaveCoverImagePng`),消除 JPEG 那层色块(源图肌理仍在);沙箱 220/0、不增条 **【2026-06-19 再续·真正修复"悬浮比海报墙更糊/有色斑",✅ 2026-06-19 实测通过,220→221】**:用户复测指出"小图(悬浮)反而比大图(海报墙)更糊"——纯缩放解释不通。真因=书架悬浮预览的 `<Image>`(`Generic.xaml` 经 `HoverPreview.Content`)未设 `BitmapScalingMode` → WPF 默认线性下采样混叠(=色斑+糊);海报墙用 `Fant` 故干净。新增 1 条 replace `HoverPreviewService.cs`(`Show()` 给悬浮 Image 设 `BitmapScalingMode.Fant`);沙箱 221/0、括号配平。详见 §2「当前补丁总数」条与 §4 魔改24 末「悬浮预览 Fant 缩放」 | **已交付** 1 create `_Mod/CustomCoverPicker.cs` + 9 wiring(`FolderListBox.xaml.cs`×4、`BookshelfMenuCommandTable.cs`、`BookshelfMenuDefault.cs`、`BookshelfConfig.cs`〔菜单迁移〕、zh-Hans/en restext) | `patches.py`(create+replace+append) |
| 25 | **顶部地址栏 = 文件夹导航地址栏**:顶部那条做成资源管理器式——地址栏**自动跟踪书架当前文件夹**(不再跟「打开的书」→ 空白/陈旧消除)、输入/粘贴/点面包屑**本地 `D:\…` 与 dav `dav://…` 都能跳转**(`AddressBar.Load`→`BookshelfFolderList.RequestPlace`);顶部 **← → ↑ 改为 书架 后退/前进/上一层文件夹**(用户弃用作者「上一本/下一本书、上移到书的父级」),右键历史=书架文件夹历史。**跨线程安全**:位置/历史变化刷新按钮可用态/地址文字 **一律 `AppDispatcher.BeginInvoke` 回 UI 线程**(照搬 `FolderListViewModel`);dav `CanMoveToParent`→`GetParentQuery` 纯字符串不碰网络。**取代之前撤回的「dav 顶部 ↑/粘贴地址导航」两 bug**(并扩展本地+自动跟踪+←→)。详见 §2 近期变更历史 2026-06-19。 | 🚧 待 Windows 实测(沙箱 `764fea1a7` 233/0、两 .cs 括号配平、XAML 良构、旧书导航符号全清) | `AddressBar.cs`×3(ctor跟踪/setter导航/Load移动书架) / `AddressBarViewModel.cs`×4(ctor回UI线程刷新/三键命令/GetHistory/MoveToHistory) / `AddressBarView.xaml`×3(←→↑重绑) | `build.py`(replace) |

> **⚠️ 关于 `build.py` 启动时打印的【改动概览】编号 ≠ 本表/§4 的概念编号**:概览按 `patches.py` 里的 `# 魔改 NN` 注释**自动分组**,与本表不完全对应——它把【已读完(16)+ 统计(17)+ 历史只记单文件(18)】的补丁**合并显示为「魔改16(19条)」**(这三者在 patches.py 里共用 16 段注释、无独立 17/18 头),并把 `ReadingBackup.cs`(本表 hd-db)标为**「魔改22(1条)」**。**总数一致、各 mod 条数也都对得上**(以 §2「当前补丁总数」为准,当前 **235 条**(234→235 新增 1 条 = 魔改26 海报墙无缝布局〔封面按真实宽高比变宽、单图去黑边〕,物理追加 PATCHES 末尾、有独立 `#  魔改 26` 注释;233→234 新增 1 条 = 魔改19 v5.8 书名设置页;223→233 新增 10 条 = 魔改25 顶部地址栏=文件夹导航,物理追加在 PATCHES 末尾、有独立 `#  魔改 25` 注释,故概览显示「魔改25(10条)」与 MD mod25 一致;221→223 新增 2 条 `FolderListBox.xaml.cs` replace=dav 双击打开,搜索改 `WebDavFolderCollection.cs` 不增条;220→221 系新增 1 条 `HoverPreviewService.cs` replace=悬浮预览 Fant 缩放,物理追加在 PATCHES 末尾、概览会归到末尾那段最近的 `# 魔改 NN` 注释下,不影响总数)),只是分组叫法不同,**不是代码与 MD 脱节**。核对口径:概览「魔改16(19条)」= MD 的 mod16+17+18;概览「魔改22」= MD 的 hd-db;其余 19/20/21 编号一致。**(不要为对齐去重构 patches.py 的注释编号——超出范围、有风险;按本注释理解即可。)**

> 每加一个新魔改,在这张表加一行,并在 §4 补一段详情。
>
> **实测状态**:权威的「已 Windows 编译实测 ✅ vs 待测 🚧」逐项清单见 §2「用户 Windows 实测确认」块(2026-06-19 更新);本表「状态」列亦标每个魔改当前状态。早期(2026-06-08/10 等)逐次编译/修复记录已归并入 §2「近期变更历史」与各 §4 小节。

---

## 2. 基准版本(Pinned Base)—— 最重要的一节

> **【2026-06-19 接手 AI 开工核查 · 上游无更新,未 `--pull`】** 按 §5.0 三步重新核查:① 文档基准 = `764fea1a7`;② 全新 `git clone`(非浅克隆,完整 4252 提交)+ `git fetch origin` 后,`git log --oneline 764fea1a7..origin/master` **输出为空**、`git merge-base --is-ancestor 764fea1a7 origin/master` 通过 → **上游 master 自基准起零新提交,用户本地已是最新**(origin/master HEAD 仍是 `764fea1a7`,commit 日期 2026-06-16;version-39~45 等分支均更老、非领先,不相关)。③ 因无更新,**本轮不需要 `--pull`**,基准 commit 不变。④ 顺带在干净 worktree(checkout `764fea1a7`)上 `python build.py --patch-only` 重放全部补丁 = **220/0 零失配**、`--no-reset` 重跑全部跳过(幂等)、改动概览合计 220 条 · 100 个文件,与 §2「当前补丁总数」「§1 表格」一致。结论:**这份魔改包对当前上游 HEAD 可直接干净打上、无锚点失配、无功能冲突/重合**。(本次仅订正了文档里几处陈旧数字:§7 收尾「203 条」→「220 条」、§1 注释「总数 154」→「220」、§5.0「39 个文件」→引用 `build.py` 概览末行;**所有带日期的历史快照一律保留**。)

- 上游仓库:`https://github.com/neelabo/NeeView`,分支 `master`,许可证 MIT

> **【2026-06-19 用户 Windows 实测确认 · 一批 🚧→✅】** 用户在本机编译并实测后逐项反馈,据此把 §1 表格状态更新如下(本条为权威实测记录,§1/§4 各处状态以此为准):
> - **✅ 海报墙双击崩溃已修复并实测确认(2026-06-19)**:症状=海报墙样式下双击文件夹/开书 → 卡几秒 → 自动闪退(内容样式正常);且用户「撤回 patches.py + 重编」后**仍崩**。真因两层:① 引起崩溃的是之前为 dav 顶部地址栏做、后已撤回的补丁 4(`AddressBarViewModel` 构造里 `AddressChanged += …NotifyCanExecuteChanged` lambda)——海报墙中央宿主在**后台线程**卸载书→触发它→跨线程改 ↑ 按钮 `IsEnabled`→`InvalidOperationException`(VS2026 调试器堆栈实证 `AnonymousMethod__2_2`);② 「撤回了还崩」是因为撤回时**只从 PATCHES 删了 4 条、漏登记 `OBSOLETE_EDITS`**→`build.py` 还原不会 checkout 这两个地址栏文件→旧补丁 4 永久残留在用户源码、重编也清不掉。**补救=把 `AddressBar.cs`/`AddressBarViewModel.cs` 加进 `OBSOLETE_EDITS`**,build.py 重编后**用户确认不再崩溃**(详见下方近期变更历史同日「撤回的补救——关键」条)。
> - **✅ 新确认通过**:mod15 标题去版本号(没开书标题留空)/ mod17(冷静期·5分钟门槛仍长期观察)/ mod20 预缓存原图封面(2048·512 隔离,含六续放大2048)/ mod21 双页末页页码 / mod24 自定义封面整块(下钻选页·dav 裁剪·容器全分辨率·选择器四连)。
> - **✅ mod23 已通过的批次**:Stage A 引擎、Stage B 接线(zip 流式打开)、Stage C 书架挂载/浏览/设置页/根下拉挂载/测试连接、C2 离线缓存、C3 持久内容缓存(离线阅读,此前 06-17 已单独实测✅)、Issue A/B/C 三连、原图统一2048(本地+dav)·封面分档·清缓存复位2048、流式 PDF(P/Invoke pdfium)、dav 文件夹清除缓存、NvDavDirFolderItem、方案A、dav 自定义封面三连、文件夹「自定义封面」、设置页 UI 精简/重构、按挂载独立右键菜单、六续(预缓存放大2048·清缓存关书+清子文件夹·落盘q95)。
> - **🚧 mod23 仍待测(用户本轮未确认)**:dav 三连(格式白名单 / dav书进度·已读完·统计 / 清缓存归零续读+单本菜单)、**流式 RAR/CBR**(SharpCompress)〔含 2026-06-19「RAR 封面快路径」:RarReader 只读首图,**已挂到浏览+预缓存共同入口 ArchivePageThumbnail**——浏览 dav RAR 文件夹封面应又快又只占几 MB(512 小封面),见近期变更历史〕、**加密 RAR + 加密 ZIP 流式**、**dav 八连其余项**(dav 重命名=Alist→115 MOVE〔最依赖运行时〕/ Feature1 文件夹自动封面「取首书首封」/ bug2 预缓存增量防风控 / Check1 内容缓存「确定」/ Check2 隐藏「重置」)、修 dav 预缓存风控误判。
> - **🚧 mod19 海报墙 v5.7**:用户表示「没听懂」,未实测;v5.4 F11、v5.6 墙闪此前已✅,v5.7 仅是「恢复瞬间中央那一下非全屏黑框零帧化」的进一步打磨,功能不受影响,保持 🚧 待用户理解后确认。
> - **裁剪/自定义封面色斑(已定位 + 已改无损 PNG,2026-06-19)**:用户用两张截图证明同源封面「悬浮大预览有色斑、海报墙缩小后干净」→ 说明并非纯源图,而是放大暴露了「源图水彩/网点肌理 + q95 JPEG 在高频肌理上额外加的色块伪影」(海报墙缩小把这两者平均掉)。**修 = 自定义封面/裁剪落盘从 q95 JPEG 改为无损 PNG**(`NvDavCache` 新增 `EncodePng`/`SaveCoverImagePng`,PATCHES[179] 调用从 `SaveCoverImage(...,95)` 换成 `SaveCoverImagePng(...)`;消除 JPEG 那层色块,源图本身肌理去不掉=画法)。文件名仍 `<hash>.<res>.jpg`、内容是 PNG 字节,`LoadCoverImage` 用 `BitmapImage` 按字节头识别编码、无需改;`ClearCover`/`GetBookCacheBytes` 按 `<hash>.*.jpg` 通配、文件名不变照常命中。**只改 `NvDavCache.cs`(create)+ `FolderListBox.xaml.cs`(mod24 那条 replace)两处既有补丁内容、不增条(仍 220)**;沙箱 HEAD `764fea1a7` 220/0、两文件整文件括号配平。⚠ **待用户编译对比**那个悬浮大预览的色斑是否明显减轻(轻了=主要是 JPEG 造的;差不多=画本身肌理、只能靠别把预览放那么大缓解)。详见 §4 魔改24 末「裁剪/自定义封面落盘改无损 PNG」。 **【订正 2026-06-19】** 上面"区别只在显示尺寸/放大暴露"的判断**不对**——用户复测明确「小图(悬浮)反而比大图(海报墙)更糊」,纯缩放解释不通。真正根因已找到=悬浮预览 `<Image>` 缺 `Fant` 缩放(默认线性下采样混叠),已新增 1 条 replace 修 `HoverPreviewService.cs`(220→221),见上方「当前补丁总数」条与 §4 魔改24 末「悬浮预览 Fant 缩放」。无损 PNG 这条仍有效保留(与 Fant 修复正交)。
- **补丁基于的 commit(当前)**:`32d892c19` —— `feat: ブック設定にエフェクトプロファイル番号を記録できるようにした (#1339)`(2026-06-23 由 `0ab0c48b0` 经 `python build.py --pull` 推进,上游 **3 个新提交**:特效配置编号 #1339 / 多选含父目录禁用复制 `1c38ac003` / 缩略图左右键折返 #1832;`FolderListBox.xaml.cs`×3 方法 + `Book.cs` memento + `FolderListBox.xaml` 缩略图样式 共重锚 4 条,详见顶部 2026-06-23 日志)。**上一基准 `0ab0c48b0`** —— `chore: 起動時ログ強化 (#1951)`(2026-06-20 由 `764fea1a7` 同步推进,上游 8 提交、tag `46.0-alpha.7`;`FolderListBox.xaml.cs` 重锚 4 条)。**上一基准 `764fea1a7`** —— `feat: コマンドパラメーター、ドラッグアクションパラメーターのJSONデータのポリモーフィズム化`(2026-06-17 由 `4dbe593eb` 经 `python build.py --pull` 推进,上游 **8 个新提交、零冲突零功能重合**、已实编、功能实测正常,核查见 §2.8)。**上一基准 `4dbe593eb`**(`chore: スライドショー中も「ドットのまま拡大」設定`,2026-06-15 由 `e87d924b1` 推进,上游 6 个新提交,核查见 §2.7)。**上一基准 `e87d924b1`**(`chore: タグ背景色コンバーター整備`):上游自更早基准 `e7bd7e299` 起共 **11 个新提交**:エフェクトプロファイル #689 / 本棚サムネイルアイコンオーバーレイ #1946 / コマンドパラメーターのコンボボックス化 / TagBackgroundConverter / スライドショー Fant 固定 #1945 / pt-BR 翻译 等。**接手 AI 已在 Linux 沙箱对干净 HEAD 逐条试打全部 136 条补丁(检测脚本完整复刻 build.py 锚点逻辑、且不在首个失配处停而是收集全部),初检 2 处锚点失配 + 1 处运行时隐患,均已重锚定,复检 136/136 零失配(详见下方 2026-06-13 日志)。⚠️ 2026-06-13 用户执行 `python build.py --pull`:还原→pull(Already up to date)→打补丁 **136/136 零失配**,但 MSBuild markup 编译报 `FolderListBox.xaml(264) MC3072: IsKeepArea 不存在`。根因仍是 #1946 重写 `FolderListIcon`(删了 `IsKeepArea` 属性、又删了 FolderListBox.xaml 里的 `OverrideIconStackPanelStyle` 资源,海报墙 mod19 都在用)。已补两处修复(见下方 2026-06-13 日志『续』)。**✅ 2026-06-15 已实编实测**:e87d924b1 的 #1946 ④`IsKeepArea` 删属性、⑤`OverrideIconStackPanelStyle` 内联两处修复编译通过;随后 `python build.py --pull` 推进到 `4dbe593eb`(6 个新提交、零冲突,见 §2.7)一并编译通过、功能实测正常(含 mod17b:高清封面「统计+已读完」都抓、导出名带日期、14 本封面全部导出)。要复现当前基准就 `git checkout 764fea1a7` 再打补丁。
- **当前补丁总数:282 条**(replace 230 / append 13 / create 39),基准 commit `32d892c19`。
- **近期变更历史(精简,新→旧)**——每条仅记「日期·改了什么·涉及文件已在 §1/§4 登记」;**完整根因/改法见对应 §4 魔改小节与代码注释/`git`**,故此处不再展开:
- `2026-06-23` **【魔改28:预设/默认值调整 · 278→282(+4 replace)】**:全是改"初始默认 / 新建时取值",**老用户已存的 Profile 不受影响、仍可在设置里自调**;主要面向发行版开箱默认。① **默认书架样式 = 海报墙**:`FolderListConfig._panelListItemStyle` 默认 `Content`→`PosterWall`。海报墙中央宿主(`PosterWallCenterHost`:样式=海报墙 且 无书在读 时,在主显示区整面铺墙;`MainWindow` 加载时挂接)随之在启动(无书)即显 → 开箱即海报墙浏览态。② **海报墙无缝**:`SystemConfig._posterWallGap` 本就默认 `0`(=无缝瀑布流)、`_posterWallJustified` 默认 `false`(瀑布流错落咬合),**已是无缝、无需改**,仅确认。③ **海报墙默认不显示书名**:`SystemConfig._posterWallShowName` 默认 `true`→`false`(纯封面墙;`PosterWallNameAreaHeight` 随之归 0、槽位不再留书名行高)。④ **WebDAV 新挂载默认限速 1/3**:`WebDavClient.DavThrottle.DefaultListing` `4`→`1`(目录列举 PROPFIND 次/秒)、`DefaultDownload` `2`→`3`(下载地址 次/秒)+ 同步类注释。**仅影响新挂载**——已挂载的速率值持久化在 `WebDavCache/throttle.json`(按挂载 key 整表存)、不受默认值变化影响;与截图(目录加载1/下载地址3)一致。沙箱 **282/0 零失配**(四处均单行值/注释改、无结构变动,括号不变)。**待用户编译实测**(尤其启动即海报墙宿主、新挂载限速读到 1/3)。⚠ **关于 ①**:`默认海报墙` 我按"开箱默认书架样式就是海报墙"实现;若你本意只是"用海报墙时默认无缝+不显示书名"、不想改默认样式,删掉 28-A 这一条即可(②③④ 不动)。
- `2026-06-23` **【魔改27:书签双击跳书架 + 去两颗书签星 + 菜单编辑器动态项正常色 · 272→278(+6 replace)·修正版】**:① **书签面板「双击」磁盘/dav 条目→跳书架对应位置**(单击只选中、不跳;不在书签面板里打开):书签面板与书架共用 `FolderListBox`。新增 helper `TryBookmarkRevealInsteadOfOpen(item)`(紧邻双击方法上方),在 `FolderListItem_MouseDoubleClick` 开头取 `item` 后调用,命中即 `e.Handled=true; return`;**单击不再跳**——`ClickToLoadBook`(单击入口,dav 守卫之后)加 `if (_vm.FolderCollection is BookmarkFolderCollection) return;`,书签面板单击只选中(不 `LoadBook`、不跳)。helper 仅 `_vm.FolderCollection is BookmarkFolderCollection` 生效;`target=item.TargetPath`,`target.Scheme==QueryScheme.Bookmark`(整理用书签夹「单文件/文件夹」=虚拟夹 `node.CreateQuery()`)→ 不拦截、保持作者默认(面板内展开);否则按 `target.SimplePath` 分流。**★两处 dav 实测踩坑(本修正版的关键)**:**(坑1)书签项 `IsDirectory` 恒为 false**——`CreateFolderItemBookmark` 对本地目录/文件/dav **都不设** `FolderItemAttribute.Directory`(只设 `Length`),故文件夹判定不能用 `IsDirectory`;改用 `NvDavSupport.IsDavPath(path) ? !NvDavSupport.IsDavArchiveExtension(path) : item.IsDirectoryMaybe()`(dav=非压缩包扩展名即文件夹;本地=`Length==-1` 即目录,与工厂 `IsDavPath && !IsDavArchiveExtension` 同口径)。**(坑2)dav 父目录绝不能用 `LoosePath.GetDirectoryName`**——它按 `/`+`\` 分割去空段再用 `\` 拼接,会把 `dav://h/a/b` 压成 `dav:\h\a`(`dav://`→`dav:`、`/`→`\`),`IsDavPath` 失配 → 工厂落 File 分支列本地空目录 → **「没有可显示的文件」**(用户实测:旧版双击 dav 书签跳过去全空;因 `IsDirectory` 恒 false,文件夹书签也走这条 GetDirectoryName 分支 → 导航到被书签夹的**上一级**且空,正是用户截图所见)。改用 mod23 已 dav 安全的 `QueryPath.GetParent()`。最终导航:**文件夹**→`RequestPlace(target, null, Focus)` 进入(`target` 保留 `dav://`,工厂 `IsDavPath` 命中→ `WebDavFolderCollection` 从 origin 解析凭据列目录);**书**→`RequestPlace(target.GetParent(), new FolderItemPosition(target), Focus)` 定位父目录并选中(不打开);全程 try/catch。(`FolderSetPlaceOption.FileSystem` 经查为**死标志**——全仓无 `HasFlag` 消费,故去掉只用 `Focus`,与已实测可用的老板键 dav 恢复 `RequestPlace(place,null,None)` 同理。)② **去掉顶部地址栏书签星**:`AddressBarView.xaml` 的 `<Button x:Name="BookmarkButton">` 加 `Visibility="Collapsed"`(不删元素——popup line322-325 仍 `ElementName=BookmarkButton` 绑定)。③ **去掉书架列表项书签★**(橙星=`FolderMarkIcon`,其 `<Image>` 图源/可见性绑 `FolderItemIconOverlayToImageSourceConverter`/`...ToVisibilityConverter`,Generic.xaml line188-195):两刀——ImageSource 转换器 `case Star` 改 `return null`,且 Visibility 转换器对 `Star` 加 `&& overlay != ...Star` 返回 `Collapsed`(整块收起、不留 18px 空位);绿✓/✗ 不受影响。④ **菜单编辑器动态项(书签等)改回正常色**:`BookshelfMenuNode.cs` 的 `TextBrush` 把 `DynamicToggle => Brushes.DarkGray` 改为 `Control.Foreground`(▸ 标记仍区分;本地+dav 编辑器共用)。沙箱 **278/0 零失配** + `FolderListBox.xaml.cs`/`AddressBarView.xaml`/`FolderListIcon.cs`/`BookshelfMenuNode.cs` 括号全 0 偏差。**待用户编译实测**。**遗留(未做·间歇性)**:书签面板根目录「单文件/文件夹」分类夹偶发渲染成带标签徽章+文件图标的列表行(用户截图确认),与「书签自动分类」mod 相关,待复现触发步骤再修。
- `2026-06-23` **【书架/书签两处 UI 修复 · 271→272(+1 replace `FolderItem.cs`;另就地改 `FolderListBox.xaml.cs` 既有补丁 idx55,不新增补丁)】**:① **右键「书签」菜单项不再显示「Ctrl+D」快捷键文字**(快捷键本身仍生效)——`CreateBookshelfDynamicItem` 的 `case "Bookmark"` 给 `MenuItem` 加 `InputGestureText = " "`(单空格);**WPF 仅当 `InputGestureText` 为空(`IsNullOrEmpty`)才会自动从 `ToggleBookmarkCommand` 的 `KeyGesture` 派生出「Ctrl+D」显示**,给个空格即隐藏文字、且不动命令的 `KeyGesture`(本地+dav 右键菜单共用此动态项 → 一处改两处生效)。② **上书签后,书架项右侧不再显示「文件夹」/「单文件」灰色标签**(黄星保留)——根因链:`FolderItem.UpdateTags()` 把项对应书签的**父书签夹名**当作标签(由 `TagItemsControl` 渲染在三种行模板右侧),而魔改「书签自动分类」(`BookmarkCollectionService.EnsureCategoryFolder`)把每个新书签自动归入顶层「文件夹」/「单文件」分类夹 → 父夹名遂成标签;新增补丁在 `UpdateTags` 的 `.Where` 里排除父夹名∈{「单文件」,「文件夹」}者(用户在分类夹内自建的**真实**标签夹仍显示;黄星=`FolderMarkIcon` 是另一个独立控件、完全不受影响)。沙箱 **272/0 零失配** + `FolderListBox.xaml.cs`/`FolderItem.cs` 括号 **0/0/0**。**待用户编译实测**(若 #1 在个别环境仍显示快捷键,则改为移除命令 `KeyGesture` 的显示派生)。
- `2026-06-23` **【新增工具脚本 `生成发布成品_到E盘.py`(非补丁、已放进接手包)· 补丁数不变 271】**:用户要发布到 GitHub 发行版,且**不愿源码被反编译 / 被商用**。已向用户澄清现实:.NET(含 WPF)编译产物是 **IL**、可被 ILSpy/dnSpy 反编译回近似源码;WPF **不支持 Native AOT**(最强反编译手段对它关死);唯一实用手段是**混淆**(抬高门槛、非不可破,且 WPF 混淆须排除 XAML 反射引用的类/属性名否则启动崩);NeeView 是 **MIT**——**允许**发布闭源/混淆二进制(须保留 MIT 版权声明),但管不住上游 NeeView 本身被他人商用;**关键提醒**:`patches.py` 本身=全部魔改源码,**切勿提交到公开仓库**(用户仓库 `reimu2233/NeeView_beta` 现仅 LICENSE/README/挂载说明,未泄露源码)。**脚本作用 = 混淆前的一步**:全新克隆上游钉 `32d892c19` → 用 `build.py` 打全部补丁 → **一次产出两个版本**:A) 需装运行时版(framework-dependent,体积小)= 复用 `build.py` 的 MSBuild 整 .sln 编译;B) 免装运行时版(self-contained,体积大)= `dotnet publish <csproj> -c Release -r win-x64 -p:SelfContained=true`(注:.NET 6+ 起 `-r` 不再隐含自包含,故显式 `SelfContained=true`)→ 两版都剥 `.pdb`(调试符号、便于逆向)+ 删任何 `Profile`(防泄露密码/历史)→ 落 `E:\NeeView_魔改_发布成品\{需装NET10运行时_体积小, 免装运行时_体积大}\`。两版 obj 路径不撞(`obj\x64\Release\…` vs `obj\Release\…\win-x64\`)。开关 `BUILD_FRAMEWORK_DEPENDENT`/`BUILD_SELF_CONTAINED` 可单独关其一;发其它上游版只改 `PIN_COMMIT` 一处。**待用户定工具再接入(未做)**:混淆步骤本身——候选 免费 `Obfuscar`(仅改名、需手配 XAML 排除)/`ConfuserEx2`(更强但 .NET 10 支持不稳),付费 `.NET Reactor`/`Eazfuscator`(WPF 友好、强、把方法编原生码)。脚本只增不改补丁,**271/0 不变**;沙箱仅 `ast.parse` 语法自检通过,实际 MSBuild/publish 须 Windows 实测。 **【修1·2026-06-23 用户实测反馈】**:首版漏拉子模块 → MSBuild 报 `MSB3202 未找到项目文件 …SevenZip.csproj / …Vlc.DotNet… / …NeeLaboratory.IO.Search… / …AnimatedImage…`。根因:NeeView 有 **4 个子模块**(`SevenZipSharp`/`NeeLaboratory.IO.Search`/`Vlc.DotNet`/`AnimatedImage`,均 neelabo 下,`.gitmodules` 在仓库根,`NeeView.sln` 引用这些子项目),普通 `git clone` 不含子模块。**已修**:checkout 钉定 commit 后补 `git submodule update --init --recursive`(拉到该 commit 钉定的子模块状态,需联网)。修复同时解决 A 版(MSBuild 整 .sln)和 B 版(dotnet publish 走 ProjectReference)。
- `2026-06-23` **【上游同步 `0ab0c48b0`→`32d892c19`(3 提交)· 重锚 4 条 · 仍 271】**:用户流程=每次 clone/pull 最新上游 + `build.py --pull` 打补丁,故「同步」=把补丁重锚到最新上游(让下次拉最新代码再打补丁能干净跑通)。上游 3 提交(**特效配置编号 #1339**=给 `BookMemento`/`BookSettingConfig`/`EffectProfileCollection` 加 `EffectProfileId` 字段 / **多选含父目录禁用复制 `1c38ac003`**=书架一批 `IsEmpty()`→`IsSystem()` + 拖放守卫 / **缩略图左右键折返 #1832**=加 `IsNavigateWithWrapEnabled` 属性)只撞 3 个文件、共 4 条补丁,其余 267 条干净。**重锚处理**:① **`FolderListBox.xaml.cs` ×3 上游方法**——`RegenerateThumbnailCommand_Execute`(mod 隐藏项/预缓存命令两条共锚此方法体〔idx43/68〕)、`ClickToLoadBook`(mod23 dav 单击只选〔idx221〕)、`FolderListItem_MouseDoubleClick`(mod23 dav 双击开书〔idx222〕):anchor+text 同步把 `!*.IsEmpty()`→`!*.IsSystem()` 跟随上游(双击/单击不再误开父目录项;text 也改、否则会把上游这行顶回去)。② **`Book.cs` memento〔idx86 mod13 阅读进度〕**:上游在 `BaseScale = _setting.BaseScale,` 后插了 `EffectProfileId = _setting.EffectProfileId,`,把这行补进 anchor 载体+text(否则锚不上/会顶回上游改动)。③ **`FolderListBox.xaml` 缩略图样式〔idx121 mod19 海报墙〕**:上游给缩略图 DataTrigger 加了 `IsNavigateWithWrapEnabled=True` 的 Setter,补进 anchor 与复刻的 Thumbnail 块;海报墙块用自定义 `NvPosterWallPanel`、不确定其支持该导航属性,保守起见**不**加(故海报墙左右键不折返,见下注 b)。**关键事实(已核源码、非假设)**:`FolderItem.IsEmpty()`/`IsSystem()` 定义都还在(line 317/319,本次只 `CanThumbnail()` 内部从 `!IsEmpty()` 改 `!IsSystem()`)→ 我**其余仍调 `IsEmpty()` 的魔改**(如预缓存命令 idx144 的 `item.IsEmpty()`)**照常编译、未动**。沙箱 `git pull`→`32d892c19`、`build.py --pull --patch-only` **新打 271 / 跳过 0 零失配** + 73 个 replace/append 目标 .cs 括号 ()/{}/[] **全 0/0/0**。**无硬性功能矛盾**,仅两处可选一致性(已报用户、未改):**(a)** 我的预缓存命令仍用 `IsEmpty`、不像上游复制那样排除「..」父目录项(选中父目录跑预缓存会试着缓存它=旧行为、非本次引入,想对齐改 `IsSystem` 即可);**(b)** 海报墙样式未加 `IsNavigateWithWrapEnabled`、左右键在海报墙模式不折返(缩略图模式现已折返,想加可补)。⚠ **沙箱无 WPF 无法编译**——「补丁干净打上+括号配平」**检测不到上游改方法签名这类编译错**;本次 3 提交均为加字段/加属性/换谓词的局部改动、已核对全部接触点(`EffectProfileId`/`IsNavigateWithWrapEnabled` 与上游逐字一致、`IsSystem()` 存在),但仍请 Windows + VS2026 编译实测确认。用户可 `git pull` / `build.py --pull`(会拉到 `32d892c19` 再干净打上更新后的 `patches.py`)。
- `2026-06-23` **dav 预缓存统计段:列目录被风控即整体中止 + 确认框**(266→271,+5 replace,`BookshelfPrecacheRunner.cs`)。改掉原「列举失败→跳过该层子树、继续统计、完成时把失败目录塞进『查看失败』」的行为(级联跳过 + 无退避 + 进度条假完成 + 不提示)。新行为:统计段 `CollectDavBooksAsync` **任一层列目录失败(基本=风控:429/503/超时/非法响应)即抛哨兵 `DavListRateLimitedException`**,经递归(foreach await 在 try 外、不被任何中间 try 吞,传播干净)直达 dav 调用处 → `rateLimited=true` → **整段跳过封面拉取**,弹一个**只有确认按钮**的框「目录可能因风控未能完全列出，请稍后尝试。」(`MessageDialog`+`UICommands.OK`,经 `RunWhenVisible` 在老板键隐藏时延后弹),**无「查看失败」、无多余文字**。catch 不再 `ListFailed++`/`FailedDirs.Add`(两字段仍声明,仅 fetch 段失败书继续走『查看失败』)。沙箱 271/0、文件括号 0/0/0。**待用户编译实测**。
- `2026-06-23` **dav 预缓存拉取中取消误报失败修复**(265→266,+1 replace,`BookshelfPrecacheRunner.cs`)。症状:拉取几秒后取消,完成框显示「失败 N」(N=DavParallel 在途并发本数)。根因:`ProcessDavBookAsync` 已在 catch 里处理「取消→抛异常→不计失败」,但 `LoadThumbnailAsync` 取消时**未必抛异常**——下载中断可让它正常返回一张「无效/占位」缩略图(`IsValid/IsUniqueImage=false`),漏过 catch、落到 `else` 失败分支被 `c.Failed++ / FailedBooks.Add` 当成真失败。修:`else` 计 Failed 前再判一次 `token.IsCancellationRequested`,取消态下撤掉预标的档后 `throw new OperationCanceledException(token)`(由 `Parallel.ForEachAsync` 收敛为取消、不计失败、不进失败清单)。沙箱 266/0、文件括号 0/0/0。**待用户编译实测**。
- `2026-06-23` **老板键/自动隐藏:修 AutoHideBehavior 两确凿 bug + 防御性修「恢复后悬浮唤不出左栏」**(259→265,+6 replace,改上游 `NeeView/Windows/Controls/AutoHideBehavior.cs`)。**确凿 bug**:① `OnDetaching` 的 `PreviewKeyDown +=` 应为 `-=`(复制粘贴错,卸载时反而多加一个 handler);② Loaded/Unloaded 绑定不对称(原版只在 OnAttached 绑 Loaded、只在 OnDetaching 绑 Unloaded)→ 改为 OnAttached 成对绑、OnDetaching 成对解,并在 OnDetaching 真正解掉窗口事件(MouseMove/MouseLeave/StateChanged/Activated)+ 置 `_window=null`(消除 HWND 重建时 MouseMove handler 累积)。**悬浮失效防御性修**(静态分析定不到唯一根因,把候选一并覆盖):③ 新增 `Window_Activated` 自愈——窗口激活(老板键/最小化恢复必经)时 `Mouse.Synchronize()` 强制 WPF 重判鼠标命中(治 `_window.IsMouseOver` 卡 stale)+ 清 `_isVisibilityHoled` 残留 + `UpdateVisibility(UpdateMouseOver)` 重算;④ `IsMouseOver` 加 `Screen==null` 守卫(治 ElementName 绑定 HWND 重建后失解致 `Mouse.GetPosition(null)` 每次 MouseMove 抛异常)。沙箱 265/0、文件括号 0/0/0。**待用户编译实测**。
- `2026-06-23` **dav 预缓存进度文案 + 暂停恢复修复**(255→259,+4 replace:`BookshelfPrecacheRunner.cs`×1 + `PrecacheProgressWindow.cs`×3)。① 运行消息从「dav 逐本拉取中…已处理 N 本(跳过 Y)」改为「拉取中 — 完成 X、跳过 Y、失败 Z（共 T 本）」(`ReportDav` 的 msg),与暂停行「已暂停 — 完成 X、跳过 Y、失败 Z」同款,三者随每本实时变(ReportDav 每本调一次)。② 修「暂停→继续」后消息卡「继续中…」要等 ~1-2s(worker 从 150ms 轮询醒 + 拉完一本网络往返)才复原:`PrecacheProgressWindow` 加 `_lastRunningText` 字段,`Report` 写运行消息时同步记下,`TogglePause` 继续分支由「继续中…」改为**立即复原 `_lastRunningText`**(空则回退「处理中…」)。沙箱 259/0、两文件括号 0/0/0。**待用户编译实测**。
- `2026-06-23` **dav 预缓存计数条**(进度条不再卡 0%,249→255,+6 replace:`BookshelfPrecacheRunner.cs`×5 + `PrecacheProgressWindow.cs`×1)。根因:`ReportDav` 硬编码 `window.Report(0.0,…)`——dav 不预先数总数 → 比率算不出 → 进度条永远 0%(只滚文字)。改两段:① **统计段** `WalkDavAsync`→`CollectDavBooksAsync`(只递归列目录 + 收集全部书 URL + 记文件夹封面别名,**不拉封面**;命中缓存树即零网络、未缓存层走限速 PROPFIND),算出 `c.Total`;② **拉取段** 把收集到的书 URL 扁平 `Parallel.ForEachAsync` 逐本拉,`ReportDav` 按 `Seen/Total` 算比率 → 进度条 0→100% 滚动。`DavPrecacheCounters` 加 `Total` 字段;`Report(value,text)` 支持 `value<0` = 不定进度(统计段进度条转圈+显「…」,拉取段切回确定百分比)。统计段也受暂停闸(`WaitWhilePausedAsync`)控制。风控:直链 throttle(2/s)仍是唯一敏感步;统计列目录走独立 listing throttle(4/s)+ 缓存树(每文件夹列一次),压力小。与上一条「预缓存解耦」叠加=稳态下统计段几乎全命中缓存(零网络、瞬时),进度条立刻开始滚。沙箱 255/0、两文件括号 0/0/0。**待用户编译实测**。
- `2026-06-23` **dav 预缓存解耦 + 刷新/浏览增量 diff 清孤儿**(246→249,+3 replace,均 `_Mod`)。① `WebDavFolderCollection.StartBackgroundRefresh`:`live` 列举成功后、`SaveTree` 前插入增量 diff(新增 `CleanRemovedDavEntries`/`CleanRemovedDavEntry`)——cached 有、live 已无 = 网盘已删 → 清孤儿(书:全分辨率封面+内容块;文件夹:递归清整棵已缓存子树+树缓存+别名,`LoadTree` 零网络);同名但 size 变 = 被替换 → 清旧封面/内容待重取。仅在 live 有效非空时执行(PROPFIND 原子,非空即完整),不误删。浏览/刷新均经 `StartBackgroundRefresh`,故**点书架刷新按钮(FolderSync→SyncAsync→SetPlaceAsync→重建 collection→命中缓存→StartBackgroundRefresh)即对当前 dav 文件夹做增量检测+清理**(按文件夹,非递归)。② `BookshelfPrecacheRunner.InvalidateFailedParents` 停用(原:有书失败就作废其文件夹树缓存 → 下次预缓存重新 PROPFIND 列举;风控下书常失败 → 缓存反复作废 → "每次预缓存都重扫")→ 现失败不再作废缓存,已缓存文件夹永不重列、稳态零列举;解直链失败的书下次仍从缓存原地重试(无需重列),已删的书改由刷新/浏览清理。**不动 WebDavEntry/mtime**(增/删纯路径 diff 即够,改按 size)。沙箱 249/0、两文件括号 0/0/0。**待用户编译实测**。
- `2026-06-22` **【书签面板顶部清爽化(仿已读完)+ 单文件/文件夹分类切换按钮 · 242→246】**：改 `BookmarkListView.xaml`(顶部 UI)+ `BookmarkListView.xaml.cs`(导航/记忆),两文件此前均未被补丁动过。**背景**:书签早有"[魔改-书签分类]"机制——`BookmarkCollectionService.Add` 每次加书签时按 `IsFolderTarget`(本地目录、或非压缩包的 dav 路径=文件夹;否则单文件)经 `EnsureCategoryFolder` **自动归入顶层「单文件」/「文件夹」两个文件夹**。本轮把这两类用按钮切出来 + 头部去冗余。**① 顶部清爽化**(XAML)：删掉原一排工具栏(＋添加 / ↑上层 / 🔄同步 / 名称↑排序 ComboBox / 🔗树视图布局)与面包屑(`BreadcrumbBar` + 复制地址右键)整块;**保留**「⋯」MoreMenu(`MoreMenuDescription`,放排序等少量功能)与搜索框;计数改「共 N 本」(仿已读完)。**② 单文件/文件夹 分段切换**(XAML + 代码后置)：顶部加两个 `ToggleButton`(左 单文件 / 右 文件夹,新样式 `CategoryToggleButtonStyle`:选中=`Control.Accent` 强调色填充 + `Control.AccentText`、悬停 `IconButton.MouseOver.Background`、圆角)。点击经代码后置 `NavigateToCategory(isFolder)` → `_vm.Model.MoveTo(new QueryPath(QueryScheme.Bookmark, isFolder?"文件夹":"单文件", null))`——**路径格式经核实与 `CreateQuery`(节点路径=层级名 `\` 连接、Skip 根)一致**,顶层分类文件夹路径就是其名,故必中;同时把另一个按钮取消选中(分段互斥)。**③ 默认单文件 + 记忆位置**:`static bool _lastCategoryIsFolder`(会话内记忆,默认 false=单文件);`BookmarkListView_IsVisibleChanged` 首次显示(`_categoryInitialized` 守卫)进入记忆的分类;之后由两按钮控制、不再每次重置(面板单例、Place 本就会话内保持)。4 条 NEW replace(XAML 资源样式 + XAML 顶部区 + 代码后置字段 + 代码后置 IsVisibleChanged/处理器)。沙箱 **246/0**、`BookmarkListView.xaml.cs` 括号 0/0/0、XAML 标签配平(DockPanel/Style/ToggleButton/StackPanel/Border 全配平)、重建核对(分类按钮+样式在、工具栏/面包屑全去、MoreMenu+SearchBox 保留、导航路径与 CreateQuery 一致)。🚧 待实测:书签面板顶部只剩 单文件/文件夹 两钮 + 共 N 本 + ⋯ + 搜索;点单文件/文件夹切到对应分类、选中态高亮、计数随之变;默认进单文件、切到文件夹后(会话内)再开面板仍在文件夹;⋯ 菜单与搜索照常。注:记忆为会话内(整程序重启回默认单文件,可加配置持久化为后续);分类依赖既有自动归类(老书签若不在两分类文件夹下,需重新加书签或手动移动)。
- `2026-06-22` **【设置树折叠/展开记忆 + 记住末次所选页 + 预缓存进度窗加暂停按钮(+暂停看统计)+ 取消不再误报未完成 · 240→242】**：两组。**① 设置树折叠记忆 + 末页记忆**(均"退出设置窗即记住"、会话内持久,重启重置):(a) 折叠/展开——`SettingPage.IsExpanded`(原版无通知自动属性、默认 true、每次开窗新建页 → 总是全展开)改为**静态字典 `_isExpandedMemory` 支撑**(按页类型 FullName 键、默认 true):XAML 的 `IsExpanded` TwoWay 绑定照旧——用户折叠/展开 → setter 写字典;重开窗新建页 → getter 读字典还原。无需存盘钩子(setter 即持久)。(b) 末页——`_latestSelectedPageType`(static)原本就记会话内末次所选页;新增在 `SettingWindowModel` ctor 还原末页后**展开其父分类**(`_pages.FirstOrDefault(p=>p.Children.Contains(page))→parent.IsExpanded=true`),确保折叠记忆下末页(尤其「其他」下的子页)仍在树里可见。两条 NEW replace(`SettingPage.cs`、`SettingWindowModel.cs`,均此前未被补丁动过)。**② 预缓存进度窗暂停 + 取消修**(改 #65 `PrecacheProgressWindow.cs` + #64 `BookshelfPrecacheRunner.cs` 两 create 文本):(a) **暂停按钮在隐藏与取消之间**——`_pauseButton`(「暂停」/「继续」切换)插入 `buttons` 中间;`_isPaused`(volatile)。(b) **暂停时看完成/跳过/失败**——窗口加 `SetCounts(success,skipped,failed)`(Runner 每报进度时调:本地 `(success,skipped,0)`、dav `(c.Success,c.Skipped,c.Failed)`);暂停时消息行换成「已暂停 — 完成 X、跳过 Y、失败 Z」并随在途本完成实时刷新;`Report` 加 `&& !_isPaused` 门控不覆盖统计。**暂停机制**=窗口 `WaitWhilePausedAsync(ct)`(暂停期间每 150ms 轮询、继续或取消即放行),Runner 两并行循环(本地 `RunCoreAsync` worker 首、dav `ProcessDavBookAsync` 首)`await` 之 → 暂停=不开新本、在途本跑完即等;取消时 `OnCancelRequested` 置 `_isPaused=false` 放行等待中的 worker 走到取消。(c) **取消不再把"在下载未完成"的本误报失败**——根因:dav `ProcessDavBookAsync` 的 OCE catch 本会 `throw`(纯 OCE 不计),但取消中断下载常抛**非 OCE 异常**(流中止/Dispose),落入通用 `catch { ok=false; }`→`c.Failed++`+`FailedBooks.Add` → 取消报告里冒出失败本(用户报"取消报错")。改:通用 catch 里 `if(token.IsCancellationRequested){撤标;throw new OperationCanceledException(token);}` → 取消期间任何异常都按取消处理、不计失败(外层 `Parallel.ForEachAsync` 的 token 仍令 `cancelled=true`、照常出「已取消」概括,但 FailedBooks 只剩真失败)。本地路径取消计 skipped(良性、无失败报告)未改。沙箱 **242/0**、四文件(`SettingPage`/`SettingWindowModel`/`PrecacheProgressWindow`/`BookshelfPrecacheRunner`)括号 0/0/0、重建源码核对(IsExpanded 字典化、ctor 展开父分类、暂停钮顺序 hide/pause/cancel、TogglePause/SetCounts/WaitWhilePausedAsync、两暂停闸门、dav 取消抛 OCE 不计失败、两 SetCounts)。🚧 待实测:① 折叠某分类→关设置→重开仍折叠、末次所选页(含「其他」下子页)重开即定位且父分类展开;② 预缓存进度窗「隐藏 暂停 取消」三钮、点暂停→停拉新本+显示完成/跳过/失败、点继续→恢复、取消时在途未完成本不再算失败/不报错。注:① 为会话内(关重开记住、整程序重启重置);暂停为每本粒度(在途本跑完才停);暂停钮文案硬编码中文。
- `2026-06-22` **【海报墙下拉去括号 + 老板键专用设置页 + 命令下三页归「其他」可折叠分类 · 238→240】**：三事一并。**① 海报墙「排版方式」下拉去括号**：`PosterWallSettingPage.cs` 两项「瀑布流(错落,封面更大)」「等高整齐(填满每行)」→「瀑布流」「等高整齐」。**② 老板键专用设置页**（用户改主意要做;Alt+X 仍固定不可改）：新增 `SystemConfig.BossKeyEnabled`(默认 true)/`BossKeyDisableRestore`(默认 false) 两配置 + 新建 `_Mod/BossKeySettingPage.cs`(`SettingPage` 子类,section「老板键(Alt+X)」承载固定键备注,两勾选框「启用老板键」「禁止恢复」,无冗余文字)。`BossKeyHotKey.cs` 改造：(a) **启用开关=动态注册/注销全局热键**——`Initialize` 缓存 `_hwnd` + 订阅 `SubscribePropertyChanged(nameof(BossKeyEnabled))`→新增 `ApplyEnabled()` 按配置 RegisterHotKey/UnregisterHotKey(禁用即让出 Alt+X 给别的程序、实时生效);(b) **禁止恢复**——`Toggle()` 顶加启用兜底检查,恢复分支(`IsHideWindow` 真)在 `ResumeAndRestoreAsync()` 前加 `if(BossKeyDisableRestore)return`→Alt+X 只隐藏不叫回;**托盘恢复不受影响**(`AppState.ShowWindow→ResumeAsync` 不经 `Toggle`、隐藏时已 `IsTaskTrayEnabled=true` 故托盘图标在);(c) Dispose 退订。加 `using NeeLaboratory.ComponentModel`(扩展方法所在)。**③ 命令下「自定义扫描/WebDAV/海报墙」+「老板键」归「其他」可折叠分类**（仿原版父分类）：新建 `_Mod/SettingPageOther.cs`(`SettingPage` 子类,header「其他」,`Items=null` 只设 `Children`=四子页)——靠原版 `SettingPage.DisplayPage`「`Items==null` 时返回首个子页」机制,选中「其他」即显首个子页、`CreateContent` 对 null 返回 null 不崩;`SettingWindowModel._pages` 尾部由 Command+三 mod 页 改为 Command+`SettingPageOther`(三页移入其 Children;`#172` 改文本=新尾,`#107` 仍产 ReadFinished 作 `#172` 锚点不动)。`IsExpanded` 默认 true(同原版分类,可手动折叠)。沙箱 **240/0**、六文件(`PosterWallSettingPage`/`SystemConfig`/`SettingWindowModel`/`BossKeyHotKey`/`BossKeySettingPage`/`SettingPageOther`)括号 0/0/0、重建源码核对(下拉去括号、两配置、`_pages` 尾=Other、`ApplyEnabled`+Toggle 双检查、两勾选页、Other 四子页)。🚧 待实测:① 下拉无括号;② 老板键页勾选启用(取消勾→Alt+X 失效且让出)/禁止恢复(Alt+X 只藏·托盘恢复);③ 设置树「命令」下三页+老板键收进可折叠「其他」、点「其他」显首个子页。
- `2026-06-22` **【修 ④ 海报墙封面间距:0-20 只有 0-5 生效(渲染端漏改)· 仍 238】**:上一条把设置页滑块 + `SafeGetGap` 改到 0-20,但**漏了渲染端**——`NvPosterWall.cs` 有 `private const double MaxGap = 5.0;`、布局时 `if (g > MaxGap) g = MaxGap;` 把间距硬夹回 5,故 6-20 全无反应(用户撞到)。改 `MaxGap` **5.0→20.0**;顺带把 `SystemConfig` 两处注释「0~5px」(`_posterWallGap` 字段行 + `PosterWallGap` 属性上方)更正为「0~20px」。已核 `PosterWallGap` setter 不夹、无 XAML 转换器、`PosterWallCenterHost` 只读不夹 → 全局仅此一处 clamp。沙箱 238/0、`NvPosterWall.cs`/`SystemConfig.cs` 括号 0/0/0、重建确认 MaxGap=20.0。🚧 待实测:封面间距能拉到 20px、且每档都有可见反应。
- `2026-06-22` **【清缓存确认框加体积 + 海报墙设置精简 + 老板键确认为固定全局热键 · 仍 238】**：三事一并。**② 清 dav 缓存:确认框现含体积、清完 Toast 中点改逗号**——此前确认框只「将清除此文件夹的缓存,确定?」不显体积。现清前先「只测量不删」(纯本地缓存树枚举 + 单次 covers 扫描,零网络不卡:新增 `BookshelfPrecacheRunner.MeasureDavFolderCacheAsync`,复用 `NvDavCache.ClearAndMeasureBatch` 加 `bool delete` 形参——`false`=只量、`true`=真删)→ 确认框显示「封面 X，内容 Y，确定清除?」;秒清不变;清完右下角 Toast 由「封面 X · 内容 Y」(中点)改全角逗号「封面 X，内容 Y」。改 `NvDavCache.cs`/`BookshelfPrecacheRunner.cs`/`FolderListBox.xaml.cs` 三个 create 文本,不增条。**④ 海报墙设置页精简**(`PosterWallSettingPage.cs` 重写构造器):去「布局」「书名」两段长描述文字(改单参 `SettingItemSection(header)`,Tips 空即不渲染);**删整个「大小」模块**(列数/封面行高两滑块 + 弃用的 `SafeGetColumns`/`SafeGetWidth`)——`PosterWallColumns`/`PosterWallTileWidth` 配置与海报墙渲染仍在、书架里 Ctrl+滚轮照常即时缩放,仅去掉滑块;「封面间距」从「大小」拎进「布局」、范围 0-5 → **0-20px**(`SafeGetGap` 上限同步 5→20);书名勾选框文案「在每张封面下方显示书名」→「显示书名」,并把该行行内标题留空(`SettingItemContent("", check)`)以免与勾选框文字重复(代价:勾选框上方留一行空隙——SettingItemControl 不折叠空标题)。净剩两区:布局(排版方式 + 封面间距)、书名(显示书名 + 书名行数)。**③ 老板键 Alt+X = 固定全局热键、进不了「命令设置」**:`BossKeyHotKey.cs` 构造里 `RegisterHotKey(hwnd, ID, MOD_ALT|MOD_NOREPEAT, 0x58)` 硬编码、不读任何配置 → Alt+X 写死。**为何进不了命令设置**:命令设置=WPF InputBinding=应用内快捷键、仅 NeeView 获焦时触发;老板键必须是 Win32 **全局**热键(窗口已隐藏到后台时还能按它叫回,普通命令做不到「从隐藏态恢复」)。要可改键只能另做一个**专用改键设置**(全局热键、不走命令系统:修饰键+虚拟键配置 + 取键 UI + 改动时注销/重注册)=独立小功能,已向用户提出、待其确认是否要做,本轮未动代码;默认仍 Alt+X。(§1 表 mod09 早已注「固定Alt+X(改键需另做)」,此处明确回答用户之问。)沙箱 238/0、`NvDavCache.cs`/`BookshelfPrecacheRunner.cs`/`FolderListBox.xaml.cs`/`PosterWallSettingPage.cs` 括号 0/0/0、重建源码核对(② 测量→确认框含体积逗号→关书→清→Toast体积逗号;④ 海报墙净两区、间距 0-20、勾选「显示书名」)。🚧 待实测:② 清缓存确认框显体积、清完 Toast 逗号、秒清;④ 海报墙设置只剩两区、封面间距 0-20px、书名勾选「显示书名」、Ctrl+滚轮缩放仍在。
- `2026-06-22` **【修复「右键清除 dav 文件夹缓存」：体积分封面/内容 + 秒清除（去网络/去二次方）· 仍 238】**：此前两病：① 清完只显示单个合并"释放 xxx"、不分封面与内容；② 文件多时很慢——`CollectDavComicFilesAsync` 建 `WebDavClient` 走 `CollectDavRecursiveAsync` 联网 PROPFIND 递归枚举整个文件夹树，且计量靠每本 `GetBookCacheBytes`（算封面时**每本都重扫整个共享 covers 目录**=近二次方）、删前 `before`+删后 `after` 各算一遍。**本次（全补丁式，改 3 处）**：① **`NvDavCache` 新增 `ClearAndMeasureBatch(coverUrls, contentBookUrls)`**（#186）——封面**只遍历一次**共享 `covers/` 目录（按 16 位 hash 前缀命中：`.jpg`→计 coverBytes+删、`.alias`→删），内容块逐本 `pages/<hash>/`（`DirectoryInfo.EnumerateFiles` 计 contentBytes 后整目录删）；**封面/内容字节分别返回**，去二次方、去删后重测；② **`BookshelfPrecacheRunner` 新增 `CollectDavComicFilesFromCache` + 重写 `ClearDavFolderCacheAsync`**（#64）——枚举改为**纯本地已缓存目录树**（`NvDavCache.LoadTree` 递归，局部函数 `Walk`+`visited` 防环，`NvDavSupport.Parse().serverPath` 取根）**零网络、不建 WebDavClient**，没缓存的层=没缓存可清→跳过；`ClearDavFolderCacheAsync` 返回签名改 `(int files, long coverBytes, long contentBytes)`，内部 coverUrls=书+文件夹自身+各层子文件夹、contentUrls=仅书 → 调 `ClearAndMeasureBatch`；ClearResume / 历史移除照旧；③ **`FolderListBox` 菜单**（#193）——Toast 改 `封面 {X} · 内容 {Y}`，新增 `FormatDavCacheSize`（≥1GB→GB **三位小数**，否则 MB 一位、含不足 1MB 如 "0.4 MB"），去掉"已清除 N 个文件，释放"等冗余文字；解构改 `var (_, coverBytes, contentBytes)`。单本 dav 书清缓存同走此路径（显示该书封面/内容）；确认框保持不测量（仍秒弹）。**锚点连锁**：#206（DavRename）anchor 横跨"清缓存处理结尾→隐藏方法"，故 `FormatDavCacheSize` 置于清缓存处理方法**之前**（已验无补丁锚定该处）、接缝原样保持。`MeasureDavCacheAsync`（计量-only）与网络版 `CollectDavComicFilesAsync`（预缓存仍用）未动。沙箱 238/0、`NvDavCache.cs`/`BookshelfPrecacheRunner.cs`/`FolderListBox.xaml.cs` 括号各 0/0/0、重建后三处方法源码核对一致。🚧 待实测（Windows）：右键 dav 文件夹"清除缓存"瞬间完成、Toast 显示"封面 X · 内容 Y"（大体积 GB 三位小数）；单本 dav 书清缓存同样；清后封面回退、内容重拉一切如常。⚠ 权衡：清除范围以本地缓存树为准——极端情形（某书内容已缓存、但其父文件夹目录树未缓存/陈旧且未重新浏览）可能漏清该书内容，重新浏览该文件夹刷新树后再清即可；此权衡换取"秒清除"。
- `2026-06-22` **【新功能：书签面板迁左栏(历史→书签→已读完→统计)+ 加书签自动分类「单文件/文件夹」· 235→238】**：把作者书签面板从右栏迁到左栏、位于历史与已读完之间(侧栏顺序 历史→书签→已读完→统计);全部加书签入口(Ctrl+D / 右键 / 地址栏★ / 拖拽 / 书架加入)按目标类型自动归入两个顶层书签文件夹「单文件」(本地文件 / dav 压缩包)与「文件夹」(本地目录 / dav 非压缩包),首次用到时自动新建、已存在则复用。**实现(全补丁式)**:① **改写 #98/#104**(左栏 `_defaultDocs`:#98 在历史行后插「已读完+统计」、#104 改插「书签」并把 marker 换成唯一 `魔改-书签左栏`)→ 新装/重置即得 (b) 顺序;② **新 #235** 右栏 `_defaultDocs` 删掉 `BookmarkPanel`(否则左右各一份 → `PanelsSource.ToDictionary` 重复键启动崩溃);③ **新 #236** `CustomLayoutPanelManager.Restore()` 末尾加一次性 `MigrateBookmarkToLeftDock()`——**自限**:仅当书签面板仍在右栏且不在左栏时才迁移(`Remove(bm)` 摘除 → 插到左栏「历史」之后),已在左栏(独立或与他面板同组)/浮动则不动、尊重用户后续布局;每次 Restore 后都校正一次,迁后一次保存即落定左栏、之后自然休眠;④ **新 #237** `BookmarkCollectionService` 两个公开 `Add` 重载改为先 `EnsureCategoryFolder(query)` 按类型(dav 用 `NvDavSupport.IsDavArchiveExtension`、本地用 `FileIO.DirectoryExists`)路由到对应顶层分类文件夹,无视传入 parent / 当前浏览位置;`AddTo` 底层与 `MoveToChild`/`Remove`(拖拽重排 / 删除)完全不动。书签面板 UI 全用作者原版(仅迁停靠位置,滚轮 / 右键菜单 / 视图样式等行为与在右栏时一致、无需改);书签设置(`IsSaveBookmark`/`IsSyncBookshelfEnabled`/`BookmarkFolderOrder` 等)全部保留、按要求**不加分类开关**(恒开)。沙箱 238/0、`CustomLayoutPanelManager.cs` 与 `BookmarkCollectionService.cs` 括号各 0/0/0、重建后左右栏布局 + 迁移方法 + 两个 Add 自动分类源码逐一核对一致。🚧 待实测(Windows 编译):书签面板出现在左栏「历史」与「已读完」之间且滚动正常;Ctrl+D / 右键 / ★ / 拖拽对 本地文件→进「单文件」、本地文件夹与 dav 目录→进「文件夹」、dav 压缩包→进「单文件」;老布局用户首次启动书签从右自动挪到左;移动 / 重排 / 删除书签照常。⚠ 已知小副作用:地址栏★弹窗里的「选文件夹」会被自动分类覆盖(仍按类型归类、不崩);从书架拖入某个指定书签子文件夹也会被自动归类(按「全部」口径);加书签后若当前书架视图不在该分类文件夹则新项不高亮(无崩)。
- `2026-06-22` **【按补丁序号查 bug：dav 缓存中枢 #186 通查（最大 1040 行）+ 修缓存上限原子写 · 块缓存 round-trip 确认 · 仍 235】**：按序号查 `NvDavCache.cs`（1040行，dav 缓存中枢：目录树/封面/内容块/长度/LRU/每挂载上限，被几乎所有 dav 文件依赖）。**通查、绝大部分正确**：① **块缓存磁盘 round-trip（#154 待核项）——确认正确**：WriteBlock（原子 tmp+Move、写 data.Length 精确字节、已存则只 touch LRU 不重写）↔ ReadBlock（整块精确读 + touch）；blockIndex↔字节偏移映射归 RemoteRangeStream；末块短长度照存照读；`.len`/`.tmp` 不被 `*.blk` 通配匹配（不计入/不淘汰）。② **LRU 淘汰正确**：每挂载"内存运行字节数"近似（首次 MeasurePages 基线、写块累加）、仅超上限才全盘扫描、EnforceLimit 重测自校正、按 LastAccessTime 删最旧、CleanupEmptyBookDirs 清空目录。③ **并发正确**：每书独立目录、`_enforceLock` 护计数器、块写无锁（同块并发竞态良性、数据最终正确、计数器自校正）。④ 长度缓存/HasOfflineData/ClearMount/ClearPages/ClearCovers/SuppressContentCache（AsyncLocal）都对。**修一个真实 bug**：`SaveLimits`（641行）非原子 `File.WriteAllText`——存用户自定义的每挂载缓存上限，写一半崩溃→`settings.json` 损坏→加载兜底清空→**自定义上限全丢回默认 5GB**（同 #166/#85/#99），改原子写（tmp+Move）。**其余非原子写**（SaveTree/SaveCover/SetFolderCoverAlias/SaveCachedLength）都是**可再生缓存**（损坏自动重建、无数据/配置丢失），**有意不改**（低价值）。只改 #186 一个 create 文件。沙箱 235/0、`NvDavCache.cs` 括号 0/0/0、重建后 SaveLimits 源码核对一致。🚧 待实测：dav 离线阅读（块缓存命中）、改某挂载缓存上限后重启仍在、超上限自动 LRU 淘汰、清内容缓存一切如常。
- `2026-06-22` **【按补丁序号查 bug：dav 设置页 #168 通查 + 修测试连接 HttpClient 泄漏 · 跨文件 key 一致性确认 · 仍 235】**：按序号查 `SettingPageWebDav.cs`（887行，dav 设置页 UI + 内容缓存窗 + 限速窗）。**全文通查、逻辑正确**：增删改（两态添加/确认、重复校验、更新/删除带确认框，均委托 `SetMounts`=已加密+原子写）、密码框配合加密无缝（`GetMounts` 解密成明文→密码框显示→编辑经 `SetMounts` 落盘加密）、`ContentCacheWindow`/`RequestThrottleWindow`（pending 值、确定才提交、X 关闭丢弃、clamp、随老板键隐藏/恢复）、`TestConnection`（后台 6s 超时 PROPFIND、401/404/405 友好提示）、`ClearCacheForCurrent`（清封面+复位 2048 标记）都对。**回填解决一个待核项**：跨文件限速 key 一致性——设置页 `SelectedMountUrlOrNull`→`BuildMountUrl`，限速窗经 `DavThrottle.Get/Apply(BuildMountUrl)`；运行时 `WebDavClient.ThrottleKey`→`MountKeyForPath`→也是 `BuildMountUrl`→`DavThrottle`（内部 NormKey）。**两侧同 key、确认一致，非 bug**。**修一个真实 bug**：`TestConnection` 里 `var client = new WebDavClient(...)`（line 511）测试完不释放 → 同 #156/#157/#167 族 HttpClient 泄漏（每点一次"测试连接"漏一个），改 `using var`。**顺手**：line 200/599 两处"拖动即存"注释过时（代码实为确定才提交、[检查1] 标记已是 commit-on-OK）→ 更正为"调上限·确定才存"；`int cleared`（line 566）未使用是无害警告、未动。只改 #168 一个 create 文件。沙箱 235/0、`SettingPageWebDav.cs` 括号 0/0/0、重建后 `using var client` 源码核对一致。🚧 待实测：测试连接、增删改挂载、内容缓存/限速窗、清封面一切如常。
- `2026-06-22` **【老板键恢复焦点：试"失焦兜底合成点击"→ 已回退（左键=翻页）· 仍 235】**：用户报老板键恢复偶发无键盘焦点、要手点一下。**根因（留档）**：作者 attempt4 诊断 `fg=True` 但键死 → 非前台问题，是 **WPF 逻辑键盘焦点**；NeeView 恢复时异步挪焦点（null→ListBoxItem→Grid），重试有时早于其落定 → 窗口内无焦点（全屏复显重排让落定更慢，放大问题）。曾加 `ForceFocusByClick()`（重试到底仍 `!IsKeyboardFocusWithin` 才模拟"窗口中心零位移左键单击"）兜底，但**用户左键单击=翻页**会误翻页 → **已完整回退 #75 到改动前**（无合成点击、重试仍 3 次）。⚠ 留给以后：别再用"合成左键点击"兜底（会翻页）；若再治此焦点 bug，方向仍是 WPF 焦点（可考虑右键/更长延时 + 专门把焦点重建到视图元素），且先问清用户的鼠标手势绑定。此焦点 bug 暂维持原状（偶尔手点）。
- `2026-06-21` **【按补丁序号查 bug：dav 目录列举 #167 通查 + 修 HttpClient 多路径泄漏 · 仍 235】**：按序号查 `WebDavFolderCollection.cs`（290行，dav 目录接入 NeeView 书架：缓存优先铺出 + 后台刷新）。**全文通查、逻辑正确**：InitializeItemsAsync（有缓存→立即铺出+后台刷新、无缓存→等实时一次并缓存）、StartBackgroundRefresh（取消上次→后台拉实时→有差异才回 UI 更新、`_disposedFlag`/取消双检）、SameEntries（按 Path 排序比 Path/IsDir/Length）、BuildItems（目录/压缩包分类排序、首本书设封面别名、客户端搜索过滤、排除过滤）、Dispose（取消 `_refreshCts`）、CreateDirItem/CreateArchiveItem（远程只读属性）、NvDavMountItems（挂载→盘符级项/面包屑，用 BuildMountUrl 干净 URL）都对。**修同族 HttpClient 泄漏（此处多条路径）**：`client = new WebDavClient`（48行）在**所有路径都不释放**——① 无缓存路径用完 ListAsync 不放；② 缓存+无搜索路径交后台任务但任务不放；③ 缓存+有搜索路径 client 建了没用也不放。修：用 `clientHandedOff` 标志区分"是否交后台任务接管"——StartBackgroundRefresh 的任务在 finally 释放接管的 client；InitializeItemsAsync 用 try/finally，未交接的（无缓存/缓存+搜索/解析失败/client 为 null）在 finally 释放。重导航时先取消上次 cts→旧任务取消→旧任务 finally 放旧 client，新 client 由新 Initialize 建，无跨导航泄漏；Dispose 取消 cts→任务取消→finally 放。配合本轮 #155 给 `WebDavClient` 加的 `Dispose`。只改 #167 一个 create 文件。沙箱 235/0、`WebDavFolderCollection.cs` 括号 0/0/0、重建后 finally 段源码核对一致。🚧 待实测：dav 目录浏览（首次/再访）、搜索、改文件夹后刷新、连续切换多个 dav 目录一切如常。
- `2026-06-21` **【按需求：dav 凭据 DPAPI 加密(明文落盘→密文)· 仍 235】**：应要求给 `NvDavMountStore`(#166)的 `NvDavMount.Password` 加密。做成**序列化层职责**：内存 `_mounts` 仍存明文（`ResolveCredentials`/`GetMounts`/`BuildMountUrl` 等消费方一字不改），仅**落盘时 DPAPI 加密、加载时解密**。实现：① 新增私有嵌套 `Dpapi`（crypt32 `CryptProtectData`/`CryptUnprotectData` P/Invoke + `LocalFree`，无需 NuGet 包；按当前 Windows 用户加密；DATA_BLOB 布局/签名/释放逐项核对，全 try/catch 不抛）；② `ProtectPassword`(明文→`dpapi:`+base64 密文，空串不加密，加密失败极罕见→退回明文保不丢密码) / `UnprotectPassword`(有 `dpapi:` 前缀→解密；解密失败如配置被拷到别的机器/账户→返回空需重输；无前缀→旧明文原样读入)；③ `Save` 序列化前把每个 mount 的 Password 换成密文副本（内存不动）；④ `EnsureLoaded` 解密回明文，并对"无前缀的旧明文"置迁移标志、加载后调一次 `Save()` **一次性重写为密文**。兼容旧 `WebDavMounts.json`（首次启动自动迁移）。补 `using System.Runtime.InteropServices; using System.Text;`。⚠ DPAPI 按用户/机器绑定：换机器/账户需重输密码（符合预期）。只改 #166 一个 create 文件。沙箱 235/0、`NvDavMountStore.cs` 括号 0/0/0、重建后 EnsureLoaded 迁移段/Save 加密段/Dpapi 源码核对一致。🚧 待实测：现有挂载首次启动后 `WebDavMounts.json` 里 Password 变 `dpapi:` 密文、dav 浏览/翻页/出封面照常；设置页能正常显示/改密码；删 .json 后重新加挂载也正常。
- `2026-06-21` **【按补丁序号查 bug：dav 挂载/凭据中枢 #166 通查 + 修原子写（防挂载全丢）· 仍 235】**：按序号查 `NvDavMountStore.cs`（320行，dav 配置/凭据中枢：挂载增删改查、`ResolveCredentials`/`MountKeyForPath`/`BuildMountUrl`/`IsExtAllowed`，被前面多个 dav 文件依赖）。**全文通查、逻辑正确**：GetMounts 深拷贝、SetMounts 归一化入库（Name 回退 Origin、NormalizeOrigin/RootPath）、ResolveCredentials 按 NormalizeOrigin 匹配、BuildMountUrl/MountKeyForPath/IsMountRoot/FindMountKeyFor 一致地用 `BuildMountUrl` 作 key（本文件内自洽；MountKeyForPath 仅在 needsAuth=true 即 dav 源被调、CDN 直链不 throttle，故无 CDN-URL 错配）、NormalizeOrigin（补 http://、去尾斜杠）/NormalizeRootPath（补前斜杠、去尾斜杠）都对。**修一个真实数据丢失 bug**：`Save()`（76行）原非原子 `File.WriteAllText`——与 #85/#99/#155 同类，但这是**凭据+配置中枢**：写一半遇崩溃→`WebDavMounts.json` 损坏→下次加载失败→`_mounts` 清空→**所有挂载（名称/地址/根路径/账号密码）全丢、需重加并重输密码**。修原子写（先写 `.tmp` 再 `File.Move(tmp,FilePath,true)`）；`SetExtensionsText`（145行，后缀白名单文本）同样裸写，低危但顺手一致化。🔒 **记一个安全提示（非 bug、未改）**：`NvDavMount.Password` 明文序列化进 `WebDavMounts.json`（无 DPAPI/加密）——改用 DPAPI 会机器绑定（破坏跨机拷贝）+ 需迁移旧明文，属设计取舍，留待定夺。只改 #166 一个 create 文件。沙箱 235/0、`NvDavMountStore.cs` 括号 0/0/0、重建后 Save 源码核对一致。🚧 待实测：dav 挂载增删改、改后重启仍在、按 origin 解析凭据、限速 key 一切如常。
- `2026-06-21` **【按补丁序号查 bug：dav 流式 PDF #157 通查 + 修 HttpClient/部分失败资源泄漏 · 仍 235】**：按序号查 `NvDavPdfiumArchive.cs`（482行，dav PDF 流式读取：绕过 PdfiumViewer 直接 P/Invoke pdfium.dll 的 `FPDF_LoadCustomDocument` + 读块回调挂到 #154 `RemoteRangeStream`，实现"翻到哪下到哪"）。**全文通查、逻辑正确**：`GetBlock` 回调（读满 size 或失败返 0；32 位 m_FileLen 对 <4GB PDF 足够）、`EnsureInit`（让 PdfiumViewer 当唯一库拥有者、绝不自行 Init/Destroy）、`PdfiumLock`（intern 同一 GUID 与 PdfiumViewer 全局串行，绝不并发踩非线程安全的 PDFium）、渲染（LockBits→FPDFBitmap_CreateEx 在锁定位上→FillRect 白底→LoadPage→RenderPageBitmap→ClosePage/Destroy/UnlockBits 全在 finally 逐层释放）、GetEntries/OpenStream（Task.Run + `_lock` + EnsureOpen + 渲染到 MemoryStream）都对。**修与 #156 同族的资源泄漏（在 #157 更不完整）**：① `Dispose` 原 `_client = null` 不释放 HttpClient（连接池/socket 滞留到 GC）；② `EnsureOpen` 失败清理不全——GetLength 失败 rethrow 漏放 `_client`，native 加载失败的内层 catch 只 `Free` 了 GCHandle、漏放 `_stream`+`_client`（且若 `FPDF_GetPageCount` 在 load 成功后抛则 `_doc` 也漏关）。修：抽 `CleanupNative()`（关 doc[PdfiumLock 内]→松 GCHandle→放 `_stream`→放 `_client`，幂等、须持 `_lock`），让 `Dispose` 与 `EnsureOpen` 两个失败点统一共用——既释放 HttpClient（配合本轮 #155 给 `WebDavClient` 加的 `Dispose`），又补全部分失败回滚（避免重试覆盖旧引用造成孤立泄漏）。doc 先关→pdfium 停用流与回调，故随后松回调/放流安全；幂等可重复调用。只改 #157 一个 create 文件。沙箱 235/0、`NvDavPdfiumArchive.cs` 括号 0/0/0、重建后 `CleanupNative`/`Dispose` 源码核对一致。🚧 待实测：dav PDF 浏览、翻页、出封面、连续开关多本 dav PDF 一切如常。
- `2026-06-21` **【按补丁序号查 bug：dav 流式 zip #156 通查 + 修 HttpClient 资源泄漏 · 仍 235】**：进入 dav 压缩档读取，按序号查 `NvDavZipArchive.cs`（573行，把 #154 `RemoteRangeStream` + #155 `WebDavClient` 组装成"流式读 zip"，明文走 .NET ZipArchive、加密走 SharpCompress + mod01 密码池的 hybrid）。**全文通查、逻辑大体正确**：`NvDavSupport`（IsDavPath / 扩展名白名单 / TrySplitDavArchive 首压缩包段切分 / Parse URL 解析）、EnsureOpen 懒打开顺序（凭据回退→client→blockStore→GetLength 在线/离线缓存长度回退→建流→开 zip）、加密探测（LeaveStreamOpen 一次性 SharpCompress 探 IsEncrypted、失败当明文）、明文/加密双路、GetEntries/OpenStream 的 Id 一致性（SharpCompress＝过滤后索引、.NET＝全列表索引，各自 OpenStream 用同列表；目录 OpenStream 抛、Id 无关）、OpenStream 复制到 MemoryStream 后返回（锁内读完即释放锁）都对。**确认一个非 bug**：RawEntryName 分隔符 .NET 路径用 `/`（＝本地 ZipArchive）、SharpCompress 路径用 `\`（＝Susie/7z）——NeeView 本就混用、下游归一化，两者皆合法。**修一个真实资源泄漏（常见路径）**：`EnsureOpen` 每开一本 dav 书都 `new WebDavClient`（各持一个 HttpClient），但 `Dispose` 只 `_client = null`、从不释放 → 每开关一本 dav 档滞留一个 HttpClient（连接池/socket）到 GC，长时间浏览大量 dav 档累积、极端下可致 socket/端口紧张。修：① 给 `WebDavClient`（#155）加 `IDisposable`+`Dispose`（释放内部 HttpClient）；② `NvDavZipArchive`（#156）的 `Dispose` 释放 `_client`；③ 顺带 `EnsureOpen` 失败 catch 里释放已建的 `_zip`/`_sharpZip`/`_stream`/`_client` 并置 null，避免部分失败后重试（`_opened` 仍 false）覆盖旧引用造成孤立泄漏。`_stream` 先于 `_client` 释放 + #154 已加释放检查 → 在途读会先抛、不再碰 `_client`，安全；每书独有 client、无共享；NeeView 仅在淘汰/关闭时调 Dispose（缓存期间不调）。改 #155+#156 两个 create 文件。沙箱 235/0、两文件括号 0/0/0、重建后 Dispose 源码核对一致。🚧 待实测：dav 明文/加密 zip 浏览、翻页、出封面、长时间连续开关多本 dav 档一切如常（资源释放对功能无影响）。
- `2026-06-21` **【按补丁序号查 bug：WebDAV 网络层 #155 通查 + throttle.json 原子写一致化 · 仍 235】**：按序号查 `WebDavClient.cs`（574行，WebDAV 网络层主体：PROPFIND/GET/Range/302跳转/直链缓存/重试，含实现 #154 `IRangeFetcher` 的 `WebDavRangeFetcher` 与限速器 `DavThrottle`）。**全文通查，WebDAV 网络层（dav 最易出错处）整体正确**：① ctor（`AllowAutoRedirect=false` 手动处理 3xx、`AutomaticDecompression=None` 字节范围必须关压缩、Basic 认证 UTF-8 base64、115 CDN 浏览器 UA）、`BuildUrl`（逐段 `Uri.EscapeDataString` 兼容中文/空格、http(s) 直链原样透传）都对；② `ResolveAndProbe`/`Probe`/`ProbeLengthOpenEnded`（206 只信 Content-Range 总长、200 才用 ContentLength；开放区间探长用 ResponseHeadersRead 只读头不下 body；递归 depth≤4 有界）正确；③ `FetchRange`（读满 count 或 EOF 截断、redirect 重发同 offset 绝对 Range、count 由 GetBlock 钳过不超长）正确；④ `ListAsync` PROPFIND（XML 命名空间、isDir＝collection 或尾斜杠、size/name 解析回退）、`MoveAsync`、路径 helper（`GetUriPath`+`DecodePath` 单次解码）都对；⑤ `WebDavRangeFetcher`（锁内解析、直链过期清 `_resolvedUrl` 重解析重试一次）、`DavThrottle`（时隙预留 ReserveSlot 锁内/Wait 锁外无死锁、每挂载独立闸、NormKey 规范化）正确。**记 3 个设计权衡（非 bug）**：FetchRange 不校验响应 206（服务器忽略 Range 回 200 时 offset>0 取错字节，但 count 上限防爆下载、后果是 zip 打不开非静默损坏；用户 Alist/115/WebDAV 均支持 Range）、ListAsync 多 propstat 拆分只取第一个（对 Alist 全在一个 200 propstat 无影响）、body 流读无显式超时（受网络约束）。**修一个真实（低危）的一致化项**：`throttle.json` 写盘（`DavThrottle.Apply` 568行）原是非原子 `File.WriteAllText`，与 #85/#99 同类——写一半遇崩溃→损坏→下次加载失败→限速设置丢失（回退默认 4/2）。虽 Apply 仅在用户改限速时调用（极少）、数据 trivial，但为一致化补成原子写（先写 `.tmp` 再 `File.Move(__tmp,f,true)`，仍在 `_ioLock` 内）。只改 #155 一个 create 文件。沙箱 235/0、`WebDavClient.cs` 括号 0/0/0、重建后 Apply 写盘段源码核对一致。🚧 待实测：dav 浏览/翻页/出封面/重命名一切如常；设置页改限速→保存→重启限速值仍在。
- `2026-06-21` **【按补丁序号查 bug：dav Range 流 #154 通查 + 补释放检查 · 仍 235】**：进入 dav 高危簇，按序号查 `RemoteRangeStream.cs`（178行，基于 HTTP Range 的可寻址只读流，dav 所有压缩档流式读取的最底层地基）。**全文通查、核心逻辑正确**：`Read` 的多块边界（用「跨块读 / 末块部分读」具体例子验证：`toRead=min(count,remaining)` 限定不越界、`blockOffset` 恒 < `block.Length`、chunk≥1 不死循环、末块 `len=length-start` 正确）、LRU 缓存（命中移队首、`while count>max` 从队尾逐出、`_cache`/`_lru` 始终同步）、Seek/Position/Length、整数运算（`blockIndex*(long)_blockSize` 无溢出）全对；并发上类注释明确「ZipArchive 由调用方加锁」，GetBlock 锁外取网络的重复 fetch 竞态在串行调用下不可达。**补一个真实（虽小）的释放后缺陷**：`_disposed` 字段在 Dispose 里置位却**从不被检查**（作者显然想检查但漏了）。后果：dav 慢网下若在缩略图/页面加载完成前就翻走该书，archive 被 Dispose、缓存清空，但残留的后台读仍进 `Read→GetBlock`→未命中→**重新发起网络 fetch（为已离开的书重下块）**，或 fetcher 已释放时抛混乱异常。修：Read 开头补 `if (_disposed) throw new ObjectDisposedException(...)`（Stream 标准做法，完成作者本意 + 杜绝释放后无谓网络重取；`_disposed` 在 Dispose 末尾才置位，只影响释放后新发起的 Read、不影响释放中正在进行的读）。⚠ 行为变化：释放后再读由「静默重取」变为抛 `ObjectDisposedException`——本是调用方误用（用已释放的流）、结果也已被丢弃（已翻走），NeeView 加载路径有 try/catch 兜底。只改 #154 一个 create 文件。沙箱 235/0、`RemoteRangeStream.cs` 括号 0/0/0、重建后 Read 源码核对一致。📌 记一个待核（非 bug）：GetBlock 对网络 fetch 做了长度归一化（119-124行），但磁盘块（`TryRead`）未归一化——依赖 `NvDavBlockStore` 忠实 round-trip（Write 前已归一化），留到查 #186 块缓存时核对。🚧 待实测：dav 压缩档浏览/翻页/出封面一切如常；慢网下加载中途翻走不再为旧书重下块。
- `2026-06-21` **【按补丁序号查 bug：已读完面板 #95-96 通查 + 修 ctor 启动崩溃隐患 · 仍 235】**：按序号查已读完侧边面板（`ReadFinishedPanel` 46行 + `ReadFinishedView` 678行）。**逻辑通查、整体正确**：列表重建（身份驱动从 ReadProgressStore 取、排除文件夹型、搜索过滤、按读完/最后访问排序）、封面优先级链（SelfPage 实时文件→Dav→高清库→160px 小图→空，全懒加载+try）、动作（打开/标记未读/删除记录，多选快照后重建）、右键选中逻辑、更多菜单（Update 返回同实例只刷勾选）都对；封面抓取走 DispatcherTimer＝UI 线程、`HasCoverHiRes` 双闸防重做；ctor 订阅的都是自有对象事件、无外部全局订阅→重建无泄漏。**修一个与自身注释矛盾的启动崩溃隐患**：`ReadFinishedPanel` ctor 注释明写"绝不让构造抛异常拖垮启动"，但代码两处会抛——① `App.Current.MainWindow.Resources[…]`，`MainWindow` 为 null 时 `.Resources` 直接 NRE（早于图标回退链）；② 两个图标都缺时 `?? throw` 显式抛。面板由 SidePanelFactory 在布局初始化时构造，抛异常可拖垮侧栏/启动。现状（MainWindow 已建、标准图标都在）不触发，但违背契约、对未来改动（图标改名/启动顺序变）脆弱。修为全程 null 守卫 + 空图（`new DrawingImage()`）兜底，绝不抛（正常路径行为不变，仅错误路径从崩溃改为空白图标）。只改 #95 一个 create 文件。沙箱 235/0、`ReadFinishedPanel.cs` 括号 0/0/0、重建后 ctor 源码核对一致。📌 另记两个未修项（非 bug）：① 面板的视图样式/排序/显示开关 5 个设置不持久化、重启重置（实现持久化属补功能 + 动 config schema、风险大，留待定夺）；② `ReadFinishedView` 327 行注释 stale（说"有封面的 GetPage 返回 null"，但实际只要文件在就返回非 null——而 Thumbnail 链本就 SelfPage 优先、无功能影响，纯注释过时）。🚧 待实测：已读完面板正常打开、列表/封面/排序/打开一切如常。
- `2026-06-21` **【按补丁序号查 bug：阅读统计 #99 通查 + 修原子写（防统计全丢）· 仍 235】**：按序号查 `ReadingStatsStore.cs`（666行，阅读时长统计聚合 + 持久化）。**全文通查，计时/冷静期/聚合/合并导入逻辑都正确**：Tick 采样（全屏+非隐藏+非挂机才计）、新书 60s 冷静期转正、`_data.Books` 访问基本在 `_lock` 内、同书识别（名+页数+大小±5MB 容差）、`ImportJson` 合并（时长/次数相加、取较早 First、较小 FinTicks）都对。**确认一个 concurrency 非问题**：`Save(true)` 在 7 处锁外调用（NoteProgress/SetHidden/RemoveBook/UpdatePaths/SetCover/ImportJson/ClearAll），曾疑与锁内写并发序列化 `_data`；但核实所有写入方——Tick/OnBookChanged（UI 定时器/事件）、NoteProgress（由 BookMementoControl 翻页流程）、SetCover（由 StatisticsView 的 DispatcherTimer，注释明确"编码在 UI 线程"）、StatisticsView 按钮、ReadingBackup——**全在 UI 线程、无真并发**，故锁外序列化当前安全，不擅改锁结构。**修一个真实持久化健壮性 bug（同 #85，可致全部阅读统计丢失）**：`Save()` 原用 `File.WriteAllText(FilePath,…)` 直接覆盖写＝非原子，写到一半遇崩溃/断电 → 统计文件损坏 → 下次反序列化失败 → `_data` 清空 → 全部阅读时长/排行/封面/读完记录丢失。修为**原子写**：先写 `.tmp` 再 `File.Move(tmp, FilePath, overwrite:true)`（throttle 不变，仍每 60s 最多一次非强制保存）。`Export`（写用户选定路径的一次性导出）仍裸写，但 live 数据不受影响、优先级低，暂不动。只改 #99 一个 create 文件。沙箱 235/0、`ReadingStatsStore.cs` 括号 0/0/0、重建后 `Save` 源码核对一致。🚧 待实测：正常阅读累计时长、统计面板排行/柱状图/封面一切如常（原子写对正常路径行为不变）。
- `2026-06-21` **【按补丁序号查 bug：续读进度 #85 通查 + 修原子写（防进度全丢） · 仍 235】**：按序号查 `ReadProgressStore.cs`（479行，续读进度持久化 + 身份计算）。**全文通查、并发锁与逻辑都很扎实**：身份 `IdOf`=去后缀名+字节大小、`_idMemo` 缓存、dav 长度未缓存(-1)时返 null 不 memo（待长度落盘后能重算）；所有 `_books` 访问一律在 `_lock` 内、`IdOf`（含文件 I/O）在锁外用 ConcurrentDictionary memo（id 由路径算、与 `_books` 无关）；`Record` 先读旧值再 `GetOrCreate`（与 old 同对象）改、`Sticky` 黏性只增不减、从 key 用 `LastIndexOf(SEP)` 解析大小（SEP=`\u001f` 控制字符、正常文件名不含）都正确。记两个**设计权衡（非 bug）**：`_idMemo` 从不失效（文件大小变了 id 会 stale，但漫画大小稳定）、同名（去后缀）+同字节大小的两本不同书会身份碰撞（换路径保进度的代价，概率极低）。**修一个真实持久化健壮性 bug（可致全部阅读进度丢失）**：`Save()` 原用 `File.WriteAllText(FilePath,…)` 直接覆盖写＝非原子（先截断再写），**写到一半遇崩溃/断电 → 文件损坏 → 下次反序列化失败 → catch 里 `_books` 清空 → 续读位置/百分比/读完标记全丢**；而 `Save` 在每次关书时都调，长期累积"写一半遇崩溃/断电"概率不可忽略，后果是该功能全部数据。修为业界标准**原子写**：先写 `.tmp` 再 `File.Move(tmp, FilePath, overwrite:true)`（同卷＝原子 rename 替换），崩溃发生在写 tmp 阶段时原文件完好；顺带把 `MigrateOld` 里同样的裸 `WriteAllText` 也走 `Save()`（原子＋去重）。`File.Move(string,string,bool)` 是 .NET Core 3.0+ API、.NET 9 有；进度 JSON 存本地配置目录（非 dav）→本地卷 Move 原子。被锁时新旧都失败但新版不截断原文件（严格更优）。只改 #85 一个 create 文件。沙箱 235/0、`ReadProgressStore.cs` 括号 0/0/0、重建后 `Save`/`MigrateOld` 源码核对一致。🚧 待实测：正常阅读→关书→重开，续读位置/进度%/已读完面板一切如常（原子写对正常路径行为不变）。
- `2026-06-21` **【按补丁序号查 bug：老板键 #75 通查 + 修 1 真 bug + 关遗留击键日志 · 仍 235】**：按序号查 `BossKeyHotKey.cs`（513行，全局热键 Alt+X 隐藏/恢复 + Win32 抢前台补焦点）。**整体通查、Win32 interop 与状态机基本干净**：`OpenSettingWindow` 防重（已有设置窗只 Activate 不新建）、`Initialize` 在 `SourceInitialized` 后调（句柄必存在、不漏注册）、`RestoreAuxWindows` 经 `ReengageInputFocus` 每次恢复都调且清空后幂等、Dispose 正确注销热键+RemoveHook+停表+退订、抢前台全 try/catch+finally 还原前台锁超时、全屏恢复钩子一次性自摘+5s 兜底、RestoreDavPlace 有界 4 轮+隐藏检查。**修 1 个真 bug + 关 1 个遗留调试开关**：① **HideAuxWindows 重入守卫**——`SuspendAsync` 在 `await LockAsync` **之后**才置 `IsHideWindow=true`（AppState.cs:88-92）；若恢复(ShowWindow)仍占锁时用户在恢复中急按两次 Alt+X，第一次 SuspendAsync 阻塞在锁上（IsHideWindow 还 false）、第二次按键仍走隐藏路径 → `HideAuxWindows` 跑两次：第二次 `Clear()` 丢掉原始位置、把已移到屏外(-32000)的窗记成 (-32000,-32000) → 恢复时辅助窗永久留屏外；而移屏不改 Visibility 是为保模态状态，故**丢的若是模态确认框会在屏外锁死主窗、程序看着像卡死**。修：`HideAuxWindows` 开头 `if (_hiddenAuxWindows.Count > 0) return;`（列表已有记录＝上次隐藏前置工作仍生效→直接返回、绝不重记；无弹窗时 Count 恒 0、双调无害；每次恢复 RestoreAuxWindows 清空列表→不跨周期误持久）。推演确认有害的只有 HideAuxWindows，状态重存那几行在第二次跑时 SuspendAsync 主体还没执行、book/place 未清、存的仍是有效值。② **关遗留击键日志**——`EnableDiagLog` 原 `true` 是诊断"恢复后键盘/滚轮失灵"焦点 bug 用的临时开关（该 bug 注释写明已于 2026-06-05 attempt6 实测修复），没关回 → 每次恢复后 15s 内把每个按键/滚轮追加进 `%TEMP%\nv_boss.log`（无界增长 + 记录击键）。改 `false`（只改值、不动含多重反斜杠的注释以避转义风险；`Log`/`DiagInput` 都 `if(!EnableDiagLog)return`→纯日志、无行为副作用；若隐藏后键盘/滚轮再失灵，改回 true 重现定位）。只改 #75 一个 create 文件。沙箱 235/0、`BossKeyHotKey.cs` 括号 0/0/0、重建后两处源码字符级核对一致。⚠ 注：EnableDiagLog 那行注释措辞（"打开日志…修好后改回 false"）略 stale，但值现为 false、与"改回 false"一致。🚧 待实测：① 正常老板键 Alt+X 隐藏/恢复一切如常、键盘滚轮可用；② `%TEMP%\nv_boss.log` 不再增长。
- `2026-06-21` **【按补丁序号查 bug：菜单簇 #50-59 通查 + 修「持久重复菜单项」bug · 仍 235】**：回填序号最低未查簇——书架右键菜单编辑器簇。**#50-59 六个 create 文件全部通查、无 live bug**：拖放树编辑器 `TreeView_Drop` 的「先 `Remove(dragged)` 再 `IndexOf(hit)`」顺序经多例验证无 off-by-one（IndexOf 在移除后算、反映当前位置）；`IsSelfOrDescendant` 正确挡住拖进自身/子孙；多选与拖拽互斥（普通点击先清多选）；每个变更操作都调 `SaveToConfig`；`BookshelfMenuNode.ToMenuItem` 从活动 `Children` 重建而非 stale `Source.Children`、Rename 写回 `Source.Name` 两者一致；`CommandTable.BuildMap` 的 Items/DavItems 重叠 ID 信息完全一致（后写覆盖无害）；对话框/`InsertLineAdorner` 渲染无误。**在 `BookshelfConfig.cs` 的 `ContextMenuItems` getter 里发现并修一个真 bug（持久重复菜单项）**：迁移补项用 `List.Exists`/`FindIndex`/`RemoveAll` **只查顶层、不递归进分组 Children**——用户把「自定义封面 CustomCover」（或 PrecacheFolder）拖进某分组后，下次读配置顶层浅查找不到 → 在顶层**又补一份** → 重复项；更糟：手动删掉顶层那份，下次启动浅查仍找不到 → **又补回 → 持久重复、删不掉**。**修法**：getter 体顶部加两个静态局部函数 `HasIdDeep`（递归存在性，含分组）/`RemoveIdsDeep`（递归移除），三处浅查（PrecacheFolder/CustomCover 存在性 + ClearDavCache/DavRename 清理）全改递归版。getter 由 #141/#197/#214 三个分层 replace 补丁叠成，只改各补丁里「后续补丁 anchor 不覆盖」的行（Insert 行、ClearDavCache-ensure 块原样保留），不断链。沙箱 235/0、`BookshelfConfig.cs` 括号 0/0/0、重建后 getter 字符级核对一致。⚠ 注：本修只**停止再生**、不自动清已有重复——若菜单里已有历史重复的 CustomCover，手删顶层那份即可永久生效（不再被补回）。🚧 待实测：把 CustomCover 拖进一个分组 → 重启 NeeView → 顶层不再多出一个 CustomCover。📌 另记一个待查跨区域隐患：dav 菜单按「挂载URL」做 key，编辑器传入的 `_davMountKey` 与菜单构建时查表 key 若因 URL 规范化（尾斜杠/大小写/转义）不一致，会导致编辑的 dav 菜单不生效——留到查 WebDAV 设置簇 #168 时验证。
- `2026-06-21` **【按补丁序号分段查 bug：预缓存簇 #64/#65，修进度浮窗 2 个真 bug · 仍 235】**：按"AI 代码 bug 率偏高、一轮一个大区域、按补丁序号、opus 模式"做系统排查，这轮查预缓存簇。**`BookshelfPrecacheRunner.cs`(#64, 898行)全文通查无 live bug**——仅记一处死代码隐患：本地管线 `RunCoreAsync` 第 55 行已把 dav 路径分流到 `RunDavIncrementalAsync`，本地文件枚举不会产出 dav:// 路径 → `isDav` 在本地管线恒 false → 133 行那段「dav 封面用 `page.Thumbnail.ImageSource` 保存」(我在 `ProcessDavBookAsync` 已修为同步 `CreateImageSource()` 的旧坏版)永不执行，是 RunDavIncrementalAsync 拆出前的残留；不影响运行，暂不动(将来若改分发会变真 bug)。**`PrecacheProgressWindow.cs`(#65, 413行)找到并修 2 个真 bug**：**① 拖动保存修**——隐藏态把右下角浮条拖到新位置后不持久化、下次最小化跳回旧位置。根因：WPF `DragMove()` 阻塞到松开、且会吞掉随后的 `MouseLeftButtonUp`，而保存位置的 `SaveTrackedPosition()` 只在 `OnMouseLeftButtonUp`(176行)里调用 → 拖动后永不触发。修：`DragMove()` 返回后(拖动确已结束)直接 `if(_isMinimized) SaveTrackedPosition()`，并手动复位 `_pressed/_dragging`(纯单击的"点击恢复"走没调 DragMove 的路径、MouseLeftButtonUp 正常触发，不受影响)。**② 泄漏修**——点「隐藏」后预缓存恰在 `BeginInvoke(Loaded)` 回调执行前完成关窗时：`StartTrackingOwner` 延迟回调在已 `CloseSafe/OnClosed` 的死窗口上跑、把死窗口订阅到主窗 Location/Size/StateChanged → 死窗口被主窗事件钩住泄漏 + 主窗每次移动都在死窗口上触发 `ApplyTrackedPosition`。修：`StartTrackingOwner` 开头 `if(_closed) return;`。只改 #65 一个 create 文件。沙箱 235/0、`PrecacheProgressWindow.cs` 括号 0/0/0、两处重建后源码字符级一致。🚧 待实测：① 隐藏态拖动浮条到新位置 → 恢复再隐藏，浮条停在拖动后的位置(不跳回);② 反复「隐藏→预缓存秒完成」不再积累隐藏的死窗口、主窗移动无异常。
- `2026-06-21` **【dav 文件夹右键「清除缓存」确认框秒开(去掉弹框前的预测量) · 仍 235】**:用户报 dav 文件夹右键清缓存时确认框弹出特别慢(文件多时)。**根因**:`ClearDavCacheCommand_Execute`(FolderListBox.xaml.cs 的 replace 补丁)在弹确认框**前** `await MeasureDavCacheAsync(path)` 量缓存大小——而它调 `CollectDavComicFilesAsync` 递归枚举夹内全部书 + 逐个 `GetBookCacheBytes` stat 缓存目录,文件多就卡;而且清完后的 Toast 本就会报实际释放量。**修法**:去掉确认框前的 `__clearSz`/`MeasureDavCacheAsync`/`__clearSzText` 三行测量,确认框改为通用文案「将清除此文件夹的缓存,确定?」**立即弹出**;释放大小仍由点确定后 `ClearDavFolderCacheAsync` 返回、清完的 Toast「已清除 N 个文件,释放 X」给出。只改 `FolderListBox.xaml.cs` 一处 replace 补丁的 text(解码→改→按 _encode 转义在 raw 外科替换、round-trip 一致);`MeasureDavCacheAsync` 方法体保留(现无人调、无害)。沙箱 235/0、语法 OK、FolderListBox.xaml.cs 括号全平衡。🚧 待实测:右键 dav 文件夹「清除缓存」→ 确认框**瞬间弹出**(不再卡),点确定后照常清、Toast 报释放量。
- `2026-06-21` **【预缓存完成框去「注意」行 + 失败清单 txt 末尾附纯文件名 · 仍 235】**:① 用户不要 dav 完成框那行「注意:有 X 本封面…可能 115 风控/Alist 离线…」——删掉 `RunDavIncrementalAsync` 完成框报告里两处 `if(c.Failed>0||c.ListFailed>0){report+="\n注意:…"}`(完成 + 取消两分支),只留第一行计数;失败明细仍可点「查看失败」看。② 「查看失败」导出的 txt 末尾追加一段「==== 失败封面(纯文件名)====」——每本失败书只列文件名(`LastIndexOf('/')`+`UnescapeDataString`,不带路径、无缩进无空行),方便直接复制(原有「文件名+完整路径」明细段保留)。只改 `BookshelfPrecacheRunner.cs`。沙箱 235/0、括号 0/0/0、语法 OK。
- `2026-06-21` **【dav 封面优先级:原图(2048)＞小图(512) · 仅 dav · 仍 235】**:用户要 dav 封面“原图优先”——① 跑「预缓存封面(小图512)」时,已有 2048 封面的本**跳过当已完成、且不降级**(保持标 2048);② 跑「预缓存原图封面(2048)」时,对有 512 小图的本,**生成 2048 后删掉那张 512**。**调研确认原来无此逻辑**:`ProcessDavBookAsync` 原先无条件 `SetResolution(resolution)`、只查「本档」`HasCover(davUrl,resolution)`(512 预缓存只看有没有 512、不看 2048)、存完不删它档。**改两个 create 文件**:① `NvDavCache.cs` 新增 `DeleteCover(davUrl, resolution)`(删单档 `<hash>.<res>.jpg`,区别于 `ClearCover` 删全部档;File.Delete+catch 幂等);② `BookshelfPrecacheRunner.cs` 的 `ProcessDavBookAsync` 三处插入:(a) 顶部——`resolution==512 && HasCover(davUrl,2048)` → 标 2048 + `c.Skipped++` + return;(b) 已缓存跳过块内——`resolution==2048` 时 `DeleteCover(davUrl,512)`;(c) 生成存好后——`resolution==2048` 时 `DeleteCover(davUrl,512)`。入口确认:line667 `Run(path)`=小图512、line680 `Run(path,2048)`=原图。六种档位组合全推演正确。**仅 dav**(改的是 ProcessDavBookAsync、只 dav 走;本地走 RunCoreAsync 内联循环、未动——用户明确“本地不存小图、不管”)。并发安全(per-book 文件、File.Delete/Exists 无共享态、SetResolution 加锁)。沙箱 235/0、两文件括号全平衡、patches.py 语法 OK、DeleteCover 已定义、三处插入到位。🚧 待实测:① 对已预缓存原图的夹再跑「预缓存封面」→ 那些书秒跳过、封面仍是 2048(没被降成小图);② 对有小图的夹跑「预缓存原图封面」→ 完成后 covers 里对应书的 `.512.jpg` 消失、只剩 `.2048.jpg`。
- `2026-06-21` **【预缓存进度窗收尾修 + WebDAV「设置 ▾」选中才可点 · 仍 235】**:
  **④ 老板键隐藏→恢复后完成,进度窗残留 + 取消无概括 → 修**:根因 = 完成块用 `if(window.IsVisible)window.Close()`,但 `PrecacheProgressWindow` 订阅 `AppState.IsHideWindow`、隐藏时 `Visibility=Collapsed`(IsVisible=false)→ close 被跳过 → 恢复后窗口又冒出来、必须手点「取消」才消失。**修法**:窗口加幂等线程安全 `CloseSafe()`(不看 Visibility、`_closed` 去重、自动切 UI 线程),Runner 里 4 处 `if(IsVisible)Close()` 全换 `CloseSafe()` → 完成无论隐藏与否都真关。**取消概括**:Cancel 按钮原 `_cts.Cancel();Close()` 直接消失;改为只 `_cts.Cancel()+OnCancelRequested()`(置灰两按钮 + 显示「正在取消…」,`_cancelling` 让 `Report` 不再覆盖该字样),关窗 + 概括交给 Runner——在**计数仍在作用域的两个管线里 `catch(OperationCanceledException)`**(置 `cancelled`),分支出「已取消。已处理 …」概括框(本地=成功/跳过;dav=新生成/跳过/失败 + 失败附注),复用 `ShowPrecacheReport`(隐藏态仍推迟到恢复再弹)。`Parallel.ForEachAsync` 取消抛 OCE(非聚合)故简单 catch 即可。
  **③ WebDAV「设置 ▾」改为选中挂载才可点**:原 `settingsButton` 是局部变量、注释明写“始终可点、不进 UpdateButtonStates”(那是上一版“不选也能点”的决定)→ 现反转:改字段 `_settingsButton` + 加进 `UpdateButtonStates`(`IsEnabled=hasSel`),未选中挂载时置灰。下拉里 4 项(右键菜单/清除封面/内容缓存/高级选项)本就都是 **per-mount**(每个 dav 挂载独立,line131 注释已确认),故“选中才可点”语义正确;子项 handler 内仍各自校验兜底。沙箱 235/0、三文件(PrecacheProgressWindow / BookshelfPrecacheRunner / SettingPageWebDav)括号全平衡、patches.py 语法 OK、Runner 零 `if(window.IsVisible)` 残留、`_settingsButton` 已入 UpdateButtonStates。🚧 待实测:④ 老板键隐藏态预缓存→恢复后进度窗**自动消失**(不用手点取消)、点取消弹「已取消。已处理…」概括框;③ 未选中 dav 时「设置 ▾」灰、选中后亮。
- `2026-06-21` **【预缓存双修:②老板键隐藏不弹完成框 + ④删书后重拉失败自愈 · 仍 235】**:
  **② 老板键隐藏时完成框照样弹(bug)→ 修**:`BookshelfPrecacheRunner.cs` 新增 `RunWhenVisible(Action)`——完成时若 `AppState.Current.IsHideWindow` 为真则**不弹**,订阅 `AppState.PropertyChanged`、等恢复显示(IsHideWindow→false)那一刻再 `AppDispatcher.BeginInvoke` 弹(一次性退订);否则立即弹。dav/本地完成框与 NoFiles 框都改走它(dav/本地完成框统一抽到 `ShowPrecacheReport(report,failedBooks,failedDirs)`,内含「查看失败」循环 + RunWhenVisible)。封面刷新 `RefreshVisibleDavFolderCovers` 不弹窗、隐藏态照常先做。
  **④ 删书后重拉仍显示失败(大夹不自愈)→ 修**:根因=预缓存按「每文件夹目录树缓存」逐层走,该缓存只在「浏览进入那个文件夹」时后台重列刷新;1000 本夹通常带子文件夹,删的书在没点进去的子文件夹里→其树缓存仍列着已删的书→预缓存钻进去试鬼书→404 失败(小扁平夹因打开即整层刷新故能自愈)。**修法**:`DavPrecacheCounters` 加并发安全 `FailedParents`(authority,serverPath);`WalkDavAsync` 在本层书 `Parallel.ForEachAsync` 前后快照 `c.Failed`,增量>0 则把本层 `(schemeAuthority,serverPath)` 记入(与 `SaveTree` 键精确同源);完成时 `InvalidateFailedParents` 去重 `ClearTree` 这些目录 → **下次重拉只对「有书失败的那几个文件夹」重新 PROPFIND 列举**(已删的书消失=不再失败;真·风控失败的重列后再试一次)。只动失败文件夹、不是整夹,风控压力小;无轻量 HEAD 接口故不逐本探 404。沙箱 235/0、`BookshelfPrecacheRunner.cs` 括号 417/216/9、`ReadingStatsStore.cs` 168 brace 全平衡、patches.py 语法 OK、注册结果 = Command/ReadFinished/WebDav/PosterWall。🚧 待实测:② 隐藏态预缓存完不弹、恢复显示才弹;④ 删一本书后重拉显示全完成(失败父目录已自动重列)。
- `2026-06-21` **【魔改·预缓存 · dav 完成框文字精简 + 「查看失败」导出失败书籍 txt · 仍 235】**:用户要 ① dav 预缓存完成框首行改成「新生成封面0本·跳过已缓存1777本·失败1本。」(去「dav 预缓存完成:」前缀 + 去空格,中点 U+00B7);② 完成框「确定」左边加「查看失败」按钮;③ 点它导出 txt(失败书籍文件名 + 完整路径),保存位置自选。**改 `BookshelfPrecacheRunner.cs`(create)六处**:(a) `DavPrecacheCounters` 加并发安全 `ConcurrentBag<string> FailedBooks/FailedDirs`;(b) 书失败处 `c.FailedBooks.Add(davUrl)`、(c) 列目录失败处 `c.FailedDirs.Add(schemeAuthority+serverPath)`(并发用 Interlocked,故用 ConcurrentBag);(d) 报告首行改简;(e) 完成框用 `MessageDialog.Commands` 加 `UICommand("PrecacheThumbnail.ViewFailed"){Alignment=Left}`+OK、`while(true)` 循环:点查看失败→`ExportFailedList`→`continue` 弹回(取消保存也不丢),点确定/关闭→break;(f) 新增 `ExportFailedList`:`Microsoft.Win32.SaveFileDialog` 选位置 → 写 UTF-8(BOM)txt(头部计数 + 每本「文件名/缩进完整路径」+ 列不出目录;`Uri.UnescapeDataString` 还原 URL 编码)。**只在有失败时显示该按钮**;无失败=原默认 OK。**restext 加 1 键** `PrecacheThumbnail.ViewFailed`(zh=查看失败 / en=View failures),塞进现有两条 append、不增补丁数。`UICommand`/`UICommands`/`UICommandAlignment` 同 NeeView 命名空间、新类型全限定无需加 using。沙箱 235/0、`BookshelfPrecacheRunner.cs` 括号 387/194/9 全平衡、patches.py 语法 OK。🚧 待实测:① 完成框首行=简版;② 有失败时「确定」左边出现「查看失败」;③ 点它弹保存框选位置、导出 txt 含失败书名+完整路径、导出后完成框弹回可再点确定;④ 无失败时只有「确定」。**注**:报告第二行「注意:…可能 115 风控/Alist 离线…」保留未动(与「查看失败」互补)。本地(非 dav)预缓存完成框未改(本地基本不失败)。
- `2026-06-21` **【魔改26 · 等高整齐(justified)行高上限 400→1000、Ctrl+滚轮步进 20→40 · 不增条(235)· 🚧 待实测】**:用户实测 v8 不卡了,但「等高整齐」最大仍每排 6 张单图、不及海报墙(masonry 3 列)大。根因=justified 目标行高=`PosterWallTileWidth`,被**输入端**卡在 [140,400](面板自身 MaxRowHeight 本就 600,但 Ctrl+滚轮与设置滑杆只到 400)→ 竖封面宽=400×0.7≈280、屏宽÷280≈6 张/排。**抬三处上限到 1000**(竖封面宽≈700→约 3 张/排=海报墙 3 列那么大;刻意不到「2 张/排」的 ~1200 阈值,避免封面过大上采样发糊):① 面板 `MaxRowHeight` 600→1000;② Ctrl+滚轮 justified 分支钳 400→1000、步进 20→40(范围变大、少空滚);③ 设置页「封面行高」滑杆 `Maximum` 400→1000、初值取值钳 400→1000。**只影响 justified**(masonry 用 `PosterWallColumns` 不受影响)。沙箱 235/0、两 CREATE 文件括号全平衡。🚧 待实测:等高整齐 Ctrl+滚轮/滑杆能拉到约 3 张/排(接近海报墙最大)。**注**:justified 实际大小随「每排张数」阶跃(6→5→4→3 张分别在行高 ~400/480/600/800 处变),滑杆/滚轮在阈值之间挪动可能暂无可见变化属正常;再大(2 张/排)会明显上采样糊,故未再放开。**本条数字取代 §4 魔改19/26 里旧的「140~400」表述。**
- `2026-06-21` **【魔改26 v8 · 海报墙改「虚拟化版 masonry」根治 1000 本卡顿 + 防抖 · 不增条(235)· 🚧 待实测·高风险】**:v7 不虚拟化视觉对但 1000 本卡爆(整夹全实体化:加载 O(n²)、任何宽度/列数变化全量重排 1000 项 → 开夹/F11/侧栏/缩放全卡)。用户在 A(VWP 行式·稳但非 masonry)/B(自绘虚拟化 masonry·理想但有风险)间**选 B + 加 C 防抖**。重写 `NvPosterWallPanel : VirtualizingPanel, IScrollInfo`(布局算法对全部项算 x/y/w/h 不变;只实体化可视 ±半屏、WPF 标准 generator、清理按真实索引、线性扫描可视范围、退化兜底不掉书;`VirtualizationMode=Standard` 关回收焊死「竖封面变宽」;`SetVerticalOffset→InvalidateMeasure`;`OnItemsChanged`/`BringIndexIntoView`/`MakeVisible`;`MarkLayoutDirty` 改 `DispatcherTimer 150ms` throttle 防抖)。**XAML 不改**(IsVirtualizing/CanContentScroll 沿用继承,VirtualizationMode 代码里压 Standard)。固有小瑕疵:未滚到的宽封面用默认比例估算、滚入时轻微 reflow。沙箱 235/0、括号全平衡、三接缝核过。⚠ **自绘虚拟化=与出过 bug 的 v6 同源、沙箱无 WPF 无法验证、极可能再迭代 1 轮**;回退路线=方案 A(VWP)。详见 §4 魔改26 顶部 v8 banner 与测试清单。
- `2026-06-21` **【编译修复 · `PosterWallTileWidth` 是 double 非 int · CS0266 · 仍 235】**:用户编译报 `FolderListBox.xaml.cs(78,33): CS0266 无法将 double 隐式转换为 int`。海报墙 v6 的 Ctrl+滚轮"等高整齐"分支把 `PosterWallTileWidth`(SystemConfig 声明为 **`double`**)读进了 `int w`。全仓核实:该属性除此处外(ViewModel `PosterWallItemSize`、设置页滑块 `(int)Value` 回写、面板 `_rowHeight` 都是 double)一律按 double 用;`PosterWallColumns`/`PosterWallGap` 才是 int(读进 int 无误)。修法:第 78 行 `int w` → `double w`,后续 `Math.Min/Max(..,140,400)`/`w=220`/回写属性全自然走 double,值仍是整数、行为不变。沙箱 235/0。🚧 待编译通过验证。(另:编译还有 2 个 `CS8604` nullable 警告在 `CustomCoverPicker:438` / `ArchivePageThumbnail:58`,均既存警告、非错误、不阻断编译。)
- `2026-06-21` **【设置归一 · WebDAV 页 4 按钮收进「设置 ▾」下拉 · 仍 235 · 🚧 待实测】**:用户要 WebDAV 设置页底部按钮行更清爽、且方便后续扩展——把「右键菜单 / 清除封面 / 内容缓存 / 高级选项」4 个独立按钮收进一个**始终可点的「设置 ▾」下拉按钮**(左键点开 ContextMenu,4 个 MenuItem 各调原 handler)。按钮行从 8 个减到 5 个:添加 · 更新 · 删除 · 测试 · **设置 ▾**。**关键点**:① 设置按钮**不进 `UpdateButtonStates`**=不随挂载选中态置灰、永远可点(用户明确要"不选择某个 dav 也能点");② 这 4 项目前都是 **per-mount**(需选中挂载),故在各自 handler 里自校验——`内容缓存`/`高级选项`/`清除封面` 本就有"未选中→`SetHint` 提示",`右键菜单`(`OpenDavMenuEditDialog`)原是静默 `return`、本次补上同样的提示;③ 改 `SettingPageWebDav.cs` 一个 create 文件:删 4 个 `Button?` 字段 + 4 段构建 + `UpdateButtonStates` 里 4 行置灰,新增 `settingsButton`/`settingsMenu`(局部变量、不占字段)+ 4 个 `MenuItem`,左键 `settingsMenu.PlacementTarget=settingsButton; Placement=Bottom; IsOpen=true`(不赋 `button.ContextMenu`、故右键不重复弹;菜单被 Click 闭包持有不被 GC)。`ContextMenu`/`MenuItem` 在已 import 的 `System.Windows.Controls`、`PlacementMode` 用全限定名。4 个 handler 原样保留、4 个旧字段全仓零残引用(已断言)。沙箱 `0ab0c48b0` **235/0**、`SettingPageWebDav.cs` 剥注释/串后代码括号 ()/{}/[] = 446/446·189/189·15/15 全平衡。🚧 **待 Windows 实测**:① 底部只剩 5 个按钮、最后是「设置 ▾」;② 点它弹出含 右键菜单/清除封面/内容缓存/高级选项 的下拉;③ 未选中挂载时点这 4 项任一 → 页面提示"请先选中…"而非无反应/报错;④ 选中挂载后点各项 → 与原按钮行为一致。**后续扩展**:往 `settingsMenu` 再 `Add` 个 `MenuItem` 即可、无需动按钮行。菜单项「清除封面」沿用原功能名(清的是封面缓存),想改 label 可说。
- `2026-06-21` **【魔改26/预缓存 · 串行→有界并发(仿浏览)· 两条预缓存功能(封面512/原图2048)共用 · 仍 235 · 🚧 待实测】**:把「预缓存封面」与「预缓存原图封面」从**严格串行**(`foreach{await 单本}`,每本=解直链→下载→解码→存→`await DelayGap(150ms)` 全跑完才下一本)改为**有界并发**,机制对齐浏览。**根因(用户诊断、代码证实)**:浏览用 NeeView `JobEngine`(`JobWorkerSize=12`)**12 路并发**生成可见封面 → 把 `DavThrottle` 的「解直链 2/s」闸**打满**、下载延迟被并发掩盖 ≈ **2 封面/s**;预缓存串行 → 同一时刻只 1 个解链在飞、要等上一本整段网络往返结束才发下一个 → **填不满 2/s** + 每本多 150ms ≈ **~1/s**(2/s 闸根本不是瓶颈、串行延迟才是)。**改法**:① 本地 `RunCoreAsync`、dav `WalkDavAsync` 的逐本循环改 `Parallel.ForEachAsync`(`MaxDegreeOfParallelism`:本地 `LocalParallel=8`、dav `DavParallel=8`,**用户设 8**;dav 的 8 是无害余量——解直链仍被 2/s 闸卡死、突破不了,只是允许更多下载在后台重叠);**dav 子目录递归仍串行**(本层书并发、跑完才进下层 → 在途数 ≤ N、有界);② 计数器全改 `Interlocked.Increment`(本地 done/success/skipped + dav `c.*` 四个);③ 删掉 dav per-book `DelayGap`(`DavThrottle` 已把解直链卡在 2/s=唯一风控敏感步骤、再 sleep 是多余串行延迟、会把吞吐压回 ~1/s;PROPFIND 后那个 DelayGap 保留)。**风控不变**:`DavThrottle.GetDownload` 是全局/每挂载单闸、N 个并发任务抢的还是同一个 2/s 时隙 → **并发突破不了 2/s 解链上限**(115 直链 API 请求率不变)、并发只是把被串行浪费的额度补满+让下载重叠;唯一不限的 FetchRange 是 CDN 字节流(非 115 直链请求、并发 6 条对 CDN 无碍)。**预期**:dav 预缓存 ~1/s → 满额 ~2/s(约翻倍、向浏览看齐);本地多核解码也并发提速。**线程安全(全仓核实、非假设)**:① `Report` 自带 `Dispatcher.CheckAccess→BeginInvoke` marshal;② `HiResCoverStore.SetResolution/RemoveResolution` 全程 `lock`;③ `NvDavCache` 封面落地=**per-book 文件**(`Hash(book).512/2048.jpg`)、`HasCover`=只读 `File.Exists`、`SaveCover`=`CreateDirectory`+`WriteAllBytes` 无共享内存态;④ `SetFolderCoverAlias`/`SaveTree`/`LoadTree` 在串行 walker;⑤ 本地档 `IsCacheEnabled=true` 写共享 `Cache.db`、`ThumbnailCache` 用 `Lock`+`_lockSaveQueue`(序列化落盘队列)全锁 → 并发写安全(浏览 12 路本就这么写);⑥ 封面/缩略图生成本就被浏览 12 worker 并发调用=线程安全;⑦ `ArchiveKey.SuppressDialog` 在并发区**之外**设/还原(非逐本态)。**故本次只有计数器需 Interlocked、其余皆已安全**。两条功能(`Run(path)`=512 / `Run(path,2048)`=2048)共用此运行器、`resolution` 透传 → 一处改动两功能同覆盖。取消流程不变:被取消的本在 body 内 catch OCE 撤标记后 throw → 经 `ForEachAsync` 以 OCE 冒泡 → `Run` 的 `catch(OperationCanceledException)` 收(`ForEachAsync` body 只会抛 OCE、非 OCE 被 `catch{ok=false}` 吞)。沙箱纯净 `0ab0c48b0` **235/0 零失配**、`BookshelfPrecacheRunner.cs` 剥注释/字符串后**代码**括号 ()/{}/[] = 337/337·172/172·9/9 全平衡、`Parallel.ForEachAsync`=2 / 残留 `DelayGap` 调用=1(PROPFIND 那个)/ `Interlocked.Increment`=7。🚧 **待 Windows 实测**:① dav 预缓存明显变快(NvDavLog 看解链间隔应稳定 ~500ms=2/s 被打满、不再每本间隔上千 ms);② 「预缓存封面」「预缓存原图封面」**两个**都生效且都更快;③ 进度/取消仍正常、计数(成功/跳过/失败)准确;④ 风控不升(解链仍 ≤2/s);⑤ 本地大文件夹预缓存多核提速、Cache.db 不损坏。**可调项(未做、可选)**:`DavParallel`/`LocalParallel` 现为常量,需要的话可在 WebDAV 高级选项里加一格「预缓存并发数」滑杆。
- `2026-06-20` **【新增·魔改26 海报墙「无缝布局(封面按真实宽高比变宽)」· 234→235,+1 create】**:把海报墙固定等宽格子(宽:高锁死 1:1.42 → 双/三页宽封面被 `Uniform` 缩成扁条+上下黑边、单图也因比例对不上露左右深色底 `#1A1A1E`)改为「justified 瀑布流」——统一封面高度 H(=`PosterWallTileWidth`×1.42,跟随原 Ctrl+滚轮缩放)、**宽度=H×封面真实宽高比**,封面用圆角 `ImageBrush`/`UniformToFill` 填满格子=**零黑边**(格子已按比例匹配,UniformToFill 只在子像素失配时裁极细丝、绝不 letterbox);竖封面占窄格、宽封面自然占宽格(方向 A,宽封面提前到位)。**新建 `_Mod/NvPosterWall.cs`**:`NvPosterWallPanel : VirtualizingWrapPanel, IItemSizeProvider`(`AllowDifferentSizedItems=true`/`StretchItems=false`〔变尺寸下 Stretch 会横向变形〕/`SpacingMode=Uniform`〔每排剩余空间均匀成间距=尽量填满〕),`GetSizeForItem` 只读缓存封面高+`FolderItem.PosterAspect` 字段=**O(1) 极轻**(12 万本逐项调用仍流畅,绝不读 `Thumbnail.ImageSource` 触发异步加载);+ `PosterAspectWatcher` 附加属性挂可见封面上,封面加载后(`IThumbnail.IsValid&&IsUniqueImage`+`BitmapSource.Pixel*`)把真实比例写回 `PosterAspect` 并 `InvalidateMeasure` 重排(只可见项、无额外开销;占位图标跳过)。缩放/书名设置变化经面板订阅 `SystemConfig.PropertyChanged` 触发重排(幂等订阅防 Loaded 多次)。改 3 条既有 text:[120] xaml 封面 `<Image Uniform Margin=3>`→圆角 `ImageBrush UniformToFill`+watcher(暗底占位 Border 保留)、[121] xaml 面板 `<vwp:VirtualizingWrapPanel ItemSize=…>`→`<local:NvPosterWallPanel/>`、[87] `FolderItem` 加 `public double PosterAspect`。**VWP v2.5.1 关键事实(逐一核对源码)**:设 `ItemSizeProvider` 后 measure/arrange 子容器用 **provider 尺寸**约束(`container.Measure(upfrontKnownItemSize)`)→ DockPanel(Stretch)撑满、封面 Grid 正好 coverW×H、`UniformToFill` 填满不塌缩;provider 非空时直接调 `GetSizeForItem` 不走脏缓存(改比例只需 `InvalidateMeasure`);`ItemSize`(原绑定)非空会让 VWP 忽略 provider → 绝不能设,故 `PosterWallItemSize` 绑定移除(留定义=死代码、不报错、不删〔删中间补丁偏移索引〕)。沙箱纯净 `0ab0c48b0` **235/0 零失配**、`NvPosterWall.cs` 状态机括号 ()/{}/[] 全 0、`_pack.py` 整包断言过(235 条/37 create)。🚧 **沙箱无 WPF 无法编译**,务必 Windows 实测:① 单图封面无左右黑边、占满圆角格;② 双/三页宽封面按真实比例横向占宽(不再扁条);③ Ctrl+滚轮缩放仍生效且重排;④ 末排会均匀摊开/居中(SpacingMode=Uniform 所致,想左对齐可把面板里 `SpacingMode=Uniform`→`None`)。**【2026-06-20 用户实测崩溃→已修】**:首版把 VWP 开关(`AllowDifferentSizedItems`/`ItemSizeProvider` 等)设在**构造函数**里 → 启动恢复海报墙样式实例化此面板时 splash 闪退、主界面没出来。根因=VWP 基类 `Items => ItemContainerGenerator.Items`、而 generator「首次访问 `InternalChildren` 前为 null、访问即抛 `InvalidOperationException`」,`AllowDifferentSizedItems` 的 handler 会访问 `Items.Count`,构造时面板没挂到 ListBox 故必崩。**修=四个开关从 ctor 挪到首次 `MeasureOverride`**(`_configured` 标志只设一次;先 `_ = InternalChildren` 建好 generator 再设)。沙箱 235/0、配平 0。 **【2026-06-20 第二次实测·封面塌成横线+行距巨大→已修】**:崩溃修好后能启动,但海报墙所有封面塌成满格宽~0高的横条、行距巨大(dav/本地都是)。根因=[120] 把封面 `<Image>` 换成了 `ImageBrush`(作 Border 背景)而 **ImageBrush 无固有尺寸** → 变尺寸 VWP 下容器 DesiredSize 塌、与 provider 尺寸错位 → 布局崩(原 mod19 用 `<Image>` 正常)。**修**:① [120] 封面改回 `<Image Stretch="UniformToFill">`(给容器固有/填充尺寸=匹配 provider;格子已按比例 → 填满无黑边、几乎不裁);② VWP 开关配置从「measure 进行中(base 之前)」挪到「首次 `MeasureOverride` 的 base 之后 + `OnLoaded`」(`EnsureConfigured` 幂等;避免在 measure 中改 AffectsMeasure 致 provider 不生效)。**教训:变尺寸 VWP 的封面必须用 `<Image>`(有固有尺寸)、不能用 `ImageBrush`/`<Border Background>`(无固有尺寸→容器塌)**。圆角暂失(Image 矩形,待布局确认 OK 再加 clip)。沙箱 235/0、配平 0。**完整详情见 §4 魔改26**。
- `2026-06-21` **【魔改26 v6 · 整体改版 masonry 自绘虚拟化 · 不增条(235)· 🚧 待实测】**:弃 VWP justified、自写 `NvPosterWallPanel : VirtualizingPanel, IScrollInfo`(列式瀑布流 + 跨列单/双/三图 + 线性扫描虚拟化 + 像素滚动)。Ctrl+滚轮改调**列数** `PosterWallColumns`(3~12,新 `SystemConfig` 字段)、模板 margin/圆角→0 无缝。详见 §4 魔改26 顶部 v6 banner。
- `2026-06-21` **【魔改26 v6 · 二次审查·修 3 处 · 仍 235 · 🚧 待实测】**:① **回收模式适配(重要)**——书架 ListBox 是 `VirtualizationMode=Recycling`(FolderListBox.xaml L344),原 `CleanupContainers` 用 `generator.Remove`(Standard 语义)违背回收契约 → 改为按宿主模式分支:Recycling 时 `((IRecyclingItemContainerGenerator)generator).Recycle(pos,1)`、否则 `Remove`(否则可能滚动卡顿/容器泄漏)。② **键盘定位**——`BringIndexIntoView` 设偏移后补 `UpdateLayout()` 同步实体化目标容器,否则框架取容器设焦点时容器还没建好 → Home/End/方向键跳不到视口外项。③ **真·无缝(去 1px 栅格线)**——基础 `NVListBoxItem` 模板的内层 `Bd` 边框硬编码 `BorderThickness=1`(样式改 BorderThickness 无效),会把封面内缩 1px → 瓦片间露 1px 暗线;给 `ListBoxItemPosterWallStyle` 覆盖一个**无边框 ControlTemplate**(ContentPresenter 直接撑满 + 选中态用「叠在封面上的 2px 描边 `PwSelBd`」不内缩不挡点击),hover 仍由 DataTemplate 的 PosterHover 负责。沙箱 235/0、面板括号 70/231/38 全平衡、XAML 标签配平。
- `2026-06-21` **【魔改26 v6 · 加布局 A(等高整齐 justified)+ 设置里自由切换 · 仍 235 · 🚧 待实测】**:海报墙现支持**两种排版**,设置→海报墙→「布局/排版方式」下拉自由切换(也可 Ctrl+滚轮分模式缩放):**瀑布流 masonry**(原 v6,封面保大、错落、竖向少量空隙、大小=列数)/ **等高整齐 justified**(布局 A:每行等高、行内变宽缩放撑满整行=横竖全无缝,代价是某些行被压小、大小=封面行高)。① 面板 `NvPosterWallPanel`:`ComputeLayout` 拆成按 `_justified` 分派 `ComputeMasonry`/`ComputeJustified`(+`AspectAt` 取比例助手);justified 算法=累加封面真实宽高比到「行宽(按目标行高)≥视口宽」收行、非末行按 `rowH=视口宽/Σaspect` 整体缩放使行宽=视口宽(末项吸附右边消浮点缝)、末行不放大左对齐;封面格宽高比=真实比例→`UniformToFill` 不裁无黑;`_y` 随行单调(线性扫描虚拟化照常);布局缓存键加 `_justified`/`_rowHeight`。② `SystemConfig` 新增 `PosterWallJustified`(bool 默认 false=瀑布流)。③ Ctrl+滚轮(FolderListBox.xaml.cs)**按模式分支**:justified 调 `PosterWallTileWidth`(140~400=行高,上滚变大)、masonry 调 `PosterWallColumns`(3~12)。④ 设置页 `PosterWallSettingPage` 加「排版方式」下拉(ComboBox)+「列数(瀑布流)」滑杆(3~12→PosterWallColumns);原「海报大小」滑杆改标「封面行高(等高整齐)」(140~400→PosterWallTileWidth)。两套大小控件各管一种模式,改另一模式参数只触发一次无害空重排。沙箱 235/0、面板括号 79/265/43 平衡、设置页 58/89/1 平衡。
- `2026-06-21` **【魔改26 v6 · 加封面间距(0~5px)+ 缝隙=空界面黑 · 仍 235 · 🚧 待实测】**:海报墙新增**封面间距** `PosterWallGap`(0~5px,设置→海报墙→大小→「封面间距」滑杆;**默认 0=与之前无缝完全一致**)。① 面板两种布局都按间距排版:masonry 列宽=`(视口宽-(列-1)*gap)/列`、跨列瓦片宽并入被跨列间距、x=`列序*(列宽+gap)`、同列下一张上方留 gap、extent 取真实内容底(不含尾部 gap);justified 收行阈值与缩放都扣掉行内 `(n-1)*gap`、`rowH=(视口宽-(n-1)*gap)/Σaspect`、列间/行间各加 gap、末项仍吸附右边界。**gap=0 时两种算法逐字退化回原无缝实现**(已验证)。布局缓存键加 `_gap`、监听 `PosterWallGap`。② **缝隙底色**:`PosterWallCenterHost` 宿主 Border 背景由硬编码 `#101012` 改为 `SetResourceReference(Window.Background)`——`Window.Background` 深色主题=纯黑 `#FF000000`,正是"没开书时主视图(透明)露出的窗口背景那个黑";故缝隙与空界面同一个黑、且随主题切换(浅色主题=白)。ListBox/面板均透明,底色直接透到宿主。顺手删了该文件不再使用的 `using System.Windows.Media;`。③ `SystemConfig` 新增 `PosterWallGap`(int 0~5 默认0)。④ 设置页加「封面间距」滑杆(0~5px→PosterWallGap)。**注意:开书点击/双击/键盘一律未改**(用户澄清:要的是"缝隙=纯黑死区"的观感,不是禁用点击打开)。沙箱 235/0、面板括号 81/281/41 平衡、设置页 70/107 平衡。
- `2026-06-20` **【上游同步 `764fea1a7`→`0ab0c48b0`(tag `46.0-alpha.7`,8 提交)· 重锚 4 条 · 仍 234】**:用户流程 = 每次 clone 最新上游 + `build.py` 打补丁,故「更新」= 把补丁重锚到最新上游(让下次 clone 最新代码再打补丁能干净跑通)。上游 8 提交(起动日志强化 #1951 / 封面优先文件名改正则 #1949 / 内容1行时标签专用行 #1952 / 拖文件激活窗口设置 #1945 / **书架项菜单缩略图移到顶部+菜单快捷键 #1950** / **书架项加文件属性 #1955** / 资源整理 / 书签文件夹颜色改属性对话框)只撞 `FolderListBox.xaml.cs` 上 4 条,其余 230 条干净。**重锚处理**:① **[mod07 右键菜单编辑器 #54]** 它整段替换的「上游硬编码菜单」被 #1950/#1955 重写 → 改锚到新 `else if (item.IsFileSystem())` 分支体(替换为 `BuildBookshelfContextMenu(contextMenu, item, selectedItem)`;System/Bookmark/Empty 三分支保持上游不动);② **[mod23 dav 重命名 命令定义 #204 + 绑定 #205]** 原锚点尾部带着上游 `EditTagColorCommand`(被 #1952「颜色设置改属性对话框」移除)→ 改锚 mod 自己的 `ClearDavCacheCommand`(脱离一切上游可变行;定义行注释踩了**全/半角括号**坑〔实际半角 `(dav 文件夹:…)`〕、改从原补丁精确提取);③ **[mod06 隐藏菜单项 #44]** 本是「垫脚」——其输出只为成为 mod07 锚点的一部分、随即被 mod07 整段替换掉,隐藏功能实际来自配置默认菜单 `BookshelfMenuDefault` 的 `Command("Hide")` 项;原锚点(`menu.Items.Add(RegenerateThumbnail)…`)上游已无 → **改成锚菜单方法签名行、加一条迁移记录注释**(在 mod07 替换区之外、不冲突);**保留此条不删,以维持 PATCHES 索引稳定**——本包历来只往末尾追加、MD 里大量 `[N]`/`PATCHES[N]` 引用都靠索引不变,删中间一条会让 ≥45 全部偏 1(并撞 `_pack.py` 索引断言)。已确认**无任何 mod 代码引用被上游删掉的 `EditTagColorCommand`/`EditTagColor_Executed`**。沙箱纯净 `0ab0c48b0` **234/0 零失配**(自写内存检查器〔顺序应用全部补丁、失配不停而收集全部〕+ `build.py --patch-only` 双验)、`FolderListBox.xaml.cs` 完整状态机括号配平 ()/{}/[] 全 0。⚠ **待用户 clone `0ab0c48b0` + `build.py` 编译实测**:① 整体编译通过;② 书架右键菜单(你自定义的那套)正常、「隐藏」项在;③ dav 重命名正常;④ 海报墙/书架显示正常(上游 #1952「内容1行标签专用行」与 mod19 海报墙模板共存无碍)。**注**:上游 #1949「封面优先文件名改正则」会影响封面选哪张图,属上游行为非冲突;#1955 新增的「文件属性」菜单项不在 mod07 配置菜单里(mod07 是你的自定义菜单,要的话可在菜单编辑器里另加)。 〔**2026-06-20 编译实测续**〕用户 `build.py --pull` 到 `0ab0c48b0`：还原→pull→打补丁 **234/0 全过**，但 MSBuild 编译报 **1 个 C# 错 CS1503**：`CustomCoverPicker.cs`[176] 调 `ArchiveEntryUtility.CreateFirstImageArchiveEntryAsync` 第二参从 `string` 变 `IStringMatch?`（上游 #1949「封面优先文件名改正则」重构：`BookThumbnailFileName` 字符串精确匹配 → `BookThumbnailRegex` 正则 + `RegexStringMatch` 包成 `IStringMatch?`；旧 `BookThumbnailFileName` getter 现返回 null=即便能编译也是坏的）。已照上游 `ArchivePageUtility` 同写法修：`var regex = Config.Current.Book.GetBookThumbnailRegex(); IStringMatch? match = regex is not null ? new RegexStringMatch(regex) : null;` 传 `match`。沙箱 234/0 + `CustomCoverPicker.cs` 配平 0/0/0。**教训**：沙箱「补丁干净打上 + 括号配平」**检测不到上游改方法签名这类编译错**——上游同步后务必提醒用户编译实测、首轮编译错多半是上游 API 变。已确认上游本次**仅此一处 public 签名变**波及 mod（`CreateAsync`/`CreateTemporaryEntry` 未动，`PictureFileExtensionTools`/`FileSystem` mod 未调）。〕
- `2026-06-20` **【新增·魔改19 海报墙「显示书名 + 行数 + 海报大小」独立设置页 · 233→234,+1 create】**:新建 `_Mod/PosterWallSettingPage.cs`(避开废弃同名)原生 `SettingPage`:「书名」(显示书名开关 + 行数 1-5)、「海报」(大小 140-400)。书名**封面下方独立一行**(用户选,默认 ON 2 行);`SystemConfig` 加 `PosterWallShowName`/`PosterWallNameLines` + 计算属性 `PosterWallNameAreaHeight`,模板根 `Grid`→`DockPanel`(书名 Border 停底、高绑 NameAreaHeight、关时=0),`PosterCap` 悬停浮名绑 inverse-ShowName。改 6 条 text([116][117][123][122][120][172])+ 1 create。沙箱 234/0、4 .cs 配平、XAML 良构。🚧 待实测。**完整详情见 §4 魔改19 v5.8**。
- `2026-06-20` **【dav 发送点并发安全全仓审计 + 补硬两处 · 改 PATCHES[155] text、仍 233 · 🚧 待实测】**:用户担心「同时多个文件夹预缓存 / 预缓存时又打开一本真实的书 → 并行突破服务器 2/s 下载地址上限」。**全仓审计结论**:① 全仓**只有 WebDavClient.cs(PATCHES[155])一个文件**对 dav 服务器发 HTTP(其它任何文件都不绕开它直接联网),单一咽喉。② `DavThrottle.Listing` / `DavThrottle.Download` 是 `static readonly` **全局单例闸**,时隙 `_nextTicks` 在 `lock` 内原子递增、等待在锁外——所以**无论同时开几个预缓存 + 还在读书,所有 resolve 抢同一个 Download 闸的时隙,全局合起来永远 ≤ 2/s,并行不可能突破**(用户担心的 bug 不存在)。六个发送点最终归属:ResolveAndProbe(解析直链=115 直链 API)→Download 2/s ✅;ListAsync(PROPFIND)→Listing 4/s ✅;Probe / ProbeLengthOpenEnded(探长度)→已 302 到 CDN 时不占、仍打源时占 Download ✅(见补硬①);FetchRange(读字节)→CDN/OSS 字节流**故意不限**(可达同款,字节流不算下载地址请求);MoveAsync(MOVE 重命名)→Listing 4/s ✅(见补硬②)。**补硬①**(Probe / ProbeLengthOpenEnded):原来只在 ResolveAndProbe 入口占一次 Download 时隙,但若**服务器不 302、直接吐文件**(needsAuth=true,打到 Alist 源),这两个探测就是额外的 115 请求却没占时隙。加 `if (needsAuth) DavThrottle.Download.Wait(token)`——仅当仍命中源才占,已 302 到 CDN(needsAuth=false)不占,**对 Alist→115 正常流程(必 302)零影响**,纯为「任何服务器都不漏」兜底。**补硬②**(MoveAsync):重命名走 115 API、原来没挂闸(手动单次、人手速度到不了 2/s,本非并发风险),为完整性也挂上 Listing 闸(用列表时隙、不占宝贵的下载时隙;代价≈0)。**最终覆盖**:每一个会打到 115 API 的请求(解析 / 探测打源 / 列目录 / 重命名)都过全局闸,唯一不限的 FetchRange 是 CDN 字节流(非 115 直链请求)。沙箱 `764fea1a7` 233/0、WebDavClient.cs 完整状态机(含 $" 插值)配平 ()/{}/[] 全 0、Download.Wait=3 / Listing.WaitAsync=2。🚧 待 Windows 实测:① 同时右键多个文件夹预缓存 + 翻书,观察是否仍稳在 2/s 不裂图(NvDavLog 可看请求时间间隔);② 重命名功能仍正常。**附带说明(非 bug,是设计权衡)**:全局闸是「先到先得」,所以**前台翻书的 resolve 会和后台预缓存抢同一个 2/s**——你正在看的书可能排在后台封面后面等时隙(之前提的「该给前台更高优先级」那条仍待做)。这是「不超限」的代价,不是超限 bug。
   - `2026-06-20` **【修取消/失败留下脏 2048 分辨率标记 · 改 PATCHES[64] text、仍 233 · 🚧 待实测】**:两个会导致「浏览未真正缓存的书却按 2048 现取(慢+风控/重解码)」的脏标记问题。**根因**:`HiResCoverStore` 的分辨率档标记在生成封面前就预标,若之后没成功存封面又没撤标记,就留下「标了 2048 没图」。**修法**:① **dav**(ProcessDavBookAsync):原来 `catch (OperationCanceledException) { throw; }` 直接重抛、跳过了底部的 `RemoveResolution` → 取消瞬间在飞的那本留脏标记。改为 catch OCE 里 `if (!ok) RemoveResolution(davUrl)` 再 throw(本档封面没成功存才撤;若取消发生在 SaveCoverImage 之后/DelayGap 中则 ok=true、标记正确保留)。② **本地**(RunCoreAsync):原来**一上来批量** `SetResolution(files, resolution)` 预标所有文件(取消后没处理到的也带 2048 标记)、且**失败的本不撤标记**(本地循环只 success++/skipped++、无 RemoveResolution)。改为**逐本标记**(循环里处理到该本才 `SetResolution(new[]{file})`,与 dav 一致)+ **取消/失败都撤标记**(catch OCE `if(!ok)` 撤、else 失败分支撤)。**效果**:对 dav/本地文件夹做 2048 预缓存后中途取消,再浏览——已成功的本=大图(缓存秒出),没处理到的本=小图(正常现取、不会误按 2048 重拉),失败的本=回退小图。沙箱 `764fea1a7` 233/0、BookshelfPrecacheRunner.cs 完整状态机(含 $" 插值)配平 ()/{}/[] 全 0。🚧 待 Windows 实测:① dav 2048 预缓存跑一半取消 → 浏览时没缓存到的书显示小图、不卡不风控;② 本地同上;③ 失败(加密没解开)的本浏览显示小图而非黑图/2048 重拉。
- `2026-06-20` **dav 请求限速器初版(硬编码 4/2,仿可达阅读器缓解 115 风控)**:`WebDavClient.cs[155]` 内加静态 `DavThrottle`(`Listing`/`Download` 两闸,预留时隙式、等待锁外无死锁、同步 `Wait`+异步 `WaitAsync`);`ListAsync` PROPFIND 前过 Listing(4/s)、`ResolveAndProbe` 命中 Alist 源的 GET 前过 Download(2/s,=限「每秒开几个新文件」,之后 CDN range 字节读不限故不拖慢单本)。**下条做成可调 UI**。
   - `2026-06-20` **【dav 请求限速做成可调 UI（设置页按钮 + 双滑块窗口，各 1-10，持久化）· 跨 3 文件改 text、仍 233 · 🚧 待实测】**：把上一条硬编码的 4/2 限速做成用户可调。WebDAV 设置页按钮行加【高级选项】按钮 → 弹双滑块窗口（`RequestThrottleWindow`，仿 `ContentCacheWindow`）：上滑块「每秒最大目录加载请求数」、下滑块「每秒最大下载地址请求数」，各 **1-10**（`Slider` Min=1/Max=10/IsSnapToTickEnabled=true）、按「确定」才提交（点 X 不保存）、初始填当前值、`AppState.IsHideWindow` 隐藏/显示。**做成全局一套**（115 按账号风控：你多个 dav 项目大概率走同一 Alist→同一 115 账号，做成每项目各 2/s 反而让总速率超账号上限=错；按钮不强制选中项，窗口头部注明全局生效）。**持久化**：`DavThrottle` 加常量 `RateMin=1`/`RateMax=10`、`ListingPerSecond`/`DownloadPerSecond`（private set，默认 4/2）、`ThrottleDto{Listing,Download}`、`SettingFile()` 指向 `<WebDavCache>/throttle.json`（catch 回退 temp）；静态构造改为**读盘**（Math.Clamp 夹 1-10，无文件默认仍 4/2）；新增 `public static void Apply(int,int)`（夹 1-10 → 两闸 SetPerSecond → lock 内 WriteAllText 持久化）。`NvDavCache` 暴露 `public static string SettingRoot => Root;` 供 throttle.json 定位。改 3 个 create 文件 text（`WebDavClient.cs`[155] +2142、`SettingPageWebDav.cs`[168] +6510、`NvDavCache.cs`[186] +112）、不增条、不增文件。沙箱 `764fea1a7` **233/0**、三文件完整状态机（含逐字串 @ 与插值串 $）配平 ()/{}/[] 全 0、`DavThrottle.Apply`=1 / `RequestThrottleWindow`=1 / 按钮 Click=1。🚧 待 Windows 实测：① 设置页【高级选项】按钮弹窗、双滑块拖动、确定后即时生效；② 重启 NeeView 后设置被记住（读 throttle.json）；③ 改小到 1/1 后刷书架/缓封面更稳但更慢、改大到 10/10 更快但风控风险升。（后续：按用户要求按钮改名「高级选项」、窗口内文字精简为一句风控提醒+两个滑块标签，去掉底部长注释）
   - `2026-06-20` 【dav 限速改为「每挂载独立」+ 高级选项按钮没选中置灰 · 跨 3 文件改 text、仍 234 · 🚧 待实测】：把上一条「全局一套」改成**每个挂载各自独立限速**（用户多挂载对应不同 115 账号/不同 WebDAV 根，需各自限速互不影响）。**挂载 key = 完整挂载身份**（origin + WebDAV 根 = `NvDavMountStore.BuildMountUrl(m)`，**与按挂载右键菜单同一个 key**；同地址但根/账号不同 = 不同挂载、各一套限速）。改动：① `DavThrottle`[155] 从两个全局闸 `Listing`/`Download` 改为 `ConcurrentDictionary<string,Gate>` 按挂载 key 懒建闸 + `ConcurrentDictionary<string,int[]>` 存每挂载速率值；新增 `Get(key)`（回显）/`GetListing(key)`/`GetDownload(key)`/`Apply(key,li,dl)`（夹 1-10→更值+两闸→整表写盘）；静态构造读 `throttle.json` 为 `{挂载key:{Listing,Download}}` 字典（**旧的全局单对象格式会被忽略=回默认 4/2**）。② `WebDavClient`[155] 加 `ThrottleKey(serverPathOrUrl)` = 调 `NvDavMountStore.Current.MountKeyForPath(_origin, 路径)` 反查（catch 回退 `_origin`）；5 个限速调用点全改为 `GetListing(ThrottleKey(serverDirPath/srcServerPath))`/`GetDownload(ThrottleKey(url))`（每个点本就有路径/URL 在作用域）。③ `NvDavMountStore`[166] 加 `public string MountKeyForPath(origin, serverPathOrUrl)`：由 (origin 相同 + 服务器路径在某挂载根之下、取最长根匹配) 反查出挂载、返回其 `BuildMountUrl`，找不到回退规范化 origin——保证两端同一 key。④ `SettingPageWebDav`[168]：【高级选项】按钮改字段 `_throttleButton`、`UpdateButtonStates()` 里按 `hasSel` 置灰（**没选中挂载即灰**）；`OpenThrottleDialog()` 取 `SelectedMountUrlOrNull()` 当 key、空则提示「请先选中一个 dav 挂载」并 return；`RequestThrottleWindow` 构造改收 `string mountKey`、回显从 `Get(mountKey)`、确定调 `Apply(mountKey,…)`、头部文案改「仅对当前选中的挂载生效」。改 3 个 create 文件 text、不增条、仍 234。沙箱纯净 `0ab0c48b0` **234/0**、三文件（WebDavClient/NvDavMountStore/SettingPageWebDav）状态机配平 `()`/`{}`/`[]` 全 0、旧全局 API（`DavThrottle.Listing`/`Download.Wait`/`ListingPerSecond`/`RequestThrottleWindow()`）已清除。🚧 待 Windows 实测：① 没选中挂载时【高级选项】置灰、选中后弹窗调的是**该挂载**的限速；② 两个不同挂载各自设不同值、互不影响；③ 重启读 `throttle.json`（现为按挂载字典）；④ ⚠ `throttle.json` 格式变了——旧的全局单值文件会被忽略、各挂载回默认 4/2（首次需重设）。
   - `2026-06-20` 【自定义封面·单文件改为「先停父层默认选中、可下潜」 · 仅改 CustomCoverPicker.cs[176] text、仍 234 · 🚧 待实测】：单文件书（zip/pdf）右键「自定义封面」原本一开窗就把包/PDF 里所有图铺平选页；现改为**先停在该文件所在的父层**（列出同级目录/书）、**默认选中该文件本身**，想看散图再双击/回车下潜进包（进去仍是铺平所有内部图选页）。**文件夹书维持原版**（开窗即在该文件夹）。实现（全在 [176] picker）：① 构造里若 startPath 含压缩包段（`PathHasArchiveSegment`）且有父层（`ComputeParentPath`），则 `_currentPath` 改成父层、记下要选中的文件 `_pendingSelectPath`；② `ReloadAsync` 填完 `_items` 后按 `FullPath` 归一化匹配（`TrimEnd('/','\')` + OrdinalIgnoreCase）找到该文件项、设 `_listBox.SelectedItem` + `ScrollIntoView`，用后即清（仅初次一次）。父层列表走原有 dav 目录分支（`LoadDavDirectoryAsync`，文件作为子压缩包项出现）或本地 CurrentDirectory 分支，故 dav/本地单文件都适用。沙箱 234/0 + `CustomCoverPicker.cs` 配平 0/0/0。🚧 待 Windows 实测：① 右键 dav/本地 zip|pdf → 开窗停在父文件夹、该文件高亮选中；② 双击它进包看到铺平散图、选页设封面正常；③ 文件夹书右键 → 开窗仍直接在该文件夹（行为不变）。【**同批追加**】另修：**每次进入新路径（下潜/返回/初次）滚轮回顶部**（之前会沿用上一层滚动位置）：`ReloadAsync` 填完 `_items` 后，若未滚到选中项（`scrolledToSelection` 标志）则 `_listBox.ScrollIntoView(_items[0])` 回顶；单文件初次已滚到默认选中文件则不覆盖。
   - `2026-06-20` **【mod24 选择器 + mod08/20 预缓存 套用 mod06 隐藏过滤:bug 修复 · 不增条、改 PATCHES[176]/[64] text、仍 233 · 🚧 待实测】**:用户发现自定义封面选择器能看到已隐藏(mod06『从书架移除不删文件』)的项目、且担心预缓存会缓存隐藏项——确属 bug:两者都**直接枚举磁盘内容、绕过了书架隐藏过滤**(mod06 只在 BookshelfExcludeFilter[40] 那一层过滤)。**修法**:给 CustomCoverPicker.cs[176] 与 BookshelfPrecacheRunner.cs[64] 各加一个容错版静态助手 `IsPathHidden(path)`——先用官方 `Config.Current.Bookshelf.IsHiddenPath`(与书架一致),再规范化分隔符(`Path.DirectorySeparatorChar`,避免反斜杠字面量转义坑)+去尾+遍历 `HiddenPaths.Items` 比对,并判定 **under-hidden**(`norm.StartsWith(hn+sep)`,因预缓存递归会进隐藏文件夹内部)。选择器:列**本地容器**(CurrentDirectory 分支 `containers.Add`)时 `if (!IsPathHidden(entry.SystemPath))` 跳过;预缓存 `CollectLocalComicFiles`:`result.Add(dir)`/`result.Add(file)` 各加 `if (!IsPathHidden(...))` 跳过(含子项)。**隐藏对本地与 dav 都生效**(初判误以为本地专属、已纠正):`IsFileSystem()` 只排除 System/Bookmark/QuickAccess/Empty/None,dav 目录项不带这些 → 同样能被隐藏命令 [43] 收进列表,存 `EntityPath.SimplePath`(dav 即 `schemeAuthority+e.Path`,与选择器 LoadDavDirectoryAsync / 预缓存 WalkDavAsync 用的 dav URL 同源,[53] 另有末尾斜杠容错)。故 dav 同样过滤:选择器 LoadDavDirectoryAsync 两个 dav 容器(目录 + dav 压缩包书)各加 `if (!IsPathHidden(schemeAuthority+e.Path))`;dav 预缓存走 RunDavIncrementalAsync→**WalkDavAsync**(非 CollectDavRecursiveAsync——后者只服务清缓存/测量、不动),archives(dav 书)Where 加 `!IsPathHidden`(连文件夹封面别名也不选隐藏书)、子目录递归 Where 加 `!IsPathHidden`(隐藏 dav 文件夹不递归=省 PROPFIND)。压缩包书只列页、页不可隐藏,不过滤。沙箱 `764fea1a7` 233/0、两文件状态机配平 0/0/0。🚧 待 Windows 实测:① 选择器浏览本地文件夹不再显示已隐藏的书/文件夹;② 预缓存本地文件夹跳过隐藏项(及隐藏文件夹下所有书);③ 选择器浏览 dav 文件夹不再显示已隐藏的 dav 书/文件夹;④ 对含隐藏项的 dav 文件夹预缓存,隐藏的 dav 书(及隐藏 dav 文件夹下所有书)被跳过、不下载封面。
   - `2026-06-20` **【mod24 自定义封面选择器虚拟化:根治『打开新书卡一下』· 不增条、改 PATCHES[176] text、仍 233 · 🚧 待实测】**:针对用户反馈『打开新书卡一下 + 缓存了也不秒出 + 框架不好』——根因:选择器 ListBox 用**非虚拟化** WrapPanel(+CanContentScroll=false),填充时把整本书每页一次性建 UI 容器+布局(几百个,和缓存无关 → 任何书都卡)。**改法**:ItemsPanel 换成 NeeView 自身大量在用的 `WpfToolkit.Controls.VirtualizingWrapPanel`(ItemSize=168,218)、去掉 CanContentScroll=false(默认 true 才虚拟化)→ **只为可见的十几项建容器**,填几百页瞬间完成、滚动时才建新容器。并把上轮按需懒加载从『像素视口数学(TransformToAncestor/ViewportHeight)』简化为『**看虚拟化面板是否已为该项建容器(=可见/近可见)**』(去 `_thumbScrollViewer`/`IsItemInThumbViewport`/`FindDescendantScrollViewer`)——更稳、不依赖按项/按像素滚动差异;IsLoadStarted 守在 item 上,容器回收复用不重复加载。沙箱 `764fea1a7` 233/0、CustomCoverPicker 状态机配平 0/0/0、三个 XamlReader.Parse 常量(ItemsPanel/ItemTemplate/ItemContainerStyle)XML 良构。**未解决(下步可选)**:① 列页那一下的网络等待(开远程包列页、RAR 尤甚,本质难消除,会显示『加载中』);② 『已缓存也不秒出』=页缩略图每次打开重解码、无缩略图级缓存(虚拟化后只解可见几张、已大幅缓解,真·秒出需加缩略图缓存)。🚧 待 Windows 实测:打开页数多(尤其未缓存)的 dav 书自定义封面,应不再卡顿、缩略图随滚动渐进出现、选页/设封面/裁剪正常。
   - `2026-06-20` **【✅ ZIP/PDF 生成封面不落内容缓存 实测通过 + 撤回 RAR 封面多扫 + 记录无邪气 RAR 已知问题 · 不增条、仍 233】**:① **✅ 实测通过**:对 dav **ZIP/PDF** 预缓存封面、以及进出装这些书的文件夹,设置里**内容缓存均不增长**(2026-06-19「生成封面 blockStore=null」那条彻底生效)。② **撤回**上条(2026-06-19)的「RAR 封面快路径多张扫描(minLongSide 逐张读到长边≥目标分辨率,4 张/24MB 上限)」——对**无邪气乐园**无效(它自动预缓存封面仍出不了 2048),且多扫会多下载到 4 张/24MB(与「少下载防风控」相悖)。已把 `TryReadCoverBytes` 恢复为**只读存储第一张图**(去 minLongSide 参数 + 多扫循环 + 4张/24MB上限 + best 兜底、删 `GetImageLongSide`;两调用方 [79]`ArchivePageThumbnail`/[64]`BookshelfPrecacheRunner` 去分辨率实参)。其顶部大注释与 [64] 注释本就写「只读第一张图」,撤回后代码与注释自动一致。沙箱 `764fea1a7` **233/0**、三文件(`NvDavRarArchive`/`ArchivePageThumbnail`/`BookshelfPrecacheRunner`)状态机配平 0/0/0。③ **⚠️ 已知问题(待查·先记录)**:**无邪气乐园(RAR)自动预缓存封面仍出不了 2048**(出小图);**同为 RAR 的乱马**清缓存重取能正常 2048;暂不知哪本 RAR 特殊(疑 RAR 偶发或该包结构特殊)。**workaround(已验证有效)**:对无邪气用 **mod24 自定义封面** → 打开该具体漫画 → 选第一张图 → 能正常出 2048。
   - `2026-06-19` 【次因彻底修:生成封面不再持久化内容块(blockStore=null)· 不增条、改 5 文件 text、仍 233】:承上条——预缓存/首次浏览生成封面那一次,因开档恒挂持久块缓存(blockStore=GetBlockStore),会把封面源块(zip 中央目录+首页 / pdf 结构+首页 / rar 文件头)落进内容缓存 pages/(用户观察:预缓存原图→内容缓存涨 11.1MB)。本条彻底修:加 AsyncLocal 开关 NvDavCache.SuppressContentCache,生成封面期间(PageThumbnail.LoadAsync 唯一总闸里 set true、finally 还原)打开;三个 dav archiver(NvDavZipArchive/NvDavPdfiumArchive/NvDavRarArchive 普通开档)读它决定 blockStore=null(只内存不落盘)还是持久存储;blockStore 全部用 ?. 守卫(SaveLength/LoadLength),离线 catch 用 ??-1→优雅 rethrow。安全性关键:dav archive 不进 ArchiveManager 缓存(CreateArchiveAsync dav 直通分支在 _cache.Add 之前 return、每次新建)→ 封面档(blockStore=null)与阅读档(blockStore 正常)是不同实例,绝不把阅读时的内容缓存也钉成 null;阅读路径不经 PageThumbnail.LoadAsync,开关=false 照常持久化。RAR 快路径自带 blockStore=null 与开关无关,其失败回退到普通开档时开关也已生效。效果:封面生成(浏览/预缓存/全格式)只 FETCH 封面源块、不再写进 pages/——内容缓存 pages/ 从此只由真正阅读填充。配合上条(封面缓存命中对所有 dav 格式生效),预缓存过封面后再浏览=读 covers/ 不开档、首次浏览/预缓存=拉封面但不落内容,内容缓存全程保持干净。改 NvDavCache.cs(加开关)、PageThumbnail.cs(PATCHES[140] set/restore)、NvDavZipArchive.cs(156)、NvDavPdfiumArchive.cs(157)、NvDavRarArchive.cs(201)五处 text。沙箱 764fea1a7 233/0;140/156/186/201 词法配平 0/0/0;157 因插值字符串 $\u0022{id+1:000}.png\u0022 令正则剥离器误判 -1,但状态机校验整文件 brace depth=0=平衡(且改动仅 3 行 blockStore、不含花括号、与 bak8 配平一致)。✅ 2026-06-20 用户实测通过:对 dav ZIP/PDF 预缓存封面 + 进出装这些书的文件夹,设置里内容缓存均保持不增长(此前观察的涨 11.1MB 已消除)。
   - `2026-06-19` 【修「浏览 dav ZIP/PDF 文件夹反复重开档拉内容、比预缓存更易触发风控」· 不增条、改 PATCHES[79] text、仍 233】:用户实测——预缓存封面后,清空内容缓存→退出 A 文件夹→再进 A,内容缓存又涨几 MB;反复进出每次都涨(每本约几百KB,865/776/630/677/703KB);而逛纯子文件夹(无单本书)内容缓存恒 0。根因:上一条给浏览路径加的「封面缓存命中检查」(NvDavCache.TryReadCoverFileBytes)只写在 RAR 分支里 → dav ZIP/PDF 书从不读已缓存封面 → 每次进文件夹都重新开档(NvDavZipArchive/NvDavPdfiumArchive 流式打开)重生成封面,而开档的 RemoteRangeStream 恒挂持久块缓存 → 把封面源数据(中央目录+首页)反复拉取并写进内容缓存 pages/。这就是浏览比预缓存更易触发风控(预缓存每本只开一次档,浏览每次进都重开)。修法(本条):把封面缓存命中检查从 RAR 分支挪到最外层、对所有 dav 格式(zip/pdf/rar)生效——预缓存过封面(covers/ 已有)后再进文件夹,直接读 covers/ 秒出、不再开档、不再拉内容。改 ArchivePageThumbnail.cs(PATCHES[79] 既有 replace 的 text)一处。沙箱 764fea1a7 233/0、ArchivePageThumbnail.cs 词法配平 0/0/0。🚧 仍待解决(次因·已分析未改):预缓存/首次浏览生成封面那一次仍会把封面源块持久化进 pages/(因开档恒挂 blockStore)——即用户观察的『预缓存原图→内容缓存涨 11.1MB』。彻底清掉需让封面生成开档时用 blockStore=null(不持久化;但封面源块仍须 FETCH,故只省持久化不省网络拉取)——更动核心开档(NvDavZipArchive/Pdfium/Rar 三处 + AsyncLocal 开关 + null 守卫),较侵入,待用户确认是否做。当前可行解:预缓存后在设置里清一次内容缓存,之后浏览(本条修复)不再重新污染。
- `2026-06-19` **【⚠️ 已撤回(见 2026-06-20 条)】RAR 封面快路径曾加 `minLongSide` 逐张扫到目标分辨率**(为无邪气乐园这类「存储第一张=低清缩略图、排序第一张才是高清页」的 RAR 出 2048)——对无邪气无效且多下载(4张/24MB),已撤回恢复 `TryReadCoverBytes` 只读存储第一张图。
   - `2026-06-19` **【RAR 封面快路径从「预缓存」挪到「浏览」共同入口 · 不增条、改 2 文件 text、仍 233】**:用户澄清——他**不用「预缓存封面」命令,而是直接浏览装 RAR 的 dav 文件夹**让其自动加载封面,而上一条把快路径只挂在 `BookshelfPrecacheRunner`(预缓存命令),浏览这条路没钩上 → 浏览仍走老完整流程(每本扫全部文件头=几十MB,用户实测清缓存 27→48MB 才见封面)。**真修 = 把快路径挂到浏览+预缓存的共同入口 `ArchivePageThumbnail.LoadThumbnailAsync`**(书架每本书封面都经此:`FolderItem.CreateArchivePage`→Page→`PageThumbnail.LoadAsync`→`ArchivePageThumbnail`):在开档(`GetSelectedPageContentAsync`)前插 dav RAR/CBR 分支——① `NvDavCache.TryReadCoverFileBytes` 命中已缓存封面秒出;② 否则 `NvDavRarArchive.TryReadCoverBytes`(只读首图几百KB)→ `NvDavCache.DecodeCoverForThumbnail`(解码缩放到本书档位+编码 JPEG)→ `SaveCoverImage` 落盘 → `return new ThumbnailSource(jpeg)`;任何异常一律回退原 `GetSelectedPageContentAsync`(本地/zip/pdf 早 return 不进此分支,**绝不比原来差**)。**关键尺寸**:浏览时 `Thumbnail.Resolution` = 该书档位(没预缓存过=默认 **512**),故浏览生成 512 小封面(每张~100KB),快路径生效后清缓存应只剩**几 MB**(不再几十MB)。改 `NvDavCache.cs`(+`DecodeCoverForThumbnail`/`TryReadCoverFileBytes`)、`ArchivePageThumbnail.cs`(PATCHES[79] 扩既有 replace、marker 不变)两个 text;预缓存里 A1/A2 快路径(PATCHES[64])保留、独立不冲突。沙箱干净 `764fea1a7` 233/0、两文件词法括号配平 0/0/0。🚧 待 Windows 实测:浏览 dav RAR 文件夹封面应**又快又只占几 MB**;若仍慢查 `%TEMP%` 下 `nv_webdav.log` 找 `RAR cover fast-path OK/failed`。
   - `2026-06-19` **【修「老板键隐藏弹窗」引入的崩溃 · 不增条、改 mod09 `BossKeyHotKey.cs` text、仍 233】**:上一条用 `Visibility=Hidden` 藏窗口,但**模态框(`MessageDialog` 经 `ShowDialog()` 显示)被改 `Visibility` 会破坏其模态状态** → 之后点按钮设 `DialogResult` 抛 `InvalidOperationException: 只能在创建 Window 并且作为对话框显示之后才能设置 DialogResult`(用户复现:对清除缓存确认框**按两次老板键**藏→显、再点取消即崩;秒点取消不崩)。**改法**:`HideAuxWindows` 不再动 `Visibility`,改为**把窗口移出可见屏幕**(`Left/Top=-32000`,记下原位置;拿不到位置=`NaN` 的窗口跳过不动、绝不退回改 Visibility),`RestoreAuxWindows` 移回——视觉上照样消失、但 `Visibility` 不变=模态状态完好、`DialogResult` 可正常设。`_hiddenAuxWindows` 字段类型改为 `List<(Window,double left,double top)>`。沙箱 `764fea1a7` 233/0、`BossKeyHotKey.cs` 词法括号配平(净 0/0/0)。🚧 待 Windows 实测。〔注:RAR 封面快路径**已于本会话改挂到浏览入口 ArchivePageThumbnail**(见上一条),浏览 dav RAR 文件夹封面应又快又只占几 MB(512 小封面);若仍慢查 `%TEMP%` 下 `nv_webdav.log` 找 `RAR cover fast-path OK/failed`。〕
   - `2026-06-19` **【两个 RAR/dav bug 修复 · 都不增条(只改 3 个 create 文件 text)、仍 233】**:① **RAR 封面预缓存又慢又下几十 MB**——根因:RAR 无尾部中央目录、出封面必须把全部文件头走一遍建条目表(乱马 Vol.01 有 187 个条目、每个头拉它所在的 256KB 块 → 187×256KB≈47MB;又因 `RemoteRangeStream` 无预读=187 次串行 Range 往返=慢),而封面本身才 435KB。**修 = 封面快路径**:新增 `NvDavRarArchive.TryReadCoverBytes`,用 SharpCompress **`RarReader`(顺序流式)** 从头读、读到第一张图片条目就停(1~3 次 Range、几百KB),且**不接持久块缓存**(`blockStore=null`→不污染「清除缓存」体积);`BookshelfPrecacheRunner` 对 dav RAR/CBR 走这条快路径(`DecodeCoverToResolution` 复刻 `ThumbnailProfile.GetThumbnailSize` 尺寸→`NvDavCache.SaveCoverImage`),**失败(加密/损坏/取不到/离线)自动回退**完整 `LoadThumbnailAsync`。代价:封面=存档顺序第一张图(漫画 99% 即第1页;异常排序包可用 mod24 自定义封面覆盖);**读 RAR 书本身仍要建一次完整条目表**(RAR 格式硬伤、本次不动,首开一次后 C3 块缓存兜住)。② **老板键(Alt+X)藏不住「清除缓存确认框」「预缓存进度窗」**——根因:作者 `AppState.SuspendAsync` 只折叠主窗内容(`MainWindow.Root.Visibility=Collapsed`)、根本不管别的独立 `Window`。**修 = mod09 老板键**隐藏时枚举 `Application.Current.Windows`、把**主窗之外当前可见的窗口一并 `Visibility=Hidden`**(记入 `_hiddenAuxWindows` 字段;隐藏不关闭=模态确认框保持模态、恢复后原样复现),恢复时(`_window.Show()` 之后)`RestoreAuxWindows` 还原——通用做法,覆盖确认框/进度窗/未来任何弹窗。**共改 3 个 create 文件 text**:`NvDavRarArchive.cs`(加 `TryReadCoverBytes`/`IsImageEntryName`)、`BookshelfPrecacheRunner.cs`(dav RAR 快路径 + `IsRarLikePath`/`DecodeCoverToResolution`)、`BossKeyHotKey.cs`(`_hiddenAuxWindows` 字段 + `HideAuxWindows`/`RestoreAuxWindows`)。**SharpCompress 0.48.1 API 已对 GitHub 源码逐一核实**(`RarReader.OpenReader(Stream,ReaderOptions?)→IReader`、`IReader.MoveToNextEntry()`/`Entry`/`OpenEntryStream()`、`IEntry.Key`/`IsDirectory`、`EntryStream:Stream`、`IReader:IDisposable`)。沙箱干净 `764fea1a7` **233/0 零失配**、三 .cs 词法括号配平(净 ()/{}/[] 全 0/0/0、与备份逐项一致)。**🚧 待用户 Windows 编译实测**:① 对装 RAR 的 dav 文件夹「预缓存原图封面」应**又快又只占几 MB**(不再 45.8MB)、封面正确;② 老板键按下时清除缓存确认框、预缓存进度窗应**一起消失**、恢复后复现。
   - `2026-06-19` **【新增·魔改25:顶部地址栏 = 文件夹导航地址栏】(223→233,+10 replace)**:按用户需求把顶部那条做成「文件管理器式地址栏」——① 地址栏**自动跟踪书架当前文件夹**(不再跟「打开的书」→ 图1 空白、图2 陈旧的毛病消失);② 输入/粘贴/点面包屑**本地 `D:\000` 与 dav `dav://host/...` 都能跳转**(`AddressBar.Load` 改 `BookshelfFolderList.RequestPlace`);③ 顶部 **← → ↑ = 书架 后退/前进/上一层文件夹**(用户明确弃用作者「上一本/下一本书、上移到书的父级」),右键历史菜单也改书架文件夹历史(`GetHistory`/`MoveToHistory`→`BookshelfFolderList`)。**安全要点(避开上次撤回的崩)**:所有「位置/历史变化 → 刷新按钮可用态 / 刷新地址文字」**一律 `AppDispatcher.BeginInvoke` 投回 UI 线程**(照搬 `FolderListViewModel` 成熟做法),且 dav 的 `CanMoveToParent`→基类 `GetParentQuery` **纯字符串、不碰网络**(沙箱核实 dav 集合 PATCHES[167] 未重写它)。改 **3 文件共 10 条 replace**:`AddressBar.cs`×3(ctor 跟踪书架 / setter 导航 / Load 移动书架)、`AddressBarViewModel.cs`×4(ctor 回 UI 线程刷新 / 三键命令 MoveToParent·Prev·NextFolder / GetHistory / MoveToHistory)、`AddressBarView.xaml`×3(← → ↑ 重绑命令)。**同时把 `AddressBar.cs`/`AddressBarViewModel.cs` 从 `OBSOLETE_EDITS` 移回 PATCHES**(它们现被 mod25 打补丁;OBSOLETE_EDITS 回到只剩 `SidePanelFrameView.xaml.cs`)。**本条取代/实现了之前撤回的「dav 顶部 ↑ + 粘贴地址导航」两 bug**(且扩展到本地 + 自动跟踪 + ←→)。沙箱干净 `764fea1a7` **233/0 零失配**、两 .cs 词法括号配平(AddressBar 43/15、VM 66/27/8[])、`AddressBarView.xaml` XML 良构、旧书导航符号(`MoveToParentBookCommand`/`BookCommands[Prev·NextBookHistory]`/`BookHubHistory`)全清除。⚠ **待用户 Windows 编译实测**:① 顶部框显示当前文件夹(本地/dav)、进文件夹即时跟随不空;② 框里输入/粘贴 `D:\000` 或 `dav://127.0.0.1:5244/dav/115网盘/Comic` 回车能跳;③ 顶部 ←/→/↑ = 后退/前进/上一层文件夹(本地+dav)、该亮才亮;④ 海报墙下也不崩(跨线程已根治)。**注**:地址栏既然=文件夹,☆ 收藏/复制/粘贴/拖拽 现在都对「当前文件夹」(文件管理器式);ⓘ 书信息仍按打开的书显示;顶部 ←→↑ 的 ToolTip 文案仍是作者原文(只改了功能,未改文案)。
- `2026-06-19` **【已撤回】地址栏首次尝试(4条,223→227→223)**:『刷新↑按钮可用态』挂钩挂在 `BookHub.AddressChanged`(由 `LoadAsync` 在**后台线程**触发)→ `NotifyCanExecuteChanged` 让 WPF 后台线程改按钮 `IsEnabled`=跨线程 → 用户报「打开本地文件夹 / 海报墙 F11 后 Esc 卡死」,全撤回恢复上游原版。**教训已落实进 mod25**(见上方 mod25 条):刷新挂钩 `AppDispatcher.BeginInvoke` 投回 UI 线程、`CanMoveToParent`/`GetParentQuery` 不做同步网络 I/O。
- `2026-06-19` **【撤回补救 · ✅ 实测海报墙双击不再崩】**:上面撤回时**漏登记 `OBSOLETE_EDITS`**(铁律见 §3/§6:replace 删条目后该文件不再被任何补丁涉及就必须登记)→ `build.py` 还原不 checkout 这两文件 → 旧补丁4 永久残留、重编仍崩(后台 Unload 线程跨线程改 ↑ 按钮 `InvalidOperationException`;只海报墙双击复现)。已补登记 `AddressBar.cs`/`AddressBarViewModel.cs`(后 mod25 又移回 PATCHES)。**给用户**:新包跑 build.py 会自动还原这两文件 → **彻底重编(清 bin·obj)** 即不崩。
- `2026-06-19` **dav 大文件(790MB cbz)打开报 EOCD 排查 + 暂停**:一度加「整包下载兜底」(`RangeNotSupportedException`/`DownloadAll`,大文件回 200 整包时整文件下载到磁盘块缓存)又**全撤回**——用户用可达阅读器证明该文件能流式读(复制/秒传后仍报错)=误诊、且有「别的书被误判整包下载」副作用。**保留**:`FetchRange` 诊断日志(响应码/`Content-Range`/bytesRead→`%TEMP%\nv_webdav.log`)+ 长度探测修正(206 只信 `Content-Range` 总长、`bytes=0-` 兜底,防分片 `Content-Length`=1字节被当总长)。**疑真因(未解)**:磁盘块缓存被污染(`NvDavCache.WriteBlock` 对已存块永不覆写→早先失败写的脏块卡死、`GetBlock` 总命中→永远 EOCD、`FetchRange` 成死代码)+ CDN 直链 `s≈25MB` 只授权前 25MB(尾部中央目录取不到)+ 115 风控。**搁置**:待风控过 + 用户清掉该书 `WebDavCache` + 用带 Probe/FetchRange 日志的 build 重开送干净日志再下最后一刀。
  - `2026-06-19` **dav 搜索框做成可用**(原灰→可用;只过滤「当前文件夹已列出项」、纯客户端零额外网络、不递归拉服务器防风控)+ **dav 改双击打开**(原单击→单击只选中、双击才进文件夹/开书,与本地"双击打开"一致)(221→223,+2 replace `FolderListBox.xaml.cs`;搜索改 `WebDavFolderCollection.cs` create 文本、不增条)
  - `2026-06-19` 修「书架悬浮预览比海报墙更糊/有色斑」(+1 replace,220→221)
  - `2026-06-19` 给 dav 右键「清除缓存」加原生确认框(作者 MessageDialog 样式),计数不变仍 221
  - 续 2026-06-19 · 确认框带缓存大小 + 文字精简(仍 221)
  - `2026-06-19` 修「预缓存悬浮进度窗:老板键隐藏时悬浮条没跟着藏」(仍 221,改 `PrecacheProgressWindow.cs` create 文本)
  - `2026-06-19` 自定义封面选择窗三连(仍 221,改 `CustomCoverPicker.cs` create 文本)
  - `2026-06-19` 修「长图(webtoon)裁剪封面无法调整」(仍 221,改 `CustomCoverPicker.cs` 的 `CoverCropWindow`)
  - `2026-06-19` 「调整」按钮支持文件夹/容器封面(仍 221,改 `CustomCoverPicker.cs`)
  - `2026-06-19` 预缓存点「取消」也刷新已缓存封面(仍 221,改 `BookshelfPrecacheRunner.cs`)
  - `2026-06-19` 诊断 dav「全角斜杠 `／` 文件夹里找不到文件」(只诊断、暂无代码改)
  - `2026-06-18` 修 dav 预缓存「风控本误判为成功 + 残留 2048 标记」(本会话,计数不变仍 220)
  - `2026-06-18` dav 右键菜单「全局→按挂载独立」+ WebDAV 设置操作行 4 项 UI 调整(本会话续 Feature3)—— 计数不变仍 220(replace 172 / append 13 / create 35),全部既有补丁就地改、零新增条目;沙箱 HEAD `764fea1a7` `build.py --patch-only` 220/0 零失配、5 改动文件 C# 词法器括号 `()`/`{}`/`[]` 全 0/0/0、全树零残留 `DavContextMenuItems` 引用
  - `2026-06-18` dav 体验八连(本会话)· bug 修 + dav 文件夹自动封面 + 预缓存防风控 + 内容缓存「确定」+ 隐藏无效重置 + dav 重命名 + dav 独立右键菜单 —— 203→220(replace 159→172 / append 11→13 / create 33→35),全部归入魔改23/24,沙箱双基准(`4dbe593eb` / HEAD `764fea1a7`)各 fresh worktree `build.py --patch-only` 220/0 零失配、9 改动文件 C# 词法器括号 `()`/`{}`/`[]` 全 0/0/0
  - `2026-06-18` 六续 · 预缓存原图放大到 2048 / 清缓存关开着的书+清子文件夹封面 / 答裁剪窗悬浮图色斑 + 自定义封面落盘改 q95 近无损 —— 计数不变仍 203,改 `ThumbnailProfile.cs`(mod20,扩大既有补丁不增条)+ `BookshelfPrecacheRunner.cs`/`NvDavCache.cs`(create)+ `FolderListBox.xaml.cs`(mod23 Execute + mod24 自定义封面落盘 两条既有 replace 的 text)
  - `2026-06-18` 五续 · 自定义封面选择器四连(排序按阅读顺序 / 选中文件夹用其封面 / 去 2 个编译 warning / 答开书卡顿;含撤销误做的散图功能)—— 计数不变仍 203,改 `CustomCoverPicker.cs`/`BookshelfPrecacheRunner.cs`/`SettingPageWebDav.cs` 三个 create 文件内容
  - `2026-06-18` 四续 · 修「dav 书架/书界面按老板键回来,书架跳回 此电脑/书签 或本地路径」—— 计数不变仍 203,只改 `_Mod/BossKeyHotKey.cs`(mod09)内容
  - `2026-06-18` 三续 · 修「自定义封面选择器里看不到 dav 子目录的自定义封面」+ 上一版编译错误修正 —— 计数不变仍 203,改 `CustomCoverPicker.cs`(+ 上一轮 `NvDavRarArchive.cs`/`NvDavZipArchive.cs`)三个 create 文件内容
  - `2026-06-18` 再续 · 加密 RAR + 加密 ZIP 流式(dav)—— 计数不变仍 203,只改 `NvDavRarArchive.cs` / `NvDavZipArchive.cs` 两个 create 文件内容
  - `2026-06-18` 续 · WebDAV 流式 RAR/CBR(SharpCompress 纯 C#)—— 201→203,首个引入 NuGet 依赖的魔改
  - `2026-06-18` · dav 三连(格式白名单 / dav 书进度·已读完·统计 / 清缓存归零续读 + 单文件菜单)—— 计数不变仍 201,均改既有 create 文件文本 + 1 条既有 replace 的 text,沙箱双基准 201/0
  - `2026-06-17` · 文件夹右键「清除缓存」(dav,一键清夹内所有文件封面+内容块,便于重测流式 PDF)
  - 续修
  - `2026-06-17` · 流式 PDF 改真流式:绕过 PdfiumViewer,直接 P/Invoke pdfium.dll(大工程·原生互操作)
  - `2026-06-17` · WebDAV/Alist 流式 PDF 阅读(初版·已被  取代)
  - `2026-06-17` · 自定义封面「调整」人工裁剪(dav)
  - `2026-06-17` · 海报墙(魔改19)封面统一大小 + 右边距一致
  - `2026-06-17` · dav 文件夹自定义封面设了不显示 + 清除封面确认框显示大小
  - `2026-06-17` · 方案A:dav 阅读 zip 把内层文件夹当页 + dav 自定义封面导航/渲染 彻底修
  - `2026-06-17` · dav 自定义封面三连修复(包内目录导航/取消崩溃/封面秒显)
  - `2026-06-17` · dav 文件夹「自定义封面」支持 + 选图窗口视觉/右侧留白修复
  - `2026-06-17` · WebDAV 设置页 UI 精简(密码框暗色 + 内容缓存收进独立小窗 + 确认框/提示精简)
  - `2026-06-17` · WebDAV 设置页操作区重构 + 「清除封面」正确复位 dav 2048 标记
  - `2026-06-17` · 「清缩略图缓存清不掉 2048」二次修复 + Stage C3 实测成功
  - `2026-06-17` · 魔改23 Stage C3:WebDAV 页面内容「持久磁盘缓存」(每挂载独立上限+LRU、离线可翻)
  - `2026-06-17` 续:原图统一 2048(本地文件夹 + dav)+ 本地文件夹自定义封面可清除
  - `2026-06-17` 又:dav 挂载封面预缓存原图「标了 2048 仍显示小图」
  - `2026-06-17` Issue A/B/C 三连修复(均针对 WebDAV/dav 挂载)
  - **(承上)mod23 已知技术局限(供接手参考)**:① **固实(solid)RAR 不支持流式**(需顺序解整包),`EnsureOpen` 检测 `IsSolid` 后明确报错;② **RAR 错误密码检测不可靠**(文件名不加密时可能抛 `NullReferenceException` 或返垃圾而非干净异常→弱口令自动试可能不稳,手动框兜底;zip 错误密码可靠抛 `CryptographicException`);③ **dav PDF 暂无 TOC/书签**(写死 cast)。
- **既有小提示(非 bug、不影响正常使用)**:mod16 那条 `HistoryListBox.xaml.cs` 的 replace 补丁在 `build.py --no-reset`(对已打补丁的树重打)下会报「锚点失配」——这是它 marker 的既有幂等小毛病、**改动前的 114 条版本就有**,与 04-N/mod02 修复无关;`MainWindow/WindowTitle.cs`(mod15「标题去版本号」那条)同理也会在 --no-reset 下报失配(2026-06-10 用原 116 条对照确认为既有现象、非魔改19 引入)。`build.py` 默认会先自动还原再整体重打(全新 123/0 干净),故日常 `build.py` / `--pull` 完全不受影响;仅极少用的 `--no-reset` 路径会遇到(本项目约定不手改源码、基本用不到)。
- **历史基准沿革(审计用;当前基准见上 = `764fea1a7`)**:补丁最初生成于上游 `6464291`(2026-06-01),此后随多次 `python build.py --pull` 依次迁移 `8200c60`(06-04)→`3b62b9c9f`(06-05)→`6c4b43c48`(06-06)→`f2e269702`(06-08)→`e7bd7e299`(06-10)→`e87d924b1`(06-13)→`4dbe593eb`(06-15)→`764fea1a7`(06-17),每次均「锚点全命中、零失配」且用户实编实测通过。
- **时间口径**:版本号括号里的时间 = 上游作者提交该 commit 的时间(`git log -1 --format='%ai' <commit>` 查),不是用户拉取/编译时间。
- 子模块锁定 commit(**更新前后未变**):
  `AnimatedImage dc68646` ／ `NeeLaboratory.IO.Search d8568a3` ／ `SevenZipSharp 78563f5` ／ `Vlc.DotNet b49cca5`

> 补丁永远是"针对某个版本"的。要复现用户状态,就 `git checkout 8200c60` 再打补丁。要用到 NeeView 再更新后的新版,见 §5。

### 2.1–2.8 历次 `--pull` 上游同步核查(已精简)

> 历次「`git pull` 到上游新版 → 重打补丁 → 核查」的结论**一律是「所有补丁锚点全命中、零失配、零功能重合,用户在 Windows(VS2026)实编实测通过」**,故不再逐次展开。仅两次有实际迁移动作:**2026-06-05**(`8200c60`→`3b62b9c9f`,2 个上游提交波及 8 条补丁、已全部迁移)与 **2026-06-10**(新增 mod19 七条,新旧双基准沙箱零失配)。mod09 老板键焦点修复(2026-06-05)细节见 §4 魔改09。逐次原始记录可查 `git` 历史。更新上游的标准流程见 §5。

## 3. 魔改包的结构

这些文件随项目一起保管(建议放在源码根目录的 `mods/` 文件夹,或单独打包发给下一个 AI):

```
mods/                                  ← 这就是 NeeView_魔改包.zip 解压后的内容
├── build.py                          # 【引擎,固定不变】打补丁 + 调 MSBuild 编译 + 收集成品;运行开头打印"改动概览"
├── patches.py                        # 【补丁数据,会增长】所有魔改的补丁;加功能只往这里追加(顶部有"魔改块行号索引")
├── 新机环境检验.py                      # 只读体检:验证编译环境(VS 工作负载 / MSBuild / 源码完整性)
├── 源码备份.py                     # 把源码去魔改化、导出一份干净原版(默认带 git)到 E 盘,供压缩上传网盘
├── README.txt                        # 给用户看的简短上手说明(怎么跑 build.py)
└── _给AI看_NeeView魔改补丁清单.md     # 本文档(改了什么、怎么继续、怎么复现用户状态)
```

> **接手只需本文档**:它自包含开工所需的全部关键信息——项目结构与技术栈分层见 §3、基准 commit 见 §2、已经改了什么见 §1/§4、怎么编译与怎么判断上游更新见 §5/§6,不依赖任何外部文档。

**引擎 / 数据分离(重要)**:`build.py` 是引擎,所有补丁集中在 `patches.py` 的 `PATCHES` 列表里,**加新功能只往这一个文件追加条目**。补丁用 **「定位锚点 + 插入代码」**(不是整文件替换),每条都看得到"原版哪几行 + 插入了什么"。想知道到底改了什么,直接读 `patches.py` 最清楚,也比纯 diff 更能扛源码漂移。

> 引擎原则:`build.py` **不为单个魔改功能修改**,但允许少量"通用基建增强"(对所有补丁通用、不绑定具体功能)。已做的基建增强:① 自动还原(git仓库默认 reset);② `--pull` 更新;③ 收集前自动强制关闭运行中的 NeeView;④ 禁用 `__pycache__`;⑤ `create` mode(新建文件);⑥ **单实例锁**(禁止两个 build.py 同时运行,临时目录锁文件+PID 存活检测,死进程残锁自动覆盖,atexit 自动清理);⑦ **reset 修复**(同一文件既被 create 又被 replace 时,reset 归类为新增删除、不做 git checkout);⑧ **改动概览**(每次运行开头打印 patches.py 真实内容:每个魔改几条补丁、碰了哪些文件,供对照 MD 核对、防止改代码忘更 MD;此功能任何异常都不中断编译)。

**补丁 mode 三种**:`replace`(锚点替换)、`append`(追加到文件末尾)、**`create`(新建整个文件)**。create 用于需要新增 .cs/.xaml 文件的大功能(SDK 项目自动包含新文件编译,无需改 csproj);其 marker 留空,靠"文件是否已存在"判断幂等;`reset` 时 create 的新文件会被**删除**(不在 git 里),改动文件则 git checkout 还原。**条目可加 `"enabled": False` 临时停用**(打补丁阶段 [停用] 跳过;其 create 文件还原时照删)。**删补丁的标准做法**:replace/append 直接删条目(还原 checkout 自带收敛);**create 必须「删条目 + file 路径登记进 `OBSOLETE_FILES`」**(还原阶段自动删除文件;v4.2 引入,首批=魔改19 v1~v3 三个旧 `_Mod/PosterWall*.cs`);**replace/append 删条目后,若该文件从此不再被任何补丁涉及,必须把路径登记进 `OBSOLETE_EDITS`**(还原阶段自动 git checkout 回原版;v5 引入,首批=`SidePanels\SidePanelFrameView.xaml.cs`)——否则旧机器上该文件的历史改动会残留(还原只 checkout「当前补丁涉及的文件」)。两张清单一对,删任何类型补丁都零手工收敛。

> `build.py` 运行时是**彩色输出**(成功=绿、跳过=黄、出错=红),且运行结束或出错都会**暂停等回车、不会一闪而过**(双击运行也看得到结果)。此外**重新编译时会自动保留旧输出目录里的 `Profile`**(用户的密码/历史/设置不会被 `_build_out` 重建清掉)。改 `build.py` 时请保留这三点。

---

## 4. 各魔改详情

### 01 · 压缩包密码池(Archive Password Pool)

**目的**:打开加密压缩包需要密码时,先**静默逐个**尝试用户保存的"密码池";全部失败,才弹出原有的手动输入框。密码池在 *设置 → 文件类型 → 7-Zip* 里编辑;按用户要求**明文**保存,不加密。

**实际改动(已实现;每处的完整原文 + 插入内容都在 `patches.py` 的 `PATCHES` 里,直接读那里最清楚)**:

- `NeeView/Config/ArchiveConfig.cs`：新增一个密码列表属性 `Passwords`。NeeView 的配置类会自动序列化进 `Profile/UserSetting.json`,设置界面也据此显示/编辑。
- `NeeView/Archiver/ArchiveKey.cs`：在 `UpdateArchiveKeyByUser()` 里——在"查单文件缓存 `ArchiveKeyCache`"之后、"弹手动输入框"之前——插入"依次返回密码池里下一个密码"的逻辑;池子用尽再走原对话框。
- `NeeView/Setting/SettingPageFileTypes.cs`：在 7-Zip 设置页加一个密码编辑列表,**复用现成的 `SettingItemCollectionControl`**(扩展名编辑器用的就是它),外观与原生设置项一致。
- `NeeView/Setting/SettingItemCollectionControl.xaml.cs`：给这个通用列表控件加了 `IsTrimEnabled` 开关(默认 `true`,不影响扩展名编辑器等别处);密码池处设为 `false`,从而**支持首尾带空格的密码**(原版的添加/编辑框会 `Trim()` 掉首尾空格)。
- `NeeView/Languages/*.restext`：补中文等界面标签。

**机制要点(将来文件大改、需手工重放补丁时看这里 ⚠️)**：
NeeView 解压时有个"重试循环"——`SevenZipAccessor` 的 `GetArchiveInfo` / `ExtractFile` / `PreExtractAsync` 三处,每当解压因密码错(`WrongPassword` / `DataError`)而失败,就调一次 `ArchiveKey.UpdateArchiveKeyByUser()` 要一个新密码,拿到就 `continue` 重试,拿不到就 `throw` 放弃。
**密码池就插在"要新密码"这个环节**:让 `UpdateArchiveKeyByUser()` 每次调用先吐出池子里下一个未试的密码(`SetKey` + 返回 true、且不弹框不报错),池子吐完了才回落到原来的手动对话框。
> 现有的 `ArchiveKeyCache` 是「按文件名记、AES 加密但**不存盘**、重启即忘」的内存缓存——它**不是**密码池,别混淆。
> 理解上面这套循环,即使将来这几个文件被重写,也能在对应位置把同样的逻辑放回去。

**存储**:`Profile/UserSetting.json` 里的 `Archive.Passwords`,明文字符串数组。改密码**永不需要重新编译**(更新不动 Profile)。

**已知取舍**:试密码是"逐个真实尝试解压",密码池很大时第一次打开会略慢;十几条以内基本无感。

**支持的密码类型**:中文 / 英文 / 符号 / 含空格(含**首尾空格**)/ 超长,均支持——密码是原样喂进 7-Zip 解密的,与手动输入走同一条路。列表会按字母排序显示、自动去重(不影响匹配)。

**如何使用(给用户)**:编译运行后,*设置 → 文件类型 → 7-Zip → 密码池*,用「+」把常用密码加进去。之后打开加密包会自动逐个试,全失败才弹手动输入框。

**验证点(给接手 AI)**:① 设置里能看到「密码池」列表并能增删;② 用某个池内密码加密一个 zip,打开应**不弹框直接进**;③ 用池外密码加密的包,试完全部池内密码后**才**弹手动框。

---

### 02 · 封面预生成(Preload All Thumbnails)

**目的**:原版缩略图是"懒加载"——只给屏幕**可见**的项排生成任务,滚动时还有 200ms 防抖,所以打开文件夹时封面是逐个冒出来的(即便已缓存,也是滚到才从 `Cache.db` 读出来铺)。本魔改让打开文件夹时**一次性对全部项排任务**:已缓存的文件夹瞬间铺满封面;未缓存的会在打开时后台一次性生成完(之后即秒开)。开关在 *设置 → 常规 → 缩略图 → 预生成全部封面*,默认**开**。

**实际改动(完整原文+插入都在 `patches.py` 的 `PATCHES`,02a–02f)**:

- `NeeView/Config/ThumbnailConfig.cs`：新增 `IsPreloadAllEnabled`(默认 `true`),自动存进 `UserSetting.json`、设置界面可见。
- `NeeView/SidePanels/ListBoxThumbnailLoader.cs`：在 `Load()` 里——开关打开时,把 `PageCollectionListBox.Items`(**全部项**)喂给 `CollectPageList` 排任务并 `return`;关闭时走原来的"仅可见项"路径。
- `NeeView/Setting/SettingPageGeneral.cs`：在缩略图缓存设置区(`IsCacheEnabled` 下面)加开关。
- `NeeView/Languages/*.restext`：中英文标签。

**机制要点(将来文件大改、需手工重放时看这里 ⚠️)**：
书架 / 页列表 / 播放列表 / 历史都共用 `ListBoxThumbnailLoader`,它的 `Load()` 原本只收集"可见的 `ListBoxItem`"。魔改的关键就一句:**改成收集 `ListBox.Items`(全部数据项,虚拟化不影响 Items)**,再交给原有的 `LoadCore` → `_jobClient.Order(...)` 去排队生成。因为 `CollectPageList` 各实现都是 `.OfType<IHasPage>()`,所以只换"喂进去的集合"即可,不必改接口或各面板。改这一处,所有列表都生效。

**已知取舍**:未缓存的大文件夹(如几百个大 PDF)打开时会后台一次性猛生成,首次吃 CPU、要等一会儿;生成完即全缓存。用户已确认主页保持 `D:\` 且**不加条目数上限**。PDF 封面用 Pdfium 渲染首页,本身较重,大文件偏慢是固有成本(与本魔改无关)。

**如何使用(给用户)**:默认已开,直接用即可。想关就到 *设置 → 常规 → 缩略图 → 预生成全部封面* 关掉。

**验证点(给接手 AI)**:① 设置 → 常规 → 缩略图 里能看到「预生成全部封面」开关,默认开;② 打开一个**已缓存**、项很多的文件夹,封面应几乎同时铺满而非逐个冒;③ 关掉开关后恢复成原版逐个懒加载。

**【02-live · 可见项优先排队 + 滚动重排 2026-06-08 · ✅ 已实测通过(2026-06-09)】**

**Bug(用户报)**:1000 项的大文件夹里很多封面拉不出来、点开具体漫画也要过一会才显示(即使已预缓存)。

**根因(已对真实源码确认)**:`JobScheduler`(`NeeView/JobEngine/JobScheduler.cs`)**严格按提交顺序**处理任务(`FetchNextJob` 取 `Queue.FirstOrDefault(!IsProcessed …)`)。原版 NeeView 只把**屏幕可见项**排进队列、且每次滚动都重排(可见项永远队首、秒出);但本魔改(02 原实现)把**整个列表的全部项按列表顺序**一次性 `LoadCore` → `Order`,而滚动时因传入的是同一个 `Items` 列表(顺序不变)→ `LoadCore` 里 `pages.SequenceEqual(_pages)` **命中 → 跳过、不重排**。于是 12 个 worker 从列表头(如 2001)按顺序啃,屏幕上(列表中段,如 2538)的封面要等前面几百个处理完才轮到 → 比原版还慢。

**修复(就地改写 `ListBoxThumbnailLoader.cs` 那条 `replace` 补丁的 text,marker 不变、不新增条目)**:`IsPreloadAllEnabled` 分支内改为——先用 `VisualTreeUtility.FindVisualChildren<ListBoxItem>` 收集当前**可见(已实体化)项**的 `Page`(`visiblePages`),再收集**整个列表全部项**的 `Page`、用 `HashSet<Page>` 排除已在可见集合里的(`restPages`),**顺序 = `visiblePages.Concat(restPages)`** 交给 `LoadCore`。这样:① 可见项排队首、优先生成 → 屏幕封面立即出;② 整夹其余项仍排在后面做后台预生成(保留 mod02 初衷);③ **滚动时可见集合变化 → `Concat` 出来的列表前缀变 → `SequenceEqual` 失配 → 重排 → 新可见项重新置顶**。

**为什么重排不会把已生成的活儿冲掉/抖动**:`JobScheduler.Order` 重排时,新旧任务是**同一集合只换顺序**——它对每个 order 用 `collection.FirstOrDefault(e => e.Key == order.Key)` **复用现有 `JobSource`**(保留其 `IsProcessed` 状态),`removes = Queue.Except(queue)` 因集合相同 = **空 → 不取消任何在途任务**;只是把未处理的可见项挪到队首,`FetchNextJob` 下次先取它们。故重排极廉价、不抖动。`PageThumbnailJobClient.Order` 又会过滤掉 `IsThumbnailValid` 的项,已在内存的封面不重复排。

**path/引用一致性**:`visiblePages` 用 `ListBoxItem.DataContext`、`restPages` 用 `Items`,两者是同一批 `FolderItem` 对象;`FolderItem.GetArchivePage()` 缓存 `_archivePage`、`GetPage()` 每次返回**同一个 `Page` 实例**,故 `HashSet<Page>`(引用相等)去重成立、可见项能从 `restPages` 里正确剔除。

**配合 04-N**:本修复让屏幕封面"立即出";04-N(池容量 200→2000)让大文件夹封面"常驻不变灰"。两者一起,大文件夹体验才完整(可见即出 + 全部常驻)。**注**:即便不调 04-N,本修复也已让可见封面秒出(只是滚到很远再滚回、被 200 池挤出的那些会重读一下)。

**状态**:沙箱干净 `f2e269702` 上 `build.py --patch-only`「新打 115、跳过 0」零失配;`ListBoxThumbnailLoader.cs` 打补丁后大括号 32/32、圆括号 75/75 配平,含 `visiblePages.Concat(restPages)` 与 `IsPreloadAllEnabled` 分支;`--no-reset` 下该补丁正确跳过(幂等)。✅ **2026-06-09 用户 Windows 实测通过**:开 1000 项大文件夹→屏幕封面立即铺出、滚到哪先出哪;关掉「预生成全部封面」开关则回原版(仅可见项、逐个懒加载)。

---

### 03 · 加密 ZIP 自动转 7-Zip(智能检测)

**目的**:NeeView 的标准 ZIP 解压用 .NET `System.IO.Compression`,**不支持加密 zip**;而密码池挂在 7-Zip 路径上。本魔改让"标准 ZIP 开着"时,遇到**加密** zip 自动改用 7-Zip 打开(密码池生效),**普通(无加密)zip 仍走标准解压**保持 .NET 原生速度。两全其美,无需关闭标准 ZIP。

**实际改动(`patches.py` 魔改 03,仅 `NeeView/Archiver/ArchiveManager.cs`)**:
- 在 `CreateArchive(string path, ...)` 里:取到 `GetSupportedType` 结果后,若类型是 `ZipArchive` 且 7-Zip 已启用 且 `IsEncryptedZip(path)` 为真,则把类型改成 `ArchiverIdentifier.SevenZipArchive`,再继续原有实例化流程。
- 新增私有方法 `IsEncryptedZip(path)`:**解析 zip 中央目录**(从文件尾找 EOCD 签名 50 4B 05 06,读中央目录偏移与条目数,逐条看每个中央目录头偏移8-9 的 GP-bit bit0),**任一条目加密即视为加密**。任何异常一律返回 false(当未加密走原路)。

**机制要点(关键设计,将来重写时务必遵守 ⚠️)**：
- **注入点必须是 `CreateArchive`,绝不能放 `GetSupportedType`**。`GetSupportedType` 被书架列举(`FolderItemFactory`/`FolderItem`)、搜索、播放列表、书签、拖放、`PageContentFactory` 等**高频**调用(列几百个文件就调几百次);在那读文件头会造成几百次磁盘 I/O、拖慢列举。而 `CreateArchive(string)` 是"压缩包真正被打开成实例"的**单点**,每个包只走一次,且上层 `CreateArchiveAsync` 有 `_cache` 缓存复用,开销可忽略。
- 检测只在"类型已被判定为 ZipArchive"之后触发,所以 `.cbz` 等被归入 ZIP 扩展名的也同样适用;无需自己再猜扩展名。
- 判断基于 zip 标准加密位,与加密工具(WinRAR/7-Zip/系统)无关。7z 经 7z.dll 支持 AES/ZipCrypto,接手后 `ArchiveKey` 密码池逻辑原样生效。
- `IsEncryptedZip` 用 `stackalloc Span<byte>`(代码库已有先例)+ 全异常兜底;path 在两种调用下都是真实磁盘路径(文件系统包=原文件;嵌套/网络包=已解出的临时文件)。

**已知取舍**:
- **解析中央目录、扫描所有条目**判断"整包是否加密"(任一条目加密即转 7z)。已修复早期"只读首个本地文件头"导致的漏判——有些 zip 第一项是目录/未加密项,旧逻辑会误判为不加密;现在扫全部条目,**第一项非加密但后面加密的包也能正确识别**(本机已实测:加密 zip 能打开并显示封面)。
- 用私有加密扩展但未置标准 bit0 的 zip(极罕见)可能漏判;主流工具都会正确置位。
- `IsEncryptedZip` 只读文件尾部的中央目录(几十~几百字节),不解压、不读全文件,开销极小;path 在两种调用下都是真实磁盘路径(文件系统包=原文件;嵌套/网络包=已解出的临时文件)。

**如何使用(给用户)**:标准 ZIP 保持开即可,无需任何设置。打开加密 zip 时自动转 7-Zip 并套用密码池。

**验证点(给接手 AI)**:标准 ZIP 开启下——① 用**池内密码**加密的 `.zip`,打开应**直接进**;② 普通无密码 `.zip` 正常打开(仍走标准 ZIP);③ 池外密码的加密 `.zip`,试完池内密码后弹手动框。

---

### 04 · 默认预设(合集)

> 这一节把所有"开箱默认值 / 性能"类改动集中在一起。**除 SQLite WAL 外,其余都是「默认值」,只在“全新无 Profile”时生效**(已有 Profile 时读 Profile 里的值;想让已有 Profile 套用,去对应设置项手动改一次即可)。WAL 是数据库行为,**编译后立即生效**。

#### 04-A · “允许文件操作”默认开

**目的**:原版 `SystemConfig.IsFileWriteAccessEnabled` 默认 `false`(关),导致首次启动的欢迎向导、以及设置里这一项默认都是关。改成默认 `true`(开),开箱即可删除/重命名文件。

**实际改动(`patches.py` 魔改 04-A)**:`NeeView/Config/SystemConfig.cs` 字段 `_isFileWriteAccessEnabled = false` → `true`。欢迎向导(`WelcomeDialog.xaml.cs`)里那个开关直接绑 `Config.Current.System.IsFileWriteAccessEnabled` 的值,所以一处改动,向导和设置页都默认开。

**重要范围说明 ⚠️**:这是**默认值**,只在"全新、还没有 Profile"时生效(首次启动 / 清空 Profile)。**已有 Profile 时**,启动读的是 Profile(`UserSetting.json`)里存的值,不会被默认值覆盖。若用户已有 Profile 又想改,直接在 设置 → 常规 → 文件访问 里开一次即可。

**验证点**:删掉/清空 Profile 后首次启动,欢迎向导里「允许文件操作」应为开;设置 → 常规 → 文件访问 → 允许文件操作 也为开。

---

#### 04-B · 默认字体与字号比例

**目的**:把默认字体设为 **Comic Sans MS**,字体比例 **130%**、菜单字体 **115%**、目录树字体 **100%**(面板比例保持原版 125% 未改)。

**实际改动(`patches.py` 魔改 04-B,共 4 条,全部在 `NeeView/Config/FontsConfig.cs`)**:全部在 `NeeView/Config/FontsConfig.cs`。比例存的是**小数倍率**(130%=1.3)。注意原版每个 scale 的 getter 都有"≤0 回退到默认值"的兜底,字体名的 getter 默认返回系统字体——所以:
- 字段默认值:`_fontScale 1.25→1.3`、`_menuFontScale 1.0→1.15`、`_fontName null→"Comic Sans MS"`;
- getter 兜底值同步改:`FontScale` 兜底 `1.25→1.3`、`MenuFontScale` 兜底 `1.0→1.15`;
- `FontName` getter 的 fallback:`?? SystemVisualParameters...MessageFontName` → `?? "Comic Sans MS"`(否则只改字段不生效)。

**重要范围说明 ⚠️**:同 04-A,只在"全新无 Profile"时作为首次默认生效;已有 Profile 时读 Profile 里存的值。用户已有 Profile 想用新字体的话,设置 → 窗口 → 字体 里改一次即可。

**验证点**:删掉/清空 Profile 后首次启动,设置 → 窗口 → 字体:字体为 Comic Sans MS、字体比例 130%、菜单字体比例 115%、目录树字体比例 100%。

---

#### 04-C/D · 性能预设 + SQLite WAL

**目的**:针对高配机器(用户机:Intel Ultra 9 285H,16 线程,32G RAM,NVMe)调高性能默认值,并优化缓存数据库写入。

**实际改动(`patches.py` 魔改 04-C / 04-D)**:

- `NeeView/Config/PerformanceConfig.cs`(04-C):三个字段默认值 —— `_cacheMemorySize 200→1024`(MB)、`_jobWorkerSize 4→12`、`_preLoadSize 5→10`。这三项 getter **不带兜底默认值**,所以只改字段即可。`MaximumSize`、`PreExtractSolidSize` 等保持原样。
- `NeeView/Database/Database.cs`(04-D):在 `InitializePragma()` 里原有 `PRAGMA auto_vacuum=full` 之后,追加 `PRAGMA journal_mode=WAL` + `PRAGMA synchronous=NORMAL`。该 `Database` 是缩略图缓存(`Cache.db`)和搜索索引共用的基类。

**为什么**:JobWorker 提到 12 让缩略图并发生成更快(配合魔改 02 预生成全部封面);1G 缓存让翻页/回看少重解码;预读 10 让顺序翻页更跟手;WAL 让"预生成全部封面"时的大量缓存写入更快、读写不互斥。

**重要范围说明 ⚠️**:性能三项是**默认值**,只在"全新无 Profile"时生效;已有 Profile 时读 Profile 里存的值(用户已有 Profile 想用新值的话,设置 → 内存与性能 里改一次)。WAL 是数据库行为,与 Profile 无关,**编译后立即对所有缓存库生效**。

**已知点 / 取舍**:
- WAL 会让 `Cache.db` 旁多出 `Cache.db-wal`、`Cache.db-shm` 两个伴随文件,属正常现象。Cache.db 在本地 `Profile` 文件夹(非网络盘),WAL 安全。
- JobWorker=12 对"一次性生成几百张封面"提速明显;但对"打开单个大 PDF 显示首页"帮助有限——那是 Pdfium 单线程渲染的固有成本,调并发救不了。
- 性能数字是基于 SQLite/.NET 常识的**预期**,未经编译实测。
- 缓存 1024MB 在 32G 机的上限(约 30G)内,不会被 `GetMaxCacheMemorySize()` 夹掉;JobWorker 12 在上限 `max(4, 核数)=16` 内。低配机器若套用此预设,这些值仍会被各自的 Clamp/Min 安全夹住,不会出错。

**验证点**:删掉/清空 Profile 后首次启动,设置 → 内存与性能:JobWorker=12、缓存内存=1024MB、预读=10。WAL 则可在 `Profile` 文件夹看到 `Cache.db-wal`/`-shm` 文件出现来确认。

---

#### 04-E · “恢复书架位置”默认开

**目的**:原版 `StartUpConfig.IsOpenLastFolder` 默认 `false`,启动后书架回到主页位置。改成默认 `true`,启动时**恢复上次浏览到的书架文件夹位置**。

**实际改动(`patches.py` 魔改 04-E,仅 `NeeView/Config/StartUpConfig.cs`)**:字段 `_isOpenLastFolder` 默认值改为 `true`。getter 无兜底,改字段即可。只改这一个,**不动**相邻的 `_isOpenLastBook`(打开上次的书)和 `_isOpenLastBookmarkFolder`(恢复书签文件夹位置)——它们保持原版默认 false。

**重要范围说明 ⚠️**:默认值,仅在"全新无 Profile"时生效;已有 Profile 时读 Profile 里存的值。用户已有 Profile 想要的话,设置 → 常规 → 启动设置 → 恢复书架位置 开一次即可。

**验证点**:删/清空 Profile 后首次启动,设置 → 常规 → 启动设置 →「恢复书架位置」应为开;且重启后书架停在上次浏览的文件夹。

---

#### 04-F · 顶部栏/面板自动隐藏延迟默认 0 秒(秒消失)

**目的**:全屏(F11)时鼠标移到顶部会浮出菜单/地址栏,原版鼠标移开后要延迟约 1 秒才隐藏。改成默认 0 秒——移开即**秒隐藏**。

**实际改动(`patches.py` 魔改 04-F,仅 `NeeView/Config/AutoHideConfig.cs`)**:字段 `_autoHideDelayTime` 默认值 `1.0 → 0.0`。getter 无兜底,改字段即可。对应设置项就是 设置 → 面板 →「自动隐藏面板的隐藏时间(秒)」。

**重要范围说明 ⚠️**:默认值,仅在"全新无 Profile"时生效;已有 Profile 时读 Profile 里存的值。用户已有 Profile 想立即生效的话,设置 → 面板 →「自动隐藏面板的隐藏时间(秒)」改成 0 即可(本魔改本质就是把这个设置项的出厂默认改成 0)。

**验证点**:删/清空 Profile 后首次启动,设置 → 面板 →「自动隐藏面板的隐藏时间(秒)」应为 0;全屏下鼠标移开顶栏即刻隐藏、不再卡 1 秒。

---

#### 04-G · 书架"内容"列表样式默认(图标原样 / 120 / 名称换行)

**目的**:书架"内容"样式默认是正方形小图(64),竖版漫画封面被裁、文件名单行截断。改默认为:**图标形状=原样**(完整不裁)、**图标大小=120**(更大)、**名称换行=开**(文件名多行完整显示)。

**实际改动(`patches.py` 魔改 04-G,仅 `NeeView/SidePanels/PanelListItemProfile.cs`)**:`ContentItemProfile` 构造函数默认值。参数顺序 `(imageShape, imageWidth, isDetailPopupEnabled, isImagePopupEnabled, isTextVisible, isTextWrapped, isTagVisible)`,改 `Square→Original`、`64→120`、`isTextWrapped false→true`,其余不动。

**重要范围说明 ⚠️**:默认值,仅"全新无 Profile"时生效;已有 Profile 时读 Profile 里存的值。用户已有 Profile 想立即生效的话,设置 → 面板 →「列表项目内容样式」里:图标形状选「原样」、图标大小拉到 120、名称换行开。

**验证点**:删/清空 Profile 后首次启动,书架(内容样式)下封面完整不裁、约 120 大小、文件名换行显示。

---

#### 04-H · 补译「系统托盘常驻」(⚠️ 待上游修复后可移除)

**目的**:设置 → 常规 →「Stay in the system tray」标题和说明在简体中文下显示**英文**。原因:上游 `zh-Hans.restext` 里 `SystemConfig.IsTaskTrayEnabled` 和 `.Remarks` 两条**键存在但值为空**,空值回退显示英文键名/英文。本条补上中文译文。

**实际改动(`patches.py` 魔改 04-H,仅 `NeeView/Languages/zh-Hans.restext`)**:把那两行空值替换为——标题「常驻系统托盘」、说明「为下次快速启动,关闭窗口后仍在系统托盘中继续运行。」(参照日文原文译)。replace 模式,anchor 是两行空值,marker 用译文片段保证幂等。

**⚠️ 待上游修复后可移除**:这是作者漏译。**将来 `git pull` 后若作者补了中文**,那两行不再是空值 → 本条 anchor 失配 → `build.py` 会**明确报错指出这一处**。届时确认作者已补译,即可从 `patches.py` 删除本条(04-H)。这是本项目中**唯一一条"预期会被上游淘汰"的补丁**,特此标注。

**验证点**:设置 → 常规,该项标题显示「常驻系统托盘」、说明为中文。

---

#### 04-I · 缩略图图像默认(分辨率 512 / 质量 90)

**目的**:缩略图(封面)图像默认分辨率 256、JPEG 质量 80,偏糊。改默认为**分辨率 512、质量 90**(格式 JPEG 本就是默认,未改),封面更清晰。

**实际改动(`patches.py` 魔改 04-I,仅 `NeeView/Config/ThumbnailConfig.cs`)**:字段 `_imageWidth 256→512`、`_quality 80→90`。512 在 `ImageWidth` 的 `PropertyRange(64,512)` 上限内;质量在 `Clamp(5,100)` 内。getter 仅夹边界,改字段即可。

**重要范围说明 ⚠️**:默认值,仅"全新无 Profile"时生效;已有 Profile 时读 Profile 里存的值(用户已有 Profile 想用的话,设置 → 常规 → 缩略图 →「缩略图图像设置」里把分辨率拉到 512、质量到 90)。**注意:改大分辨率后,已生成的旧缩略图缓存仍是旧分辨率,需清理缓存或重新生成才会变清晰。**

**验证点**:删/清空 Profile 后首次启动,设置 → 常规 → 缩略图:分辨率 512×512、质量 90。

---

#### 04-J · 「将视频作为书籍打开」默认关

**目的**:`MediaArchiveConfig.IsEnabled` 默认 `true`(视频会被当书籍打开),改默认为 `false`。getter 无兜底,改字段即可。设置位置:设置 → 文件类型 → 视频 →「将视频作为书籍打开」。仅"全新无 Profile"时生效。

#### 04-K · 补译书架右键「Book thumbnail」子菜单(⚠️ 待上游修复后可移除)

**目的**:书架右键的 `Book thumbnail` 子菜单 3 项(子菜单标题 / 设为缩略图 / 重新生成)在简体中文下显示英文——上游 zh-Hans 这 3 条是空值。补译为「书籍缩略图 / 将当前页设为缩略图 / 重新生成缩略图」。同 04-H 性质,**将来上游补译后 anchor 失配报错,届时删除本条**(仅 `zh-Hans.restext`)。

---

#### 04-L · 补译清缓存对话框(⚠️ 待上游补译后可移除)

**目的**:上游 #879 把"清理缩略图缓存"重写为「全部删除 / 清理无效项 / 取消」三选一对话框(见魔改 05),但简体中文把这些键留空——中文界面会显示英文。补译 6 个键:`CacheDeletedDialog.Title`=删除缩略图缓存、`.DeleteAll`=全部删除、`.ClearInvalid`=清理无效项、`.Deleting`=删除中...、`Message.DeleteFailed`=删除失败、`Message.DeleteSuccess`=删除成功(`Message.DeleteItems` 上游已有中文「已删除 {0} 个项目。」,保留不动)。同 04-H/04-K 性质,**将来上游补译后 anchor 失配报错,届时删除本条**(仅 `zh-Hans.restext`)。

#### 04-M · 默认关闭“已读”绿勾标记

**目的**:去掉书架里「打开过/在历史中」的书名后那个绿色 ✓(上游 `FolderItemIconOverlay.Checked`,图标 `ic_done_24px`,由 `IsVisibleHistoryMark` 控制)。

**实际改动(`patches.py` 魔改 04-M)**:`NeeView/Config/BookshelfConfig.cs` 字段 `_isVisibleHistoryMark = true` → `false`。它是 `[DefaultEquality]` 字段,保存时走 `DiffJsonConverter<BookshelfConfig>`(`TrimSaveData` 默认开)只写「非默认值」——用户从没手动开过它(一直是默认 true),故 Profile 里没存这项,改默认即生效。书签星标(`IsVisibleBookmarkMark`)不受影响,照常显示。

**范围/可逆**:同其它 04 子项,只在「全新无 Profile 或没手动设过该项」时生效;它本就是原生开关,随时可在 **选项 → 设置 → 书架 → 勾选「显示历史标记」** 重新打开。

---

#### 04-N · 书架缩略图内存池容量 200 → 2000(大文件夹封面常驻、滚动不变灰)

**目的**:大文件夹(用户「1000 个一夹」)里很多封面是灰的、滚过去又变灰,即使已预缓存。根因是书架封面 **jpeg 常驻内存的池子** `ThumbnailBookCapacity` 默认仅 **200**(`ThumbnailConfig.cs`,mod04 原先未动它)。

**机制(已对真实源码确认 ⚠️)**:`BookThumbnailPool : ThumbnailPool`(`Book/BookThumbnailPool.cs`)的 `Limit => Config.Current.Thumbnail.ThumbnailBookCapacity`。`ThumbnailPool`(`Thumbnail/ThumbnailPool.cs`)在 `Add` 时做 `Cleanup`:集合超过 **150% Limit** 先删失效项,超过 **120% Limit** 就把**最老的若干项 `Clear()`(`_image=null`)** 砍到 Limit。即容量 200 时,内存里最多 ~240 个封面 jpeg,**1000 项文件夹其余 ≥760 个必然是灰的**;封面被挤出后再滚回来,得重新 `InitializeFromCacheAsync`(读 `Cache.db` + 解码)——就是那一下"先灰再出图"。**预缓存救不了这个**:预缓存填的是磁盘 `Cache.db`,这里卡的是**内存池**。(解码后的 `ImageSource` 由 `ThumbnailLifetimeManagement`(`Lifetime=1000ms`)管,1 秒即释放,所以大头内存不是问题,常驻的只有 jpeg 字节。)

**实际改动(`patches.py` 魔改 04-N,仅 `NeeView/Config/ThumbnailConfig.cs`)**:字段 `_thumbnailBookCapacity = 200` → `2000`。它是 `[DefaultEquality]` 字段(同 04-M 的逻辑:用户没手动设过 → Profile 里没存 → 改默认即生效)。

**为什么 2000**:用户文件夹约 1000 项/个;2000 留足余量(`ThumbnailPool` 在 150% = 3000 才清、清到 2000,故 ≤2000 项的文件夹封面全部常驻不被挤出)。**内存**:池子只存 jpeg 字节,512/q90 单张约几十~百KB,2000 张约几十~一两百MB,32G 机可忽略;解码位图 1 秒释放、不累积。数字随时可在 **设置 → 常规 → 内存与性能 →「书籍缩略图容量」**(`ThumbnailConfig.ThumbnailBookCapacity`,在 缓存内存/预读/JobWorker 等同区块、列表偏下)按机器内存调整。

**配合 02-live**:04-N 让封面"全部常驻不变灰",02-live(可见项优先)让封面"立即出"。两者一起,大文件夹体验才完整。

**范围/可逆**:默认值,只在「全新无 Profile / 没手动设过该项」时生效;已手动设过的以 Profile 为准。低配机若嫌占内存,把它调小即可。

**验证点**:① 删/清空 Profile 后首次启动,设置 → 常规 → **内存与性能** →「书籍缩略图容量」应为 2000(它在「缩略图」页上面那个「内存与性能」页,不在「缩略图」页);② 预缓存过的 1000 项大文件夹,封面铺满后**来回滚动不再变灰**(全部常驻);③ 配合 02-live,打开大文件夹时屏幕封面立即出现。

---

### 05 · 清理缓存按钮显示缓存体积 + 全部删除后自动重启

**目的**:① 在 设置 → 常规 → 缩略图 的「清理缩略图缓存」按钮标题里,显示当前缓存占用大小,如「清理缩略图缓存(当前为 320.5 MB)」,方便随时了解缓存体积;② 上游 #879(`ad42ed12e`)已把"清理缩略图缓存"重写为「全部删除 / 清理无效项 / 取消」三选一对话框(全部删除=清光所有缩略图;清理无效项=只删源文件已不存在的僵尸缓存、保留有效封面)。本魔改让**「全部删除」成功后自动重启 NeeView 重建缓存,「清理无效项」不重启**(它没动有效封面、无需重建)。

**实际改动(`patches.py` 魔改 05a–05c;原 05d 已废弃)**:
- 05a(`SettingPageGeneral.cs`):新增静态方法 `GetThumbnailCacheSizeText()`——累加 `Database.DatabasePath`(Cache.db)及其 `-wal`/`-shm` 伴随文件大小(因 04-D 开了 WAL,伴随文件也占空间),换算 MB 保留 1 位小数;任何异常返回「未知」。
- 05b(`SettingPageGeneral.cs`):把「清理缩略图缓存」按钮的标题拼成 `... + "(当前为 " + GetThumbnailCacheSizeText() + ")"`。
- **05c(`SettingPageGeneral.cs`,2026-06-05 重写)**:在新版 `RemoveCache` 的结果判定 `string? caption = null;` **之前**注入一段——仅当用户选「全部删除」(`result.Command == deleteAllUICommand`)且删除成功(`progressDialog.Result == ProgressDialogResult.Completed`)时,`SaveDataSync.Current.SaveAll(true)` 先存设置(重启会禁止保存)、`App.Current.Reboot(...)` 重启、`return` 提前结束(跳过原本的"成功"提示框,直接重启);「清理无效项」与失败情形 `if` 条件不成立,照走上游原逻辑(弹结果提示、不重启)。
- ~~05d~~ **已删除**:旧设计是"清完弹 OKCancel 问是否重启"(键 `CacheClearedRebootDialog.Message`);新设计改为**自动重启、不再询问**,故该询问框与其中英译文一并移除。对话框/结果消息的简中补译改由 **04-L** 提供。

**为什么这样设计(2026-06-05 与用户敲定)**:
- 上游重写后两个选项本就齐全,无需新增;「清理无效项」保留有效封面,**没有重启重建的必要**;「全部删除」清光封面,重启重建最顺手 → 故只给"全部删除"挂自动重启。
- 严格说连"全部删除"也非必须重启(魔改02 打开文件夹会铺满、魔改08 可递归预缓存,下次打开自然重建),自动重启只是图省事一键重建;用户选择了"全部删除自动重启"。

**机制 / 取舍 ⚠️**:
- **静态快照**:设置页在打开那一刻构建,体积是那时读的。想看清理后的新数字需关闭设置页重开。做成实时刷新需改 ViewModel + 数据绑定,成本高、价值低,故不做(用户已确认方案 A)。
- 体积含 WAL/SHM,故与单看 Cache.db 文件可能略有出入,但更接近真实占用。
- marker 注意:05b 的 marker 不能用 `GetThumbnailCacheSizeText()`(05a 已引入该串会导致 05b 被误判跳过),改用拼接特征串 `"(当前为 " + GetThumbnailCacheSizeText()` 保证幂等(已验证)。05c 的 marker 用注释 `// [魔改] 全部删除后自动重启重建缓存`(注入文本含此注释,幂等)。

**验证点**:① 打开 设置 → 常规 → 缩略图,「清理缩略图缓存」按钮标题应显示「(当前为 X.X MB)」,数值与 Profile 下 Cache.db(含 -wal)实际大小相符;② 点「清理缩略图缓存」应弹出三选一对话框,中文显示「全部删除 / 清理无效项 / 取消」(04-L 补译生效);③ 选「全部删除」→ 进度条走完后 NeeView **自动重启**(不再弹询问框);④ 选「清理无效项」→ 删完弹「删除成功 / 已删除 N 个项目。」提示、**不重启**。

---

### 06 · 手动隐藏(从书架移除,不删硬盘文件)

**目的**:右键书架里的漫画文件或文件夹 →「隐藏」,该项从书架显示中消失(**硬盘文件完全不动**)。用于把不想看到的项藏起来。按**完整路径**标识(移动文件后隐藏失效,但不会误伤同名文件)。

**实际改动(`patches.py` 魔改 06a–06j)**:
- **06a/06b 配置层(`BookshelfConfig.cs`)**:新增 `StringCollection HiddenPaths`(隐藏的完整路径列表,仿现有 `ExcludeRegexes`)+ `IsHiddenPath(path)` 判断方法。`[PropertyMember]` 自动持久化到 UserSetting.json,重启仍隐藏。
- **06c 过滤层(`BookshelfExcludeFilter.cs`)**:在 `Filter()` 现有正则排除之后,追加一段——把 `EntityPath.SimplePath` 命中 `HiddenPaths` 的项也滤掉。一处覆盖所有书架列表。
- **06d/06e/06f 命令(`FolderListBox.xaml.cs`)**:仿 `RegenerateThumbnailCommand` 新增 `HideItemCommand`(声明+绑定+Execute)。Execute 把选中项(限 `IsFileSystem()`)的 `EntityPath.SimplePath` 加入 `HiddenPaths`,再 `await _vm.Model.RefreshAsync(true, true)` 刷新书架。
- **06g 菜单(`FolderListBox.xaml.cs`)**:在右键"普通文件系统项"分支(文件/文件夹共用)的 `Book thumbnail` 子菜单之后,加分隔线 +「隐藏」菜单项。
- **06h/06j 本地化**:`BookshelfItem.Menu.Hide`(菜单文字)、`BookshelfConfig.HiddenPaths`(设置页列表标题+说明),中英新增。
- **06i 隐藏项管理(`SettingPagePanels.cs` + 新建 `_Mod/HiddenPathsEditWindow.cs`)**:设置 → 面板 → 书架 里放一个「编辑」按钮(不再用 150px 小框,避免滚轮与外层设置页冲突),点击弹出独立大窗口 `HiddenPathsEditWindow`(760×520):列出全部隐藏路径,支持添加 / 删除(多选)/ 全部清除;关闭窗口时 `BookshelfFolderList.Current.RefreshAsync` 刷新书架使变更生效。**注**:06i 这条 replace 补丁的 marker 必须用新 text 里存在的串(`HiddenPathsEditWindow`),否则幂等检测失效会重复打。

**机制要点(给接手 AI)**:
- 隐藏不动硬盘,只是书架构建时被过滤掉。复用 `BookshelfExcludeFilter.Filter` 这个唯一注入点。
- 持久化:`HiddenPaths` 是 `[PropertyMember]` + `[JsonConverter]` 的 StringCollection,退出保存设置时自动序列化。`HideItemCommand` 里 `.Add()` 改的是其内部 Items,保存时一并写入。
- 文件夹隐藏 = 整个文件夹项从书架消失(其内容自然也不显示)。
- **范围**:此功能只作用于书架(侧栏)显示。`EntityPath.SimplePath` = 项的真实完整路径。
- 路径匹配大小写不敏感(`ConainsOrdinalIgnoreCase`);`StringCollection.ValidateItem` 不改输入,匹配可靠。

**验证点**:① 右键一个文件/文件夹 →「隐藏」→ 它从书架消失;② 重启 NeeView 仍隐藏;③ 设置 → 面板 → 书架 →「隐藏的项」列表里能看到它、删掉该行后它重新出现在书架;④ 硬盘上文件始终在。

---

### 07 · 书架右键菜单完整编辑器

**目的**:在 设置 → 面板 → 书架 →「右键菜单」里可视化编辑书架"普通文件/文件夹"的右键菜单——TreeView 拖拽排序/分组,增删项/分隔/分组/重命名/恢复默认。A 类静态项(打开/删除/重命名/剪切/复制/资源管理器/隐藏/缩略图子菜单)可自由编排;B 类动态项(带 ▸,如书签勾选/标签/外部应用/复制移动到文件夹/子文件夹/历史/播放列表)可显隐但不可入组(动态项无法预先编排,技术限制)。

**实际改动**:`NeeView/_Mod/` 下新建 `BookshelfMenuItem.cs`(模型:4类型枚举+树形+工厂+Clone)、`BookshelfMenuCommandTable.cs`(命令注册表,含 Precache)、`BookshelfMenuDefault.cs`(默认顺序,Precache 在顶部)、`BookshelfMenuNode.cs`(TreeView 绑定节点)、`BookshelfMenuDialogs.cs`(添加命令/重命名对话框,含拖拽插入线 InsertLineAdorner);`NeeView/Setting/BookshelfMenuEditControl.xaml(.cs)`(编辑器控件);改 `BookshelfConfig.cs`(加 `ContextMenuItems` 持久化)、`FolderListBox.xaml.cs`(硬编码菜单改为读配置生成)、`SettingItem.cs`、`SettingPagePanels.cs`、`*.restext`。

**机制要点 ⚠️**:命令是 `FolderListBox` 私有 RoutedCommand(非全局 CommandTable),主视图那套 MenuTree 编辑器无法复用,故全部新建。拖拽用 WPF 原生 DoDragDrop(不依赖 NeeView 的 MenuTree 拖拽设施,模型不兼容)。编辑器体验已多轮打磨:DisplayText 去助记符下划线、TreeView 滚轮穿透到外层设置页、拖拽就近吸附(FindNearestItem 按 Y 找最近项+上下半区判断插前/插后/进组)、消除禁止光标、插入线视觉反馈、拖后清选中态(消除残留白框)、点击项时阻止 RequestBringIntoView 自动滚动(否则点靠近底部的项列表会跳,让它保持静止)、支持 Ctrl+左键加选/Shift+左键范围选用于批量删除(多选高亮直接设 TreeViewItem 背景,普通左键清空多选;重命名/拖拽仍单选)。「添加项」按钮文字改为「添加」。**重命名修复**:原 DisplayText 对命令项/动态项只读注册表默认名、忽略用户自定义名(Source.Name),导致重命名后编辑器列表不变(但实际右键菜单其实已生效);改为优先用 Source.Name(与实际菜单 ResolveMenuLabel 一致),且 Rename 后 LoadFromConfig 重建树刷新显示。

**注意**:用户已有 UserSetting.json 里存了旧的 ContextMenuItems,要看到新默认(如 Precache 项)需点编辑器里「恢复默认」。

**验证点**:设置 → 面板 → 书架 →「右键菜单」能打开编辑器,拖拽排序/分组/增删/恢复默认都正常,书架右键菜单按编辑结果显示。

---

### 08 · 完整版预缓存(递归封面预生成)

**目的**:书架右键文件夹 →「预缓存封面(含子文件夹)」,递归遍历所有压缩包/PDF,逐个真实生成封面缩略图存入 Cache.db,带进度窗口和完成报告。用于一次性把整个库的封面都缓存好,之后秒开。

**实际改动**:`NeeView/_Mod/BookshelfPrecacheRunner.cs`(递归收集 + 逐个 `new Page(new ArchivePageContent(CreateTemporaryEntry(file),null))` + `Thumbnail.IsCacheEnabled=true` + `await LoadThumbnailAsync` 存缓存 + Dispose)、`NeeView/_Mod/PrecacheProgressWindow.cs`(自定义进度窗口);改 `FolderListBox.xaml.cs`(命令+菜单)、`SystemConfig.cs`(浮条位置记忆字段 PrecacheFloatMarginX/Y)、`*.restext`。注册进 07 的菜单命令表(默认在顶部)。

**菜单显示范围(2026-06-08)**:「预缓存封面」**只在文件夹(目录)上显示**——`FolderListBox.xaml.cs` 的菜单工厂 `CreateBookshelfCommandItem` 的 `case "Precache"` 改成 `item.IsDirectory ? 菜单项 : null`;返回 null 时被 `BuildBookshelfContextMenu` 里的 `if (element != null)` 过滤掉、不加入菜单。**单本书(压缩包文件)右键不再出现此项**——单本书的封面在书架显示出来时就已经缓存,再单独「预缓存封面」无意义;此功能只对文件夹(递归缓存夹内所有书封面)有用。改的是 patch（含 `case "Precache"` 的那条 replace）的 text,不新增补丁、仍 114。

**进度窗口特性**:带 [隐藏][取消];正常态固定宽 360(文件名长短不左右抖,长名截断20字);点隐藏缩成浮条(进度条+右端百分比),非模态;浮条默认在**主窗口右下角内侧**、可拖拽移动(记住距右下角像素偏移、存 SystemConfig 跨重启持久化)、隐藏期间实时跟踪主窗口移动/缩放/最大化(监听 LocationChanged/SizeChanged/StateChanged,最大化用工作区算位置+兜底拉回屏幕内)、单击恢复正常态。

**浮条恢复崩溃修复(2026-06-08)**:点隐藏缩成浮条后、再点浮条恢复正常态时,旧版会崩(`System.InvalidOperationException: 指定的元素已经是另一个元素的逻辑子元素`)。根因:`ToggleMinimize` 缩条时 `_rootGrid.Children.Clear()` 只把承载 `_normalContent` 的 `Border` 移出网格,但该 `Border` 仍持有 `_normalContent`;恢复时又 `new Border { Child = _normalContent }`,而 `_normalContent` 还挂在旧 Border 上 → WPF 不允许同一元素同时是两个元素的逻辑子元素 → 抛异常退出。修复:恢复分支 `new Border` 之前先 `if (_normalContent.Parent is Border ob) { ob.Child = null; }` 把它从旧容器摘下(对反复「缩条↔恢复」每轮都成立;旧 Border 摘空后无引用被 GC)。改 `_Mod/PrecacheProgressWindow.cs` create text,不新增补丁、仍 114。

**完成框 Owner 修复(2026-06-08)**:预缓存「完成报告」框和「无文件」提示框,旧版直接 `new MessageDialog(...).ShowDialog()` **没设 Owner** → 成了独立顶层窗,两个毛病:① **不受老板键(Alt+X)影响**——老板键隐藏的是主窗,而这框没被主窗拥有,故主窗藏了它不藏;② **后台预缓存时打开设置窗**,框夹在主窗与设置窗之间(被设置窗挡住),却因 `ShowDialog` 模态把设置窗禁用 → 设置窗点不动、框也够不着。修复:加 `GetDialogOwner()`(取当前活动且可见的窗口、兜底 `MainWindow.Current`),两处 `MessageDialog` 都 `dlg.Owner = GetDialogOwner()` 后再 `ShowDialog()`。于是没开设置时 Owner=主窗 → 老板键隐藏主窗会连带隐藏被它拥有的框(WPF:owner 隐藏则 owned 窗口随之隐藏);开了设置时 Owner=设置窗 → 框浮在设置窗之上、可点。`BossKeyHotKey` 是全局热键(`RegisterHotKey` 注册在主窗 HWND),模态框开着也能经主窗消息钩子触发 WM_HOTKEY,故隐藏照常生效。改 `_Mod/BookshelfPrecacheRunner.cs` create text(并加 `using System.Linq;`),不新增补丁、仍 114。

**老板键再加固:也隐藏「主窗口之外的弹窗」(2026-06-19,通用方案,计数不变仍 233,改 mod09 `_Mod/BossKeyHotKey.cs` text)**:上面 Owner 法只保了预缓存「完成框/无文件框」;但「**清除缓存确认框**」「**预缓存进度窗**」(`PrecacheProgressWindow`)这类独立窗口仍可能不被老板键(Alt+X)隐藏。根因:作者 `AppState.SuspendAsync` 隐藏时只 `MainWindow.Root.Visibility=Collapsed`(折叠主窗内容)+ 关设置窗,**根本不枚举其它 `Window`**。改为**通用做法**:老板键隐藏分支在 `SuspendAsync` 前调 `HideAuxWindows()`——枚举 `Application.Current.Windows`、把主窗(`MainWindow.Current`)之外**当前可见**的窗口一并**移出可见屏幕**(`Left/Top=-32000`、记下原位置)并记入 `_hiddenAuxWindows`;恢复链 `_window.Show()` 之后调 `RestoreAuxWindows()` 移回原位置。**⚠ 最初版用 `Visibility=Hidden` 藏,踩坑**:模态框(`MessageDialog` 经 `ShowDialog()` 显示)被改 `Visibility` 会破坏其模态状态 → 之后点按钮设 `DialogResult` 抛 `InvalidOperationException: 只能在创建 Window 并且作为对话框显示之后才能设置 DialogResult`(对确认框按两次老板键藏→显再点取消即崩);故改成**移出屏幕**=视觉消失但 `Visibility` 不变、模态完好、`DialogResult` 可正常设。这样确认框/进度窗/未来任何弹窗都跟老板键一起藏/显,无须逐个设 Owner。沙箱干净 `764fea1a7` 233/0、`BossKeyHotKey.cs` 词法括号配平(净 0/0/0)。🚧 待 Windows 实测。

**加密包处理(第3步)**:预缓存期间设 `ArchiveKey.SuppressDialog=true`——加密包只静默试密码池,**密码池没命中也不弹手动框**(否则会打断批量)。用 `page.Thumbnail.IsValid` 精确判断成功(真生成封面)vs 跳过(加密没解开/损坏)。注:加密失败与损坏不强行细分(LoadThumbnailAsync 吞异常+临时 entry 无加密标志,区分不可靠)。

**已知取舍**:加密包封面生成比普通包慢,是 7z 解密加密内容的固有成本(COM 开销+须解密验证),与密码池试错无关(单密码时无试错),无法通过改密码顺序优化。

**验证点**:右键文件夹 →「预缓存封面」→ 递归跑完报告"成功 X/跳过 Y";加密包(密码池能解开的)能生成封面;密码池没命中的包静默跳过不弹框;浮条拖动后跟踪主窗口、跨重启记住位置。

---

### 09 · 老板键(全局热键版,Alt+X 一键隐藏/恢复)

**目的**:按 **Alt+X** 一键把 NeeView 隐藏到后台(收进托盘),**再按一次 Alt+X 恢复**——即使 NeeView 隐藏在后台、焦点不在它身上也能用同键叫回。

**实际改动**:`NeeView/_Mod/BossKeyHotKey.cs`(用系统级 `RegisterHotKey` 注册全局热键 + `HwndSource.AddHook` 处理 WM_HOTKEY,固定 Alt+X=MOD_ALT|MOD_NOREPEAT+0x58);`NeeView/NativeMethods.txt`(加 RegisterHotKey/UnregisterHotKey/WM_HOTKEY/HOT_KEY_MODIFIERS 供 CsWin32 生成);`NeeView/MainWindow/MainWindow.xaml.cs`(SourceInitialized 时创建并 Initialize);`NeeView/System/AppState.cs`(**修 ShowWindow 恢复 bug**)。

**机制要点 ⚠️**:① NeeView 命令体系的快捷键只在窗口有焦点时有效,隐藏后收不到,所以必须用**系统级全局热键**(RegisterHotKey),它由 Windows 捕获,后台也能响应。WndProc **不能因 IsSuspended 跳过**——隐藏态正是要响应热键来恢复的时候。② **ShowWindow 恢复 bug**:原 `AppState.ShowWindow` 先 `GetLatestActiveProcess` 找活动进程并 AppActivate,但窗口 Hide 后进程句柄仍在,会误把"隐藏态的自己"当活动进程去激活(对 Hidden 窗口无效)→ 永远恢复不了;修复为 **IsHideWindow 态优先走 ResumeAsync 恢复自己**,不去找活动进程。

**状态记忆(恢复隐藏前状态)**:SuspendAsync 会关掉设置窗口、关闭当前书(RequestUnload)、ResumeAsync 不保留全屏态。在 BossKeyHotKey.Toggle 隐藏前记下 _wasFullScreen(WindowStateManager.IsFullScreen)、_wasSettingOpen(SettingWindow.Current!=null)、_lastBookAddress(BookHub.Current.Address 当前看的书);恢复走 ResumeAndRestoreAsync:await ShowWindow() 后,依次——若有记住的书且当前没书则 BookHub.RequestLoad 重新打开(NeeView 自动恢复到上次页)、若隐藏前全屏则 SetFullScreen(true)、若隐藏前设置窗口开着则 OpenSettingWindow()。

**焦点修复 · 历史(2026-06-05,attempt 1/2/3,均失败)**:最初三次尝试——① `ForceForeground` 立刻强抢一次前台(`AttachThreadInput`+`SetForegroundWindow`+`BringWindowToTop`+`Activate`);② 加固:再推迟到 Dispatcher `Background` + `DispatcherTimer` 补两拍(200/400ms)重抢;③ 把重开书 option 从 `BookLoadOption.IsBook` 改成 `IsBook | FocusOnLoaded` 补"视图焦点"——用户**都已编译实测,全部没修好**(隐藏期间在外部按键如回车后再 Alt+X 恢复,滚轮翻页 + Esc/F11 照旧失灵,必须手点一下窗口才接管;编译仅一个无害 `CS4014` 警告)。

**❌ 第四次"前台"假设(attempt4)——已被诊断日志推翻**:上一版接手 AI 读源码后判断"唯一根因=窗口没抢到前台"(`FlushWindowState` 的 `window.Activate()` 被前台锁拒绝),据此做 attempt4:多重抢前台(`SPI_SETFOREGROUNDLOCKTIMEOUT=0`+`AttachThreadInput`+`BringWindowToTop`+`SetForegroundWindow`+`Topmost` 翻转)+ 延迟重试 + **内置诊断日志**(写 `%TEMP%\nv_boss.log`,记 `GetForegroundWindow()==本窗口? / IsActive / Keyboard.FocusedElement`)。**用户编译实测:仍没修好。** 但这次拿到了决定性数据——

**✅ 诊断日志结果(决定性,2026-06-05)**:`nv_boss.log` 显示从恢复第一拍(`after-ShowWindow`,在任何抢前台动作之前)起,**`fg=True`、`active=True` 全程为真,focus 也很快落到主视图 `Grid`**。即**窗口自始至终就是前台 + 激活 + 有 WPF 焦点**。⟹ "窗口没抢到前台"的假设是错的,attempt1~4 全在解一个不存在的问题;`window.Activate()` 其实成功了、前台锁没拦。

**✅ 真正根因(第五次,attempt5)= HWND 没拿到 Win32 键盘焦点**:窗口虽是前台/激活、WPF 逻辑焦点也设了(`focus=Grid`),却**没向系统发 Win32 `SetFocus`**——这是 WPF 经 `Hide()`→`Show()` 复显的已知坑(WPF 误以为窗口本就有焦点,跳过了 SetFocus)。而**键盘消息(WM_KEYDOWN)和滚轮消息(WM_MOUSEWHEEL)都是系统投给"焦点窗口(focus window)"、不是"前台窗口(foreground window)"**——两者可不一致。于是焦点窗口仍是外部那个程序 → NeeView 收不到键/滚轮(两者同时死,正好对上症状);手点一下(点击→`WM_MOUSEACTIVATE`→系统 `SetFocus`→`WM_SETFOCUS`→WPF 重新接管)才恢复。〔仍成立的事实:F11/Esc 命令绑在 MainWindow 上(`MainWindow.xaml.cs:110` 的 `RoutedCommandBinding`),窗口内有焦点即可路由;`FirstLoader.cs:130` 重开书已带 `FocusOnLoaded`——这两点 attempt5 仍依赖。〕

**🔧 attempt5(对症"Win32 键盘焦点",但抢前台删过头)**:把恢复后的 `ForceForeground` 换成 `ReengageInputFocus` = `SetForegroundWindow`+`SetActiveWindow`+**`SetFocus(hwnd)`**+`Activate`,并**去掉**了 attempt4 的抢前台机制(误信日志 `fg=True` 是常态)。**用户实测:外部只是"按回车"(前台容易抢回)的 case 修好了 ✓;但外部窗口牢牢占前台(如点链接真跳转)的 case 仍坏 ✗** —— 因为那种情况下光一句 `SetForegroundWindow` 会被前台锁拒绝,没真抢回前台,`SetFocus` 落空。

**🔧 本次修复(attempt6 = attempt4 ∪ attempt5,两半都补)**:重写 `BossKeyHotKey.cs` 的 `ReengageInputFocus`——**先**用 attempt4 那套强力抢前台(`SystemParametersInfo(SPI_SETFOREGROUNDLOCKTIMEOUT,0)` 临时解前台锁 + `AttachThreadInput` 绑前台线程输入队列 + `BringWindowToTop`/`SetForegroundWindow` + `Topmost` 翻转),**抢到、解绑之后再** `SetActiveWindow` + **`SetFocus(hwnd)`** 补 Win32 键盘焦点(触发 `WM_SETFOCUS` 让 WPF 重新接管键盘+滚轮)。顺序关键:`SetFocus` 放在 `AttachThreadInput` 解绑之后(此时本线程已是前台线程,焦点设得干净、不被 attach 状态搅乱)。保留 `DispatcherTimer` 150/250/400ms 重试(等 NeeView 把焦点在 `null→ListBoxItem→Grid` 间异步挪定后再补一次)、`FocusOnLoaded` 兜底、设置窗口/全屏还原。全部 Win32 仍**自包含 `DllImport` 在 `BossKeyHotKey.cs`**,未改 NativeMethods.txt。**保留输入到达探针**:恢复后 15 秒内把到达窗口的按键/滚轮也记日志(`INPUT-KEY`/`INPUT-WHEEL` + `IsKeyboardFocusWithin`)——万一仍有 case 失灵,据 `fg`(前台抢到没)+ `INPUT` 行(输入到窗口没)判断,再决定是否上最重手段(`最小化→还原` 强制 OS 整体重激活)。

**✅ 状态:已实现并实测可用(2026-06-05 用户在 Windows 编译实测,attempt6 把"按回车""点链接真跳转"等外部牢占前台的 case 全部修好,反复切换正常)。** 诊断日志(`EnableDiagLog`)已关闭(若将来上游更新后焦点 bug 复发,把它改回 `true` 重编即可重新拿 `%TEMP%\nv_boss.log` 定位)。补丁层亦经真实 `build.py --patch-only` 在干净 `3b62b9c9f` 上验证(当时 84 条零失配、`BossKeyHotKey.cs` `[新建]` 且与源文件字节一致、三个 mod09 文件括号配平 BossKey 大括号 59·圆括号 171、AppState 37、MainWindow 124、`RequestLoad` 5 参签名匹配)。**教训(更新版)**:① 定位"恢复后输入失灵"别想当然——前四次假设"前台/激活"且都错,是诊断日志拿到 `fg/active/focus` 真实值才发现真正缺的是 **Win32 键盘焦点(`SetFocus`)**;② 但"前台"也不是完全无关——外部窗口牢占前台时仍得先抢回前台 `SetFocus` 才有效,所以**两半(前台 + Win32 焦点)缺一不可**(attempt5 删过头才暴露这点)。能加诊断日志拿真实数据时,别纯靠推理。

**改键**:当前固定 Alt+X。全局热键改键需自己存配置+重新注册(较复杂),暂未做。

**验证点**:按 Alt+X 窗口消失;在桌面或别的程序里再按 Alt+X 窗口恢复;反复切换稳定。**重点回归(本次修复)**:隐藏后**先在外部窗口按一下回车等键**,再 Alt+X 恢复 → 应能**直接用滚轮翻页、Esc/F11 退全屏,无需先手点窗口**。

**🔧 修「在 dav 书架/书界面按老板键回来,书架跳回『此电脑/书签』或本地路径」(2026-06-18,计数不变仍 203,只改 `_Mod/BossKeyHotKey.cs` 内容)**:
- **现象**:在某 dav 目录(或正看某 dav 书)按 Alt+X 隐藏、再 Alt+X 恢复后,左侧书架不在原 dav 目录,而是跳到根(只剩 PC + 书签)或上次的本地路径;有时连书也变回上次的本地书。
- **根因(读 `AppState`/`AppSequence`/`FirstLoader`/`FolderList` 源码定位)**:① 隐藏走的 `AppState.SuspendAsync` 会 `BookshelfFolderList.RequestPlaceClear()` 把书架位置清空;② 复显走 `ShowWindow → ResumeAsync → AppSequence.ReinitializeAsync → StartAsync → LoadFirstBook → new FirstLoader().Load()`,**`FirstLoader` 按 `Config.StartUp.LastBook/LastFolder` 重设**——若 `IsOpenLastFolder` 关,`SetFolderPlace` 落到 `GetFixedHome()`(=此电脑/书签)或上次的本地 `LastFolder`,且 `LoadBook` 还以 `isRefreshFolderList` 触发把书架同步到书所在目录;③ 这些都是**本地/根的快速 `SetPlaceAsync`**,而 **dav 目录构建要走一次网络列目录、很慢**;`FolderList.SetPlaceAsync` 每次新调用都会取消上一次在飞的构建(`FolderList.cs` line519,`_updateFolderCancellationTokenSource.Cancel()`),**慢的 dav 构建必然被后到的快构建取消**,而被取消的构建**静默不改 place**(`CreateFixedFolderCollectionAsync` 返 `null`、`SetPlaceAsync` 不更新、且无 home 兜底)→ 书架最终停在根/本地。原本 mod09 已在恢复后 `RequestPlace(_lastBookshelfPlace)` 想纠回 dav,但**它一次性发出、立刻被 FirstLoader/书加载的后续快构建取消**,所以对 dav 失效(对本地路径恰好够快、看着没事)。
- **修**:复显时不再一次性抢(会被取消),改为新方法 `RestoreDavPlaceAndBookAsync`:**每轮先 `await BookshelfFolderList.Current.WaitAsync()`(等书架忙锁释放=上一次 `SetPlaceAsync` 构建真正结束)→ 再比对当前 `Place.SimplePath` 与隐藏前的 dav 目录;不一致才 `RequestPlace` 一次,然后 `Task.Delay`(让刚发起的 dav 构建抢到忙锁,下一轮 `WaitAsync` 才会等它完成)**,最多 4 轮、落对即收工。这样**我们发起的 dav 构建不会被自己的下一次调用打断**,也能盖过 FirstLoader 的本地/根设值。书同理:仅当当前 `BookHub.Address` 不是隐藏前那本时才 `RequestLoad`(只前两轮、`isRefreshFolderList=false` 不再触发竞争性书架刷新、避免反复重载打断翻页)。
- **为何不直接改核心 `SetPlaceAsync`**:那条取消逻辑是所有导航共用的(切目录要取消上一次构建),动它影响面大;把纠正逻辑收在 mod09 自己的恢复路径里(等空闲再纠)最稳、零副作用。
- **诊断**:`EnableDiagLog` 仍开着,`RestoreDavPlaceAndBookAsync` 每轮写一行 `place-restore#N placeOk=.. cur=..` 到 `%TEMP%\nv_boss.log`,若仍跳错可据此看是「没纠回(placeOk 一直 False)」还是「纠回又被别处改走」。
- **验证**:`BossKeyHotKey.cs` 词法 0/0/0、双基准 203/0、applied 文件逐字节 == 工作树。**待用户编译实测**:在 dav 目录/书界面按两下 Alt+X,恢复后书架应回到原 dav 目录(可能先闪一下根/本地、随后被纠回,属正常——dav 列目录有网络延迟)。

---

### 10 · 加密压缩包封面修复

**目的**:加密压缩包在书架/预缓存里**显示不出封面**(是空白图)的修复。

**实际改动(仅 `NeeView/Page/ArchivePageThumbnail.cs`)**:`LoadThumbnailAsync` 里生成缩略图时,把 `pageContent.Decrypt = false` 改成 `true`。

**机制要点 ⚠️**:NeeView 原本生成压缩包封面缩略图时显式 `Decrypt=false`(不解密),对加密包就读到加密字节 → 生成空图(而空图也让 IsValid=true,所以预缓存会误报"成功"但实际空白)。改成 `true` 让加密包也解密生成封面;配合密码池(自动给密码)+预缓存静默模式(不弹框),加密包封面正常。**只改缩略图那处,不动正文阅读路径**(`ArchivePageContent.cs` 的 Decrypt=false 保持不变)。

**注意**:之前预缓存若已存了空图缓存,需清理缩略图缓存(设置里那个按钮)后重新预缓存,才能看到新封面。

**验证点**:加密 zip(密码池能开的)在书架显示封面;预缓存后封面正常出现(非空白)。本机已实测:加密 zip 能打开、有封面。

---

### 11 · 设置窗口里按 F11 也能切全屏

**目的**:在设置窗口打开时按 F11 也能切换主窗口全屏(原本设置窗口吞掉 F11 没反应)。

**实际改动(仅 `NeeView/Setting/SettingWindow.xaml.cs`)**:`SettingWindow_KeyDown` 里原本只处理 Escape(关窗),加一个 F11 分支 → 调 `MainViewComponent.Current.ViewWindowControl.ToggleWindowFullScreen(null)`(与 ToggleFullScreenCommand 同一入口)。

**机制要点 ⚠️**:设置窗口是独立 Window,有自己的键盘焦点,F11 被它接收但原本不处理,主窗口的 F11 命令也就收不到。直接在设置窗口的 KeyDown 调全屏切换即可。

**11-2 设置窗口实时跟随主窗口尺寸**:原版设置窗口尺寸=打开瞬间主窗口尺寸-100(居中),导致"先开设置再F11"和"先F11再开设置"两种方式大小不一。改为打开后监听主窗口 SizeChanged/LocationChanged/StateChanged,设置窗口实时同步(尺寸=主窗口-100、居中于主窗口,最大化用工作区算)。**另修**:F11 切全屏会把焦点抢到主窗口导致设置窗口 Esc 关不掉,F11 处理里加 this.Activate()+Keyboard.Focus(PageContent) 把焦点拿回来。

**验证点**:① 打开设置窗口,按 F11 → 主窗口全屏/非全屏切换,设置窗口尺寸跟着同步、保持居中;② 拖动主窗口边缘改大小 → 设置窗口实时跟随;③ F11 切全屏后设置窗口 Esc 仍能关闭;④ 两种打开顺序(先设置后F11 / 先F11后设置)设置窗口大小一致。

---

### 12 · 全屏时 Esc 退出全屏(等价 F11)

**目的**:主窗口处于 F11 全屏时,按 **Esc** 退出全屏(等价于再按一次 F11)。原本主窗口的 Esc 只用于取消待处理项(剪切/移动的 pending 操作),无法退出全屏。

**为什么用硬编码、不走"默认快捷键"**:NeeView 自带「退出全屏」命令(`CancelFullScreenCommand`),理论上给它设个默认快捷键 Esc 也行,但默认快捷键**只对全新 Profile 生效**——用户已有 Profile、命令快捷键表已存在,新默认会被挡住(和魔改04 各默认值同样的 Profile 限制)。用户要"编译后立即生效、不手动绑、不重置 Profile",故采用**硬编码行为**:直接在主窗口的 Esc 处理里加判断,不经过快捷键系统、不依赖 Profile。

**实际改动(`patches.py` 魔改 12,仅 `NeeView/MainWindow/MainWindow.xaml.cs`)**:
在 `MainWindow_PreviewKeyDown` 的 `if (e.Key == Key.Escape)` 块里,原有 `PendingItemManager.Current.Cancel();` 之后追加:若 `MainViewComponent.Current.ViewWindowControl.IsFullScreen` 为真,则调 `SetWindowFullScreen(this, false)` 退出全屏并 `e.Handled = true`。非全屏时这段不执行,Esc 行为完全不变。

**机制要点(将来重写时看这里 ⚠️)**:
- 判断/退出全屏走 `MainViewComponent.Current.ViewWindowControl`(类型 `IViewWindowControl`,接口上有 `IsFullScreen` getter 和 `SetWindowFullScreen` 方法)——与 `ToggleFullScreenCommand`、mod11 用的是同一入口,稳定可靠。
- 用 `SetWindowFullScreen(false)`(明确"退出")而非 `ToggleWindowFullScreen`,因为已被 `IsFullScreen` 判断包住,只会在全屏时触发=退出,不会误进全屏。
- 保留了原 `PendingItemManager.Current.Cancel()`:全屏时按 Esc 会先取消待处理项(若有,通常无)再退出全屏,不破坏原行为;非全屏时只取消待处理项(同原版)。
- **范围**:只改主窗口(`MainWindow`,非浮动模式的常见情况)。浮动主视图窗口(`MainViewWindow`,`MainView.IsFloating`)的 Esc=关窗逻辑**未动**——浮动全屏时 Esc 关窗本身也会结束全屏,行为可接受。

**为什么不进魔改04**:这是改代码逻辑(键盘行为)的功能型改动,不是"改某个默认值/开关",按 §6 约定单开序号块(12),不并入 04 合集。

**验证点(给接手 AI + 用户实测)**:① 主窗口按 F11 进全屏 → 按 Esc 应退出全屏(回到普通窗口);② 不在全屏时按 Esc → 行为同原版(不会有副作用,仍能取消待处理的剪切/移动);③ 反复 F11 进、Esc 出,稳定。

---


### 13 · 书架阅读进度百分比(自包含)

**目标**:书架每本单文件书的文件名后显示阅读进度 `(95%)`,一眼看出读到哪了。

**关键约束(已对真实源码确认)**:NeeView 阅读历史(`History.json` 的 `BookMemento`)**只存"当前页的文件名"字符串,不存页码序号、也不存总页数**(整条历史链唯一的数字字段是随机排序种子 `SortSeed` 和基准缩放 `BaseScale`,与页码无关)。你读书时标题栏/底部滑条的 `145 / 152` 是**书开着时的实时状态**(内存里的 `Book`),关书后并不落盘。上游也**没有**现成进度功能(`Percent` 全是缩放/字体设置;绿色 ✓ 是 `FolderItemIconOverlay.Checked` = "在历史里"的有/无二值标记,非百分比)。

**做法(自包含,零风险动 NeeView 历史)**:
- **新建 `_Mod/ReadProgressStore.cs`**:自己的 JSON `ReadProgress.json`(放 `Config.Current.History.HistoryFilePath` 同目录),`书路径 → long[] [index, count, finished, finishedAtTicks]`(`finished` 黏性「读完过」0/1、`finishedAtTicks` 读完时刻 Ticks,均为 mod16 加;旧的长度 2/3 记录加载时自动补成长度 4)。全 try/catch,任何读写失败只表现为"不显示进度"。
- **抓取**:`Book.CreateMemento()` 注入一行——书开着、`CurrentPage` 存在时 `Record(_source.Path, _source.Pages.IndexOf(CurrentPage), _source.Pages.Count)`。这正是那个 `145/152` 的来源,所以记的就是屏幕上看到的数。只对**点开读过**的书有记录。
- **显示**:`FolderItem` 加 `ReadProgressText`(如 `"95%"`)和 `IsReadFinished`(是否 100%)两属性;`FolderListBox.xaml` 的 **Normal/Content** 两模板在文件名后加进度 `TextBlock`(Dock 右),`BasedOn NoteTextStyle`(同日期行淡灰),`DataTrigger IsReadFinished=True` 时 `Foreground=#FF66BB6A` 绿色。
- **实时刷新(关键)**:历史保存被 `_historyEntry` 限制成每次开书只存一次,光靠它会出现「读一下变一次就锁死」。所以真正的实时刷新挂在**翻页事件**上——`BookMementoControl.Book_CurrentPageChanged`(每次翻页都触发)里调 `ReadProgressStore.RecordLive`(只更新内存、不写盘,避免频繁写)记当前页,再 `AppDispatcher.BeginInvoke` 到 UI 线程 `BookshelfFolderList.Current.RefreshIcon(该书路径)`;经 `FolderItem.NotifyIconOverlayChanged`(已补 `OnPropertyChanged(ReadProgressText/IsReadFinished)`)让书架那一项的百分比重新求值。于是边读边翻、百分比当场跟着变,**不必关书或重启**。写盘交给关书/保存时的 `Book.CreateMemento()` → `Record`(总是落盘,因内存已被 RecordLive 改过,不能按「内存没变」跳过)。
- **百分比规则**:`count<=1` 或 `index<=0`(第一页/未读)→ null = **不显示**(当未读,不显示 `0%`);否则 `pct=round(index/(count-1)*100)` 夹 `[1,100]`,读到最后一页=100%(绿)。

**限制(按用户决定)**:① 只对"用此版打开过"的书显示——已在历史、但没用新版重开过的书要打开一次才出现(用户决定**不做**"打开压缩包补全已读书",因为没点开的本来也只 0%)。② 进度边读边翻即时刷新(挂翻页事件,见上「实时刷新」),不必关书或重启。③ `ReadProgress.json` 与 `History.json`、缩略图 `Cache.db` 各自独立,清缩略图缓存不影响它;将来若对某书"删除历史记录",可在 13 里顺手清该书进度(目前未做)。

**状态:百分比与 MB 已在 Windows 实编实测正常(2026-06-05 用户确认);「读一下变一次就锁死」二修后,改挂翻页事件实时记录+刷新(`Book_CurrentPageChanged` → `RecordLive` + `RefreshIcon`),经用户 Windows 实测通过(2026-06-05)。至此 mod13(百分比+实时刷新)与 mod14(MB)全部 ✅ 实测可用。**补丁层已用真实 `build.py --patch-only` 在干净 `3b62b9c9f` 上零失配(92 条、`ReadProgressStore.cs` 新建且字节一致、改动文件大括号配平、`FolderListBox.xaml` 作 XML 解析通过),仍未覆盖 **Banner/Thumbnail 两种缩略图视图**(目前只在 Normal/Content 文件名后显示);显示样式(颜色/位置)如需再调随时说。

**【13b · 续读位置解耦(窗口模式也能恢复)2026-06-07】**

**Bug(用户报)**:窗口模式(非 F11)看书,拖进度条到某页(如第 40 页 / 26%)后退出,重启续读位置回到旧的第 3 页,但书架 % 仍显 26% → 位置与 % 对不上。

**根因(已对真实源码确认)**:① mod13 的进度 %(`ReadProgressStore.RecordLive`,翻页 hook #91)**每次翻页就记、不看是否全屏**,所以窗口模式也更新且落盘 → % = 26%。② NeeView 的**续读位置**(重启恢复到第几页)走历史 memento,而 **mod18 把它和「历史列表」用同一个 `CanHistory` 闸门绑死、只在 F11 全屏才写回**(`BookMementoControl.SaveBookMemento` 第 195 行、`TrySaveBookMemento` 第 118 行都走 `CanHistory`,后者已被 mod18 加了 `IsFullScreen`)→ 窗口模式拖进度条位置不写回 → 重启恢复到上次 F11 存的第 3 页。两者打架。

**用户选定方案**:**历史列表仍只记 F11 全屏(mod18 不动),但窗口位置也要能恢复 → 解耦**。

**做法(无闪、不碰 mod18 的历史列表)**:利用 mod13 已有的「不分全屏、每本书都记页码并落盘」特性,额外记下**当前页的 `EntryName`**,开书时用它覆盖恢复页:
- **`ReadProgressStore.cs` 加续读页名子存储**:新增 `_resume`(`path → 当前页 EntryName`),独立存 `ReadResume.json`(History.json 同目录,**不碰** `_map`/`ReadProgress.json`)。`SetResumeLive`(翻页时只更新内存)+ `GetResumePageName`;`Save()` 把 `_resume` 随 `_map` 一起落盘(故关书时与 % 一同持久化,与 % 走同一条已被证实在窗口模式也触发的落盘路径)。全 try 兜底。
- **翻页 hook #91 加一行**:`SetResumeLive(__path, __book.CurrentPage.EntryName)`(窗口模式也记;`#91` 内已有 `CurrentPage != null` 守卫)。
- **新增 BookHub 补丁(`[魔改13b]`,replace,mod13 第 8 条)**:开书定稿 `setting` 处(`BookHub.cs` 第 448 行 `var setting = args.BookMemento ?? CreateOpenBookMemento(...)` 之后)插:仅当 `address.EntryName == null`(常规开书、未指定具体入口页)时,`var __resume = ReadProgressStore.Current.GetResumePageName(address.TargetPath.SimplePath); if(!空) setting.Page = __resume;`(全 try)。NeeView 自己按页名定位(`setting.Page`→`address.EntryName`→`StartPage.PageName`→`Pages.FindIndex(EntryName)`,见 `Book.SetStartPage` 第 174 行),**无闪**;查不到/页已删则 `FindIndex` 返 -1 → 开第 0 页,优雅(无回归)。BookHub.cs 此前无任何补丁碰过,无冲突。

**为什么不破坏 mod18**:只改了「开书恢复到哪一页」,完全没碰 `BookHistoryCollection`(历史列表)/`CanHistory`。历史列表照旧只收 F11 全屏单文件;`ReadResume.json` 是独立存储,与历史/缩略图无关。对 F11 历史里的书,mod13 记的页是最新位置(窗口也更新),覆盖后恢复到最新页(更准);从没读过的书无记录 → 不覆盖 → NeeView 默认行为。修复后:窗口模式拖进度条→关书→重启恢复到该页,且书架 % 与位置一致。

**path key 一致性(已确认)**:mod13 记录用 `Book.Path`(=`_source.Path`)、显示用 `EntityPath.SimplePath`、开书覆盖用 `address.TargetPath.SimplePath`,三者同源(% 能显示在正确的书上即证据;`CreateOpenBookMemento` 本身也用 `address.TargetPath.SimplePath` 作 key)。

**分组提示**:BookHub 补丁是追加在 PATCHES 列表**末尾**的,靠它前面新插的一行 `#  魔改 13:` 注释标题归入 mod13(build.py 概览据注释标题就近归组);故跑 build.py 应见「魔改13 8条 / 魔改16 18条」(mod16 在第二步-2b 后含 2 个新 create 文件)。若哪天概览把它算成别的组,多半是那行标题被挪动或删了。

**状态**:✅ **13b 已 Windows 实测通过(2026-06-07)**:窗口模式拖进度条/翻页后退出、重启恢复到该页,且与 mod18 历史互不影响。(注:本段下方 13c 起把进度存储重构成身份主键、并新增第二步-2b 的两个文件,补丁总数与分组已变 → **当前总数 113、mod16=18**;下面这句历史数据「111 条/mod16=16」是 13b 当时的快照,留作历史。)补丁层当时 `build.py --patch-only` 干净 `6c4b43c48` 零失配(111 条、相关文件配平、repr 往返一致、分组 mod13=8/mod16=16)。

---

**【13c · v2 路径无关重构 2026-06-07 · 第一步 / ✅ 已实测通过】** 目标:移动文件后 进度%/续读位置 仍认得同一本(用户决策:身份口径=**文件名+大小**;扫描用手动按钮;范围含已读完+进度%+续读)。本次只做**第一步**(纯 `ReadProgressStore.cs` 重写,不碰 UI/历史);第二步(已读完面板改身份驱动 + 设置里扫描按钮)已在本步实测通过后完成,详见下文 2a / 2b。

- **主键从「路径」改成「身份」**:`ReadProgress.json` 由 `path → long[] [idx,cnt,fin,tks]` 改成 **`identity → ReadRec{Index,Count,Finished,Ticks,Resume,Path,Access,Name}`**(`ReadRec` 为 `ReadProgressStore` 内公共类,System.Text.Json 序列化公共属性)。`identity = 去后缀文件名 + '\u001f'(SEP) + 文件字节大小`。`Resume`(续读页)并入本文件,**不再写 `ReadResume.json`**。
- **路径无关怎么实现**:所有公开方法签名**完全不变**(`RecordLive/Record/GetProgressText/SetResumeLive/GetResumePageName/GetFinishedPaths/GetFinishTicks/ClearFinished/ClearAllFinished` 一律仍收路径,**12 个调用点一个不动**),内部一律先 `IdOf(path)` 把路径解析成身份再操作 `_books`。`IdOf`=`StripExt(path)+SEP+FileSizeOf(path)`(`FileSizeOf`:文件→`FileInfo.Length`、文件夹→直接子文件字节和、不存在→ -1 即返回 null),并用 `ConcurrentDictionary<path,id> _idMemo` 缓存避免重复 stat;`IdOf` 在主 `_lock` 之外算(不在锁内做 I/O)。**关键洞察**:书架/开书/翻页查询时文件就在眼前(能算身份),故移动后**自动认得、无需扫描**;扫描只为「已读完」面板(列移动后不在眼前的书)修复打开路径,留第二步。
- **旧数据迁移**:`EnsureLoaded` 先试反序列化新格式(`Dictionary<string,ReadRec>`);旧格式值是数组会抛异常 → 走 `MigrateOld`:读旧 `Dictionary<string,long[]>` + 旧 `ReadResume.json`,对**文件还在**的旧 path 算身份转成 `ReadRec`(续读页并入 `Resume`),**文件已移动/删除的旧项算不出身份 → 丢弃(一次性损失)**;迁移后写新格式。
- **第二步预留接口(本文件这次一并加好,故只动一次)**:`GetFinishedBooks()`→`List<(id,name,path,size,finTicks,accessTicks)>`、`ClearFinishedById(id)`→返回 path、`UpdatePaths(IEnumerable<KeyValuePair<id,path>>)`→批量更新最近路径返回改动数、`IdentityOfFile(path)`→公开 `IdOf` 供扫描端用同一套身份算法。
- **已知小回归(可接受)**:统计排行(mod17)那条进度条对「已移动但没重开」的书,`GetProgressText(r.path 旧路径)` → 文件不在 → 返回 null → 该行进度条空(旧版会显示陈旧%);重开一次或扫描后即恢复。已读完面板这步仍历史驱动,对没移动的书照常工作。
- **验证**:沙箱 `build.py --patch-only` 干净 `6c4b43c48` 上 **111/0 零失配**;生成的 `ReadProgressStore.cs` 大括号 81/81、小括号 249/249、401 行,13 个公开方法齐全。✅ **2026-06-07 用户 Windows 编译实测通过**:移动一本读到一半的书到别的文件夹 → 书架仍显示其 %、打开仍续读到原页(均无需扫描);旧 `ReadProgress.json` 首次加载自动迁移正常。**第一步(进度%/续读 路径无关)落地完成。**

---

**🆕 13-spread(2026-06-15)· 双页模式看到最后显示 99% / 不算读完——已修**:用户反馈双页(跨页)模式翻到最后,书架/统计仍显示 99%、且不进「已读完」。**根因**:进度页号一直记的是「当前页 = 跨页**首页**」(`Pages.IndexOf(book.CurrentPage)`),而 `CurrentPage` 在双页模式是跨页前一页。偶数页书的末跨页 = [count-2, count-1],首页 index=count-2 → `GetProgressText` 的 `index*100/(count-1)` 永远差一页(99%);`Sticky`(`index>=count-1`)与 mod17 `NoteProgress`(`index<count-1` 即 return)也都判不到读完。**修法(改 3 条现有 replace 补丁、不新增条目,仍 150)**:把记录页号从「首页」改成「当前显示页中的**最大页号**(跨页尾页)」——`NeeView Book` 有公开属性 `CurrentPages`(当前显示页列表,双页=两页都在),遍历它取 `Pages.IndexOf` 的最大值(单页模式只有一页 → 等于原值,不受影响)。三处同改:① `#91` 翻页即时钩子(`RecordLive`,`BookMementoControl.cs`)、② `#106`(mod17 `NoteProgress`,同一钩子,anchor 随之更新为 `__idx` 版)、③ `#86` 关书持久化 `Record`(`Book.cs`,用 `_currentPages` 私有字段)——**第③处尤其关键:不改它,关书存盘会把 live 记的末页号盖回首页号 → 重启又变 99%**。于是看到末页(无论单/双页、奇/偶数页)即 100% 并标记读完。**注**:`GetProgressText` 只按 `Index` 算 %、不读 `Finished` 标志,故必须让 `Index` 真正到 count-1。**验证**:`build.py --patch-only` 干净 `4dbe593eb` 上 150/0 零失配(`#106` anchor 已对齐 `#91` 改后输出);`Book.cs` 大括号47/47·圆括号91/91、`BookMementoControl.cs` 34/34·80/80 配平。⚠️ 待 Windows 实测:双页模式翻到最后 → 书架/统计 100%、进「已读完」。

### 14 · 文件大小单位智能显示(KB/MB/GB)

**目标**:书架文件大小别老用 KB(漫画动辄 `219,722 KB`),够大显示 MB、超大 GB。

**做法**:改 `Converters/FileSizeToStringConverter.ByteToDisplayString`(上游写死 `$"{KB:#,0} KB"`,且全程无任何大小单位设置项)——`≥1GB`→`{GB:#,0.00} GB`、`≥1MB`→`{MB:#,0.0} MB`(如 `214.6 MB`)、更小仍 `KB`(避免小文件 `0 MB`)。

**影响面**:`ByteToDisplayString` 是全局函数,书架笔记行、页列表、文件卡、导出预览都用它 → 一处改、四处生效,单位统一。✅ **已随 mod13/14 批次 Windows 编译实测正常(2026-06-05)**。

---

### 15 · 隐藏右上角 Dev/版本水印

**目标**:去掉标题栏/菜单栏右上角那个 `Dev` 版本水印(自己编译的 Dev 包会显示)。

**来源**:水印是 `MenuBar/MenuBarView.xaml` 里的 `Border x:Name="Watermark"`(内含 `WatermarkText`),由 `MenuBarView.xaml.cs` 构造函数控制:`this.Watermark.Visibility = Environment.Watermark ? Visible : Collapsed`。`Environment.Watermark` 取自 `AppSettings.Current.Watermark`,Dev 包(`AppSettings.PackageType = "Dev"`)默认开水印,并在 `if (Environment.IsDevPackage)` 分支把 `WatermarkText.Text` 设成 `"Dev"`。

**做法**:把那句改成恒 `this.Watermark.Visibility = Visibility.Collapsed;`,水印永不显示。后面设背景/文字色/文字的代码照常跑(只是作用在隐藏元素上,无害),不碰 `Environment`/`AppSettings`,影响面最小。

**【15-2 · 标题去版本号 → 后改留空 2026-06-09 · 待 Windows 实测】** 用户:窗口标题「NeeView 1.0.0-Dev」不要版本号、只留「NeeView」,并入 mod15。**来源(对真实源码核实)**:`MainWindow/WindowTitle.cs` 构造里 `_defaultWindowTitle = $"{Environment.ApplicationName} {Environment.DisplayVersion}";`(第35行),没开书时 `Title = _defaultWindowTitle;`(第95行)→ 标题即「NeeView 1.0.0-Dev」。开书时标题走可配置的 `WindowTitleFormat1/2/Media`(默认不含 `$Version`,grep 无命中),不受影响;`VersionWindow`(关于框)单独显示版本号、那是本职,不动。**做法**:新增一条 `replace` 补丁(归 mod15、放在 mod15 段内 Watermark 补丁之后 → 概览「魔改15 2条」),把第35行改成 `_defaultWindowTitle = string.Empty;` → 没开书时标题**留空**(用户先要去版本号显示「NeeView」,随后又说连「NeeView」也不要 → 直接留空)。**补丁 115→116**(replace 90→91;新文件 `MainWindow/WindowTitle.cs`,文件数 60→61)。**验证**:沙箱干净 `f2e269702` 上 `build.py --patch-only` **116/0 零失配**、概览「魔改15 2条」;`WindowTitle.cs` 打补丁后配平 18/18·34/34。⚠️ **待用户 Windows 编译实测**:没开书时窗口标题/任务栏应为空(连「NeeView」都不显示);打开书后标题照常(书名等)。

**【18-2 · 已读完排除文件夹型书 2026-06-09 · 待 Windows 实测】** 用户:「已读完」面板里冒出一个文件夹「000」(把文件夹当书读到 100% 了),按 mod18「只记单文件」的口径不该出现。**根因(对真实源码核实)**:mod18 只在 NeeView 历史的 `CanHistory` 加了目录过滤,**管不到「已读完」**——`ReadFinishedView.UpdateList`(第296行)是直接从 mod13 `ReadProgressStore.Current.GetFinishedBooks()` 取数的,而 `ReadProgressStore.RecordLive` 每翻页就记、不分全屏、也不排除文件夹型书 → 文件夹读到 100% 就进了 `ReadProgress.json`、漏进「已读完」(§1 mod18 行原写「已读完随历史只剩单文件、无需单独改」不准,已修正)。**做法(改 mod16 现有 create 文件 text、不新增补丁,仍 116、mod16=19)**:在 `UpdateList` 的 `GetFinishedBooks()` 之后、`.Select` 之前加一道 `.Where(b => string.IsNullOrEmpty(b.path) || !Directory.Exists(b.path))` → 路径是现存目录的(文件夹型书)不显示;单文件(`Directory.Exists`=false)照常显示;已删除的按无效项处理。列表与「共 N 本」计数都走过滤后结果。**为何不在记录端(mod13)拦**:`ReadProgressStore` 同时给文件夹型书提供续读(mod13b),记录端拦会连带掐掉文件夹续读;故只在「已读完」显示端过滤(与 mod17 统计过滤文件夹同思路)。**注**:文件夹型书的 100% 记录仍在 `ReadProgress.json`(供续读),只是不在「已读完」露面。**验证**:`build.py --patch-only` **116/0 零失配**;`ReadFinishedView.cs` 配平 148/148·325/325。⚠️ **待用户 Windows 编译实测**:「已读完」里不再出现文件夹型书(如「000」),「共 N 本」相应减少;单文件照常显示。

**🆕 18b(2026-06-15)· 文件夹彻底不记进度、不进「已读完」(口径统一)**:18-2 是在「已读完」显示端(v1 的 `UpdateList`)过滤文件夹;mod16 v2 改身份驱动后,数据源换成 `ReadProgressStore.GetFinishedBooks()`,且 mod13 的翻页钩子 #91 对**每本书(含文件夹)**都调 `RecordLive` → 文件夹翻到末项会被置 `Finished=1` 漏进面板。**做法(改 `ReadProgressStore.cs` 现有 create 文件 text、不新增补丁,仍 150)**:① `RecordLive`/`Record` 两个写入守卫各加 `|| Directory.Exists(path)` → **以后不再把文件夹的进度写盘**(第196/218行);② `GetFinishedBooks()` 加 `if (!string.IsNullOrEmpty(r.Path) && Directory.Exists(r.Path)) continue;` → **含旧记录的文件夹立刻从面板隐藏**(第348行)。**取舍**:文件夹的续读位置/进度% 随之消失(符合「文件夹不算书」统一口径);`ReadProgress.json` 里的旧文件夹记录是「被隐藏」非物理删除。**验证**:`build.py --patch-only` 干净 `4dbe593eb` 上 150/0 零失配,`ReadProgressStore.cs` 三行在 196/218/348、大括号配平。⚠️ 待 Windows 实测。

**备注**:也可改 `AppSettings.Watermark = false`(若该设置可改),但代码里强制隐藏更稳、重编不丢。**✅ 一行改动,已随 13~16 批次在 Windows 编译通过**(单行可见性改动,风险极低)。

---

### 16 · 「已读完」侧边面板

**目标**:左栏历史记录图标下面加一个面板,**外观仿历史**——顶部「数量 + 「…」菜单」+ 列表(封面缩略图+日期+书名),Ctrl/Shift 多选,双击打开,右键可「标记为未读」移出(并把那本重置回第一页)。读完判定用**黏性**(读到过末页就永久算读完,翻回 99% 也不掉)。「…」菜单里可切**排序方式**(按读完时间 / 按最后打开时间)与**顺序**(正序/倒序)。

**原设计核实**:NeeView 没有「已读完」面板(本无阅读百分比概念)。面板框架:`IPanel` 接口(`TypeCode/Icon/IconTips/View/DefaultPlace/Refresh/Focus`);所有面板由 `CustomLayoutPanelManager._defaultDocs` 列出、`SidePanelFactory.Create` 构造;左栏图标即来自 `_defaultDocs` 左 dock。最像的模板是历史面板。

**做法**:
- 新建 `_Mod/ReadFinishedPanel.cs`(实现 `IPanel`,薄壳;图标取 `ic_done_24px` 绿勾,取不到退回历史图标、绝不抛异常拖垮启动)。
- `_Mod/ReadFinishedView.cs`(**纯代码** `UserControl`,**实现 `IPageListPanel`**):一个 `ListBox`,**外观仿历史的「内容」视图**——封面缩略图(`PanelListContentImage`,靠默认样式按 `ContentItemProfile` 自动定尺寸)+ 日期(`LastAccessTime`)+ 书名;模板用 `XamlReader.Parse` **运行时**套上(只依赖 NeeView 程序集的 `PanelListContentImage` + 全局主题画刷 `Panel.Note`/`Panel.Foreground` + 日期 `StringFormat`,**不新增 XAML 编译单元**,免 x:Class/编译坑)。**列表项直接复用 `BookHistory`**(自带 `Thumbnail`/`Name`/`LastAccessTime`/路径),数据 = `BookHistoryCollection.Current.Items` 按 `GetFinishedPaths()` 过滤、按时间倒序。缩略图懒加载照抄历史:自建 `PageThumbnailJobClient("ReadFinishedList", BookThumbnailCategory)` + `ListBoxThumbnailLoader(this, …)`(故视图须实现 `IPageListPanel`:`PageCollectionListBox`/`IsThumbnailVisible=true`/`CollectPageList`)。列表 `SelectionMode=Extended`(Ctrl/Shift 多选,同历史)。双击/回车 `BookHub.Current.RequestLoad(… KeepHistoryOrder|SkipSamePlace|IsBook …)` 打开。**右键「标记为未读」**(`ContextMenu`,仅本面板、不进设置;右键未选中项→只选它、右键已选项→保持整组)→ **对所有选中项**:`ReadProgressStore.ClearFinished(path)` 删进度记录(移出本面板 + 书架未读),并 **把 `Unit.Memento.Page=""` 续读页归零**(开书时 `address.EntryName ?? setting.Page` 取到空 → 回第一页,见 BookHub L453;`Unit` 即 `BookMementoCollection.Current.Set(Path)`,改它开书会读到、退出时落盘),最后刷新书架。
- **头部(复刻历史)**:顶部一行 DockPanel——左 = 数量「共 N 本」,右 = **复用 NeeView 的 `MoreMenuButton`**(「…」菜单按钮)。`MoreMenuButton` 模板在全局 `Generic.xaml`;「…」图标 `ic_more_24px_a` 在 `Styles/MoreButtonIcons.xaml`(非全局,故运行时 `new ResourceDictionary{Source="/Styles/MoreButtonIcons.xaml"}` 取出来设给 `ImageSource`;取不到也只是没图标、按钮仍可点)。菜单内容由 `MoreMenuDescription` 子类 `Create()` 构建一次;`Update()` **返回同一个菜单实例、只原地刷新勾选**(切勿返回 `Create()` 的新实例,否则菜单会自动消失——详见下「排序」坑)。
- **排序(「…」菜单,两级)**:父项为排序键「按读完时间 / 按最后打开时间」,各自下挂二级子菜单「倒序 / 正序」(去掉括号说明字),点子项一次定「键+序」。`SetSort(byFinishTime, descending)` 改状态 + 重建列表。排序键:**按读完时间**用 `ReadProgressStore.GetFinishTicks(path)`(无则退回 `LastAccessTime`),**按最后打开时间**用 `LastAccessTime`;顺序 `OrderBy` / `OrderByDescending`。默认「按读完时间 + 倒序」。**⚠️ 坑(已修)**:`MoreMenuDescription.Update()` **必须返回传入的同一个 ContextMenu 实例**(只在原地刷新叶子项 `IsChecked`),**绝不能返回 `Create()` 的新实例**——否则 `MoreMenuButton` 把 `MoreMenu` 换成新对象,`DropDownMenuBehavior` 重新把 `IsOpen` 绑到按钮 `IsChecked`(带 200ms 延迟),会把刚弹出的菜单顶掉 → 菜单一闪就自动消失。故持有四个叶子项引用,`Create()` 建一次、`Update()` 原地刷新勾选。
- **`ReadProgressStore` 黏性「读完过」+ 读完时刻**:存储值 `[index,count]` → **`long[] [index,count,finished(0/1),finishedAtTicks]`**(`int[]`→`long[]` 以容纳 Ticks)。`RecordLive`/`Record` 用 `Sticky()`(读到过末页就把 `finished` 置 1、只增不减,修掉「100%→99% 掉出已读完」)+ `NewTicks()`(finished 从 0 翻 1 那刻记 `DateTime.Now.Ticks`、已是 1 则保留)。`GetFinishedPaths()` 返回 `finished==1`(黏性);新增 `GetFinishTicks(path)` 给排序用;`ClearFinished(path)` = 删记录(=标记未读)。**兼容旧数据**:加载时长度 2/3 补成长度 4(`finished` 按最后位置推断,旧记录无读完时刻 → 0「未知」、排序时退回最后访问时间)。
- **「…」菜单全套(复刻历史)**:除排序外还有——**视图样式** 列表/内容/横幅/缩略图(`SetListStyle`,切 `_listBox.ItemTemplate`;缩略图样式另把 `ItemsPanel` 切成 `WrapPanel`;4 个模板用 `XamlReader.Parse` 运行时套,分别含 `PanelListContentImage`/`PanelListBannerImage`/`PanelListThumbnailImage`,缩略图宽度绑 `Panels.ThumbnailItemProfile.ShapeWidth`,均靠各自默认样式自动定尺寸)。**显示项目数量**(开关「共 N 本」)。**显示搜索框**(开关一个 `TextBox`,按书名 `Contains` 不区分大小写过滤)。**删除无效项**(文件已不存在的已读完项,带 `MessageBox` 确认)/ **清空已读完**(`ReadProgressStore.ClearAllFinished()`,带确认;不动文件)。所有勾选项在 `RefreshChecks()` 里按当前状态原地刷新(配合 `Update()` 返回同一实例)。**面板状态本会话内有效**(重启回默认:内容样式 / 按读完时间倒序 / 显示数量 / 隐藏搜索框;如需持久化可后续加)。**未做**:`分组显示`(与本面板已有的灵活排序有点冲突、且分组的排序方向不好控,暂缓)、`仅当前文件夹`(对已读完列表无意义,跳过)。
- **书架那个 100% 绿仍按实时位置**(`GetProgressText.isFinished` 不变):翻回 99% 书架显示灰色「99%」,但本面板因黏性仍留着它——书架=你当前读到哪,本面板=读完过的集合,两者分开、互不影响。
- 注册两处:`_defaultDocs` 左 dock 在 `HistoryPanel` 后加 `nameof(ReadFinishedPanel)`(决定它在历史**下面**);`SidePanelFactory.Create` 加一个 case。
- **已有 Profile 也能出现**:`LayoutPanelManager.Restore()` 末尾有「すべてのパネル登録を保証する」段——把"已注册但布局里没有的面板"按默认 dock 补进去,故你现有 Profile 左栏会自动补上它,不必重置 Profile。

**刷新**:面板 `Refresh()`(切到该面板时)重建列表;右键标记未读后即时重建。非实时(读完一本要切走再回/重开才更新列表)。

**✅ 状态:已用户实测可用(2026-06-06)**。面板 / 缩略图 / 四种视图样式(列表·内容·横幅·缩略图,缩略图为 `WrapPanel` 网格)/ 排序二级菜单(曾自动消失、已修=`Update()` 返回同一实例)/ 显示数量 / 搜索框(按名过滤)/ 删除无效项 / 清空已读完(均带确认)/ Ctrl·Shift 多选 / 右键标记未读+重置首页,均经用户编译实测正常。补丁层零失配(98 条、两新文件字节一致、配平 101/101·36/36)。**未做**:分组显示(与本面板已有的灵活排序略冲突、分组排序方向不好控,暂缓)、仅当前文件夹(对已读完列表无意义,跳过)。边界:某本读完书若不在历史(历史关掉/被删)→ 没有 `BookHistory` 项 → 不显示(可接受)。

---

**后续增强(2026-06-07 起;均已实现,完整逐条改法见代码注释与 §2「近期变更历史」对应日期;✅=已 Windows 实测、🚧=待测)** —— **注:下面 ① v2 重写已取代上面正文里 v1 的「数据源 = `BookHistoryCollection.Items`」描述**:

- **① v2 身份驱动重写(2026-06-07 ✅)**:配合 mod13 v2,面板数据源由「历史 join」改为**身份驱动** —— 遍历 `ReadProgressStore.GetFinishedBooks()`(id,name,path,size,finTicks,accessTicks)造行类 **`FinishedItem`**,**代码里已无 `BookHistory` 引用**;封面混合 `mod17 统计封面 base64(`ReadingStatsStore.GetCoverByNameSize` 名+大小取)→ `SelfPage()` 实时(`ArchiveEntryUtility.CreateTemporaryEntry`)→ 空白`(永不 null),**扛文件移动/清缓存/删源**;打开用最近路径(失效弹 Toast)、标记未读=`ClearFinishedById`(连续读一起清)。
- **② 移动找回·「自定义扫描」(2026-06-07 ✅)**:新增 `_Mod/ReadScanService.cs` + `_Mod/SettingPageReadFinished.cs`(设置页「自定义扫描」,注册搭 mod17 那条 `SettingWindowModel` replace)。填目录→递归枚举漫画文件→按身份算 `(身份→最新路径)`→`ReadProgressStore.UpdatePaths` 批量改最近路径(只更新已有记录、不开书);进度条 +「已检查 N 个文件」实时状态;扫完在 **UI 线程**逐个 `BookHistoryCollection.Rename(old,new)` 同步 NeeView 历史。
- **③ 扫描顺手迁移缩略图缓存键(2026-06-08 ✅)**:扫描把这些书在 `Cache.db` 的键从旧路径迁到新路径(一条 `UPDATE OR REPLACE` 同迁「封面键=文件路径」+「包内页键=书路径\反斜杠\条目」,`@sep`=反斜杠参数化),移动后复用已生成封面不重生。**⚠ 关键坑**:对 `Cache.db` **开独立第二连接(`Pooling=False`,WAL + `busy_timeout`)**,**绝不复用 NeeView 的 `_db.Connection`**(会与其 `BeginTransaction` 纠缠);DB I/O 在后台线程、全 try 降级。
- **④ 扫描顺手清理孤儿缓存(2026-06-09 🚧)**:扫描末调上游 `ThumbnailCache.Current.CleanupHeavy(token)`(「清理无效项」内核,用 `ArchivePath.Exists` **正确区分封面键/包内页键**——别天真 `File.Exists`(会误删所有包内页键)——只删源已不存在的 + `Vacuum`),清掉移动「没读过的书」留下的孤儿;完工提示报清理数。
- **⑤ 右键「删除记录」(2026-06-08 ✅)**:`ReadRec` 加独立字段 `Dismissed`(0/1,旧 json 缺省 0)。「标记为未读」=`ClearFinishedById`(删记录→进度%归0+清续读);「删除记录」=`DismissFinishedById` 仅移出面板、**保留进度%/续读**(独立于黏性 `Finished`,翻页不会取消隐藏);「清空全部」也改成批量置 `Dismissed`(留进度)。
- **⑥ 历史面板多选不显示「打开」(2026-06-08 ✅)**:新增一条 replace 改 `HistoryListBox.xaml.cs`,右键构建包进 `if(SelectedItems.Count<=1)`,多选只剩「删除历史记录」。
- **⑦ 右键「打开」=打开+在书架中定位(已读完/统计/历史 三面板,2026-06-08/09 ✅)**:右键「打开」在开书同时 `SidePanelFrame.Current.SetVisibleFolderList(true,true,true)` + `BookshelfFolderList.Current.RequestPlace(父目录, new FolderItemPosition(QueryPath(书路径)), Focus|FileSystem)` 跳书架并选中;双击/回车/单击仍只开书。
- **⑧ 两面板外观对齐书架(2026-06-09 🚧)**:已读完/统计的 `new ListBox` 套 `NVListBox` 样式(`Application.Current.TryFindResource`,细滚动条常显)+ `VirtualizingPanel.SetScrollUnit(lb, Pixel)`(像素平滑,不再一次跳一整本)。
- **⑨–⑪ 统计面板(mod17)微调,详见 §4 mod17**:⑨「总」视图年柱 1/4 宽(`BuildBars` 在 `Total && 柱<4` 补足 4 列靠左,2026-06-09 🚧);⑩ 柱悬浮提示 0.5s(`ToolTipService.SetInitialShowDelay(bar,500)`+`SetShowDuration(60000)`,2026-06-15 🚧);⑪ 备份升级为**高清封面 `.db`**(新增 `_Mod/ReadingBackup.cs`〔= mod22「高清封面备份」实现〕,补丁 153→154):`StatCoverDb` 自包含 `ReadingCovers.db`(表 `covers(key,value)`,键=名+大小)存**高清封面 ≤2048**;`ReadingBackup.ExportAll/ImportAll` = 单 `.db`(meta 段 = 统计/进度 JSON + covers 段 = 高清 BLOB,导入读文件头 15 字节自动识别 .db/.json、向后兼容旧 JSON);取数链 `SelfPage 实时 → HiResThumb(库) → 小封面`;**要 2048 须先用 mod20「预缓存原图封面」渲染 2048、再开统计面板让 `CaptureCoversOnce` 入库**(2026-06-15 🚧)。

---
### 17 · 阅读统计侧边面板(Reading Statistics)

**目标**:左栏「已读完」**上方**加「统计」面板(顺序 历史→统计→已读完),折线图图标。仿阅读 APP——日/周/月/年/总 切换 + 总时长大字 + 在读/读完/打开次数 + 柱状图 + 阅读时长排行。**不显示「笔记」、不做「阅读目标」**(按用户要求)。数据**完全自包含**,只统计"装上本魔改之后"的阅读(NeeView 从不记阅读时长,过去无历史数据可补)。

**计时规则(核心,按用户多条消息累积)**:
- 只在【F11 全屏 且 未被老板键隐藏(`AppState.IsHideWindow==false`)且 有书打开】时才算"在阅读";每 5 秒采样一次(`DispatcherTimer`)。
- **新书 1 分钟冷静期**:一本"从没被记录过"的书,要**连续全屏满 60 秒**才转正开始记(这 60 秒一起计入);冷静期内退出全屏/切书/隐藏 → 连续秒清零、下次从 0 重来;冷静期内只在内存计数、**不写盘**(满足"避免频繁调用")。
- **冷静期一次性**:某书一旦转正(`Recorded=1`,写进 JSON),**永久**免冷静期(重启也记得),以后打开看 5 秒就记 5 秒。
- **显示门槛**:统计/排行只显示"累计总时长 ≥ 180 秒(3 分钟)"的书(转正后 60→180 这段先记着、暂不显示)。
- **同一本书判定**:去后缀书名 相同 且 页数 相同 且 文件大小差 ≤ 5MB(zip/rar 等后缀不参与;`books` 存 `List<BookStat>` 遍历模糊匹配,非字典精确 key)。
- **读完**:进度条翻到最后一页(`index >= count-1`)记一次「读完时刻」,只对已被时长记录的书。
- **时长显示**:时+分,**截断不四舍五入**(`sec/60` 整除),超 24h 仍用「小时」不用「天」,不足 1 分钟显示「0 分钟」。

**原设计核实**:NeeView 无任何阅读计时机制;`WindowStateManager.IsFullScreen`(mod09 已用)判全屏、`AppState.Current.IsHideWindow` 判老板键隐藏、`BookHub.Current.BookChanged`(public event)+`BookChangedEventArgs.Book`(`Book?`)拿当前书、`Book.Path`/`Book.Pages.Count` 拿路径页数、`Config.Current.History.HistoryFilePath`(mod13 已用)定 JSON 目录。面板框架同 mod16(`IPanel` + `SidePanelFactory.Create` + `CustomLayoutPanelManager._defaultDocs`)。

**做法**:
- 新建 `_Mod/ReadingStatsStore.cs`(数据层 + 计时,单例):`StatsData{List<BookStat>}`;`BookStat{Name(去后缀)/Pages/Size/Recorded/First/Last/FinTicks/Days(dict:"yyyy-MM-dd"→long[2]{秒,打开次数})}`,存 `ReadingStats.json`(History.json 同目录)。`StartTracking(window)` 启 5 秒 timer + 订阅 `BookChanged`(更新当前书识别、已记录书打开+1)+ `window.Closing` 时 Flush。`Tick()` 实现上面的冷静期/累加。`NoteProgress()` 记读完。查询 `GetSummary/GetRanking/GetBars/SumAllBooks`(全过滤总秒≥180)。`Export/Import(replace)/ClearAll`。`FormatDuration()` 时+分截断。写盘节流 60 秒一次 + 退出 Flush。全程 try/catch,任何异常只表现为少记一点、绝不影响 NeeView。
- 新建 `_Mod/StatisticsPanel.cs`(`IPanel` 薄壳,`DefaultPlace=Left`,`IconTips="统计"`):图标 = **自画折线图**(`DrawingImage` 蓝 `#FF4A90D9`,`XamlReader.Parse`,主题无关;失败退回 `pic_history_24px`,绝不抛异常拖垮启动)。
- 新建 `_Mod/StatisticsView.cs`(纯代码 `UserControl`):日/周/月/年/总(`UniformGrid` 5 Button,选中高亮)+ ‹日期› + 「…」(`ContextMenu`:导出/导入(替换)/清空,用 `Microsoft.Win32.Save/OpenFileDialog`)。总时长大字 + 在读/读完/打开次数(`Grid`)+ 柱状图(`Grid` 动态列,周按天·月按天·年按月·总按年·**日不画柱**;`BarBrush` frozen 蓝)+ 排行(`DockPanel` 行,书名 `TextTrimming` + 时长)。主题色用 `SetResourceReference` 套 `Panel.Foreground`/`Panel.Note`。
- 注册两处(同 mod16):`SidePanelFactory.Create` 加 `nameof(StatisticsPanel) => new StatisticsPanel()`(接在 `PlaylistPanel` 行后);`_defaultDocs` 在 `HistoryPanel` 行后插 `StatisticsPanel`(故落在历史**下面**、已读完**上面**)。
- 接入两处:`MainWindow.xaml.cs` 的 `SourceInitialized`(mod09-8 那处)在 `_bossKeyHotKey.Initialize()` 后加 `ReadingStatsStore.Current.StartTracking(this)`;`BookMementoControl.cs`(mod13 那处)在 `RecordLive(...)` 后加 `NoteProgress(...)`,复用同一 `__book/__path`。
- **v2 升级(2026-06-06,用户 Windows 实测 v1 通过后按反馈做)**:
  - **① 挂机暂停**:`OnBookChanged` 与 `NoteProgress`(每次翻页都会调到)记 `_lastActiveTicks`;`Tick` 里若"距上次翻页 > 60 秒"就直接 return(不累加、冷静期保持),翻页即恢复。防止开着书去干别的还在计时。
  - **② 排行多样式 + 缩略图 + 进度条 + 点击打开 + 不存在提醒**:`StatisticsView` 改实现 `IPageListPanel`,阅读时长排行从纯文字行改为 `ListBox` + 四种行模板(列表/内容/横幅/缩略图,同 mod16,`XamlReader` 运行时解析)+ 缩略图懒加载(`PageThumbnailJobClient` + `ListBoxThumbnailLoader`)。新增包装类 `StatRankItem : IHasPage`,用排行项的 `Path` 去 `BookHistoryCollection.Current.Items` 找对应 `BookHistory` 复用其缩略图;每行底下叠一层半透明 `ProgressBar`(`Opacity=0.18`)作进度条背景,进度解析自 mod13 `ReadProgressStore.GetProgressText`("N%"→0~1)。双击/回车 → 文件存在则 `BookHub.Current.RequestLoad` 打开,不存在则 `ToastService.Current.Show(new Toast(..., ToastIcon.Information))` 弹 NeeView 通知框(就是「删除无效项」那种)。为此 `BookStat` 加 `Path`(累加时存最近完整路径)、`GetRanking` 返回 `(name, sec, path)`。
  - **③(并入②)** 半透明进度条背景即第 ② 条里的 `ProgressLayer`。
  - **④ 「…」改原生 MoreMenuButton(修全屏 bug)**:原先自绘 `Button`+`ContextMenu`,在 F11 全屏下弹出会让侧栏 auto-hide 收起(左栏消失);改用 NeeView 给所有面板用的 `MoreMenuButton` + `MoreMenuDescription`(`StatisticsMoreMenu`),与 mod16 同源,不再触发该问题。菜单内含:视图样式(4)+ 导出/导入(替换)/清空;`Update()` 仍返回同一实例只刷新勾选(mod16 教训)。导出/导入结果也改用 Toast 提示。
  - 配平更新:`ReadingStatsStore` 142·346、`StatisticsView` 132·347(`StatisticsPanel` 不变 11·23)。补丁仍 105 条、3 新文件 repr 往返字节一致、干净 `3b62b9c9f` 上 `build.py --patch-only`「新打 105、跳过 0」零失配,接入点(历史→统计→已读完 等)再次肉眼核对正确。

- **★ 最终修正(2026-06-06 多轮,用户 Windows 逐项实测后定稿 —— 接手以本节为准,上面 v1/v2 描述是演进过程)**:
  - **致命卡死修复(最重要)**:首测「点统计图标→卡死→闪退、根本进不去界面」。根因 = 排行项缩略图用了 NeeView 的 `PanelListContentImage`/`PanelListBannerImage`/`PanelListThumbnailImage`,其模板内含 `(bool)value` 硬转 Converter、对 `Thumbnail==null` 不安全;而用户旧统计数据(v1 时期记的)没存 `Path`、在历史里一本都匹配不到 → `History`/`Thumbnail` 全 null → 渲染即崩(NeeView 自家面板的项 Thumbnail 永不为 null,所以只有我们这种「自建包装项」会触发)。**修复 = 缩略图一律改用标准 WPF `Image` 绑 `{Binding Thumbnail.ImageSource}`**(`IThumbnail.ImageSource` 可空且 `INotifyPropertyChanged`,`Image` 对 null Source 完全安全),彻底弃用那三个 NeeView 缩略图控件;并去掉 `{x:Static local:Config.Current}…ShapeWidth` 绑定(缩略图卡片改固定 `Width=120`)。**缩略图懒加载仍保留**(`ListBoxThumbnailLoader` 只需 `IHasPage.GetPage()`,其内部 `.WhereNotNull()` 已能滤掉 null page)。另加两道保险:**构造函数整体 `try` 兜底**(失败时在面板内显示错误文本、而不是让整个程序闪退)、**首帧 `Dispatcher.BeginInvoke(Reload, Background)` 延迟**(界面框架先渲染出来)。
  - **进度条**:彻底**弃用 `ProgressBar`**(其默认模板带 `RepeatBehavior=Forever` 高光动画、且边界不稳),改用**纯 `Border` + `MultiBinding`**:新增 `public class RatioMultiplyConverter : IMultiValueConverter`(`ratio × 本层Grid的ActualWidth/Height`,一切异常/NaN/负数兜底为 0)。**列表/内容样式 = 横向**(`HorizontalAlignment=Left` + 绑 `Border.Width` = ratio×行宽,从左→右);**缩略图样式 = 竖向**(`VerticalAlignment=Bottom` + 绑 `Border.Height` = ratio×卡片高,从下→上)。颜色**淡蓝 `#FF4FA3E8` `Opacity=0.30`**。两个层常量 `ProgressLayerH`(横)/`ProgressLayerV`(竖);**不能用 GridLength 绑 `ColumnDefinition.Width`**——ColumnDefinition 不在视觉树、不继承 DataContext,绑定无效。**(2026-06-07 17-live-2 反转:为实时刷新可靠,又从 Border+MultiBinding 换回「极简模板 ProgressBar 单值 `Value` 绑定」;当初疑 ProgressBar 崩溃实为缩略图 null,ProgressBar 本身安全。详见 §4 mod17 末 17-live-2。)**
  - **样式**:**去掉「横幅样式」**(删 `_bannerT` + 菜单项 + `ApplyListStyle` 的 Banner 分支),只剩 列表/内容/缩略图 三样式。
  - **概要**:**去掉「打开次数」**(删 `_opens` 字段/`StatCell`/赋值,概要 Grid 收为单行两列),现仅 在读 / 读完。
  - **「…」菜单文字**:「导出统计数据…」「导入统计数据(替换)…」→ **「导出数据…」「导入数据…」**(四字)。
  - **确认框统一**:`DoClear`(清空统计)、`DoImport`(导入替换)从 WPF 系统 `MessageBox` 改用 NeeView 原生 `MessageDialog`(`MessageDialogIcon.Warning` + `UICommands.Delete`/`OK` + `Cancel`,`if(ShowDialog().Command!=…) return;`,在 `namespace NeeView`)。**顺带统一**:mod16「已读完」面板的「删除无效项」「清空已读完(字样→清空全部)」也从 `MessageBox` 改 `MessageDialog`;NeeView 原生**历史面板**的「删除无效的历史记录(字样→删除无效项)」补上确认(原本无确认)、「删除全部」本就有确认未动(改 `HistoryListViewModel.cs`:菜单文字直接写死、`RemoveUnlinked()` 开头插确认块)。
  - **新文件共 3 个**:`ReadingStatsStore.cs` / `StatisticsPanel.cs` / `StatisticsView.cs`(均在 `NeeView\_Mod\`)。
  - **文件夹不计入统计(2026-06-06,随 mod18 一起做)**:`Tick()` 累加前、`NoteProgress()` 记读完前各加 `System.IO.Directory.Exists(path)` 判断——当前书路径是目录(文件夹/盘符)就跳过,故打开文件夹全屏浏览不再计时长、不进排行、不记读完。详见 §4 魔改 18「最终实现」。
  - **配平(最终)**:`ReadingStatsStore` 142·346、`StatisticsPanel` 11·23、`StatisticsView` 133·343;受牵连的 mod16 `ReadFinishedView` 101·226。
  - **补丁层**:**109 条**(mod17 段 = 4 create + 5 replace;5 个 replace = SidePanelFactory / CustomLayoutPanelManager / MainWindow.xaml.cs / BookMementoControl.cs / SettingWindowModel.cs,外加历史面板 2 个 replace 也在 mod17 段内 = 共 7 replace … 注:其中 HistoryListViewModel 2 条 + 前述 5 条);干净 `3b62b9c9f` 上 `build.py --patch-only`「新打 109、跳过 0」零失配。
  - **mod16 ReadFinishedView 无磁盘副本**的改法(供接手参考):`ast` 提取该 create 条目的 `text` → 写磁盘改 → 按 `text` 节点行号(单行 `repr`,patches.py 内)就地回填,其余补丁与注释零扰动。

**为什么时长从装上才开始累计**:NeeView 历史只记"最后打开时刻 / 当前页",从不记"看了多久";所以本面板只能从装上本魔改起、按上面规则现采现记,过去的阅读没有时长数据可回填。这是数据来源的客观限制,不是 bug。

**✅ 状态:核心已 Windows 实测可用(2026-06-06)**。已逐项确认正常:进面板不卡死/闪退、缩略图正常显示、列表/内容/缩略图三样式、进度条(列表内容横向·缩略图竖向从下到上·淡蓝)、双击打开原书+不存在弹 Toast、挂机暂停(停一页>60秒停表)、导出数据/导入数据(替换确认)、清空统计(确认框)、柱状图(日/周/月/年/总)、菜单四字文字、以及顺带统一的已读完/历史面板确认框与字样。补丁层干净 `3b62b9c9f` 上 `build.py --patch-only`「新打 109、跳过 0」零失配,3 新文件 repr 往返字节一致。**仍待长期观察(非即时可验)**:新书 1 分钟冷静期是否到点转正、累计满 3 分钟才进统计/排行 —— 需实际读够时长后回看。用到的 NeeView API 均对真实源码核实:`WindowStateManager.IsFullScreen`/`AppState.IsHideWindow`/`BookHub.BookChanged`/`Book.Path`/`Pages.Count`/`HistoryFilePath`/`IThumbnail.ImageSource`/`ListBoxThumbnailLoader`/`MoreMenuButton`/`MessageDialog`+`UICommands`/`ToastService`/`SettingItemContent`+`SettingPage`。

**🔧 17-fix(2026-06-06,迁到 `6c4b43c48` 后修)· 排行缩略图不再寄生于历史**:用户实测发现「阅读时长排行」里有书显示**空白灰块**、点开原漫画也不恢复。根因 = `StatRankItem` 原本 `Thumbnail => History?.Thumbnail`、`GetPage() => History?.GetPage()`,**完全依赖该书在 `BookHistoryCollection` 里(且 `x.Path == r.path` 精确匹配)**;而 **mod18 把历史收紧成「F11 全屏单文件」后,很多被统计过的书并不在历史里**(尤其在窗口模式打开过、或历史里没有对应项的),`History` 取到 null → 缩略图为 null、懒加载器也因 `GetPage()` 返回 null 而 `WhereNotNull()` 滤掉 → 永远空白;在窗口模式重新打开也进不了历史(mod18 排除非全屏),故「点进去也不恢复」。**修复(改 `StatisticsView.cs` 的 `StatRankItem`,仿 mod08 预缓存写法)**:新增私有 `SelfPage()` —— 历史里没有这本书时,按统计存的 `Path` 自造一个临时 `Page`(`new Page(new ArchivePageContent(ArchiveEntryUtility.CreateTemporaryEntry(Path), null))` + `Thumbnail.IsCacheEnabled = true`),封面早已在 `Cache.db`、懒加载器一拉即显;改 `Thumbnail => History?.Thumbnail ?? SelfPage()?.Thumbnail`、`GetPage() => History?.GetPage() ?? SelfPage()`。历史里**有**的书仍走原 `History` 路径(行为不变、不重复造页);只对**不在历史**的书启用路径后备。全程 `try` 兜底(`Exists && File.Exists(Path)` 才造,异常只表现为空白、绝不抛)。补丁仍 **110 条**(改的是 mod17 自有 create 文件 `StatisticsView.cs` 的 text,未新增条目);`StatisticsView.cs` 配平 138/138·354/354,干净 `6c4b43c48` 上 `build.py --patch-only`「新打 110、跳过 0」零失配。NeeView API 已对 HEAD 真实源码核实:`ArchiveEntryUtility.CreateTemporaryEntry(string)→ArchiveEntry`、`ArchivePageContent(ArchiveEntry, BookMemoryService?)`(第二参可空)、`Page(PageContent)`、`Page.Thumbnail`(具体类 `Thumbnail : ObservableObject, IThumbnail` → 可绑 `ImageSource`、变更自动通知)。✅ **排行封面显示已确认正常**(2026-06-06 起 mod17 在用:排行 / 三样式 / 封面均正常,不在历史的书也能显示封面)。边界:某书原文件已删则仍空白(预期)。

**🖼️ 17-cover(2026-06-06)· 封面随统计数据持久化(导出/导入带图片、删原文件/清缓存都不丢)**:用户要求导出/导入的数据带封面图片,且**源文件删了或缩略图缓存(Cache.db)清空了也不影响排行缩略图**。做法 = 给 `ReadingStatsStore.BookStat` 加一个 `Cover` 字段(封面缩略图缩到 ≤160px、JPEG q78、再 base64)。要点:① 它是统计数据的一部分,`Export`/`Import` 序列化整个 `_data` 时**自动就带上了**(导入合并分支也补了「本地没封面就用导入的」);② 它存进 `ReadingStats.json`,**与 Cache.db、原文件都无关** → 删文件/清缓存后仍在;③ 排行显示优先级改为 `CoverThumb() ?? History?.Thumbnail ?? SelfPage()?.Thumbnail`——有持久化封面就用它(`StaticThumbnail` 包一张解码出的 `ImageSource`,实现 `IThumbnail` 的 5 个属性,模板 `{Binding Thumbnail.ImageSource}` 一字不改);有封面时 `GetPage()` 返回 null(免得懒加载器再去生成,省事)。**封面如何被存进去**:`StatisticsView` 在每次刷新排行后延迟多次(1.2/3.5/7 秒)扫描,把「还没存过封面 且 实时缩略图已加载出」的书,编码成 base64 调 `ReadingStatsStore.SetCover(name,pages,size,b64)` 持久化——**只要在统计面板里见过一次**(此时文件/缓存还在),之后删文件/清缓存都仍能显示;另外点「导出数据」时会**先把当前已加载的封面即时抓一遍**再写文件,导出成功提示也改成「已含封面图片」。编码/解码是纯 WPF 标准 API(`BitmapSource`/`TransformedBitmap`/`JpegBitmapEncoder`/`BitmapFrame`/`BitmapImage`,新增 `using System.Windows.Media.Imaging;`),全 `try` 兜底。改的是 mod17 自有的两个 create 文件(`ReadingStatsStore.cs`+`StatisticsView.cs`)的 text,**补丁仍 110 条**;两文件整文件括号配平(SV 168/168·412/412,RSS 147/147·368/368),`GetRanking` 返回类型与 `BuildRank` 参数类型一致,干净 `6c4b43c48` 上 `build.py --patch-only`「新打 110、跳过 0」零失配。✅ **封面显示与导出已确认在用正常**(排行封面正常、导出 JSON 含 base64 封面、换机导入封面跟回)。具体边界「删源文件 / 清缓存后封面仍在」的持久化机制已上线、显示侧已验证,但该删除场景未逐一专门实测。**已知边界**:某书若从没在排行里露过面(不在当前 top30 / 没浏览到)就被删/清缓存,则没机会抓封面、仍空白(可接受;要彻底覆盖可后续加「导出时把全部书的封面都生成一遍」,目前未做)。**JSON 体积**:封面只给「累计≥5分钟」的书存、单张小图约几 KB,常规用量可控;读书量极大时 `ReadingStats.json` 会相应变大。

**📐 17-size(2026-06-06)· 排行「内容样式」缩略图改用 NeeView 标准尺寸**:用户反映统计排行的「内容样式」封面比「已读完」等面板小不少。原因 = 17-cover 时排行内容模板用的是写死 `<Border Width="56" Height="42">` 的普通 `<Image>`(小横框,竖版封面被压更小);而「已读完」(mod16)用的是 NeeView 原生 `<local:PanelListContentImage Thumbnail="{Binding Thumbnail}"/>`,尺寸由 `Config.Current.Panels.ContentItemProfile.ShapeWidth/ShapeHeight` 决定(默认 64、Square)、并随用户设置变化。**修复**:把排行「内容样式」模板也换成 `<local:PanelListContentImage Thumbnail="{Binding Thumbnail}" Margin="0,0,6,0"/>`,与「已读完」完全一致(尺寸/形状/留白/背景全自动跟随同一 Profile)。**安全前提**:`PanelListContentImage` 的默认模板会把 `Thumbnail.IsNormalImage/IsUniqueImage` 经 `(bool)value` 转换器使用——这正是 mod17 当初为避免 null 崩溃才改用普通 `Image` 的原因。因此本次同时给 `StatRankItem` 加了 `private static readonly IThumbnail EmptyThumb = new StaticThumbnail(null);`,把 `Thumbnail` 改成 `CoverThumb() ?? History?.Thumbnail ?? SelfPage()?.Thumbnail ?? EmptyThumb` —— **保证永不为 null**(`StaticThumbnail` 的 `IsValid/IsNormalImage/IsUniqueImage` 返回真 bool、`ImageSource` 为 null 时 NeeView 的 `ImageSourceToThumbnailConverter` 会安全返回默认图),从而 `PanelListContentImage` 不再有 null 崩溃风险。「缩略图样式」未动(本就够大)。改的仍是 `StatisticsView.cs` 的 text、**补丁仍 110 条**、整文件括号配平(168/168·414/414)、干净 `6c4b43c48` 上 110/0 零失配。已对真实源码核实:`PanelListContentImage` 模板尺寸取 `ContentItemProfile.ShapeWidth/ShapeHeight`、`ImageSourceToThumbnailConverter` 对 null 返回默认图(`NeeView/Styles/Generic.xaml`、`PanelListContentImage.cs`)。✅ **已确认**:排行「内容样式」封面与「已读完」内容样式一致大小。

**⚡ 17-live(2026-06-07)· 阅读时长排行的淡蓝进度条实时跟随翻页**:原本排行那条淡蓝进度条(取自 mod13 进度)只在 `Reload()`(重开面板/切日周月年)时由 `BuildRank` 取一次 `ReadProgressStore.GetProgressText` 快照,故只能重启/重开才变一次。用户要它边读边翻实时跟随。**做法(复用 mod13 已有的翻页钩子 #91,不新增钩子)**:① `StatRankItem` 实现 `INotifyPropertyChanged`,`ProgressRatio` 改为会通知的属性(set 时为 `ProgressRatio/ProgressPercent/ProgressStar/RestStar` 发 `PropertyChanged`);② `StatisticsView` 加静态 `Current`(构造函数最前设,Build 抛异常也已设好)+ `UpdateLiveProgress(path)`(在当前 `_currentRows` 里找 `Path` 匹配的行、从 `ReadProgressStore` 重取百分比写回 `ProgressRatio`,全 try 兜底);③ mod13 的 #91 翻页钩子在已有的 `AppDispatcher.BeginInvoke`(UI 线程)里顺带调 `StatisticsView.Current?.UpdateLiveProgress(__path)`。于是边读边翻、排行进度条当场跟着当前页走;书不在当前排行(没读到/不在所选时间范围)则 no-op。进度按 mod13 的「当前位置 %」走(翻回第一页 → `GetProgressText` 返 null → ratio=0 → 进度条空),与书架百分比口径一致。**【17-live-2 2026-06-07】** 用户首测「拖进度条没变化」——症状(加载时显示正确、之后不刷新)最像那条 `MultiBinding`(`Border.Width = RatioMultiplyConverter(ratio × 祖先Grid.ActualWidth)`)在 `ProgressRatio` 通知时**没重算**(MultiBinding+RelativeSource 的刷新比单值绑定脆弱)。改为**最稳的单值绑定**:进度条层 `ProgressLayerH/V` 从「Border+MultiBinding」换成 **极简模板(无动画)的 `ProgressBar`**——`Value={Binding ProgressRatio}` Min0 Max1,模板只有 `PART_Track`+`PART_Indicator`(横向 `HorizontalAlignment=Left`/竖向 `VerticalAlignment=Bottom`,淡蓝 `#FF4FA3E8` Opacity0.30),`IsHitTestVisible=False Focusable=False`。控件自己按比例铺填充,不再依赖 ActualWidth/MultiBinding;单值绑定随通知刷新可靠(同书架 % 原理)。INotifyPropertyChanged/Current/UpdateLiveProgress/#91 钩子均不变;`RatioMultiplyConverter` 类保留(现未用、无害)。注:当初疑 `ProgressBar` 会崩,实为排行缩略图 null 之故(已修),ProgressBar 本身安全。**补丁仍 111 条**(只改 `StatisticsView.cs` 与 `BookMementoControl.cs` 既有内容,未新增补丁),两文件整文件括号配平(`StatisticsView.cs` 175/175·450/450、`BookMementoControl.cs` 31/31·81/81)、干净 `6c4b43c48` 上 111/0 零失配。✅ **已实测通过(2026-06-07)**:干净重编后,看书翻页/拖滑块时排行那条淡蓝进度条实时跟随当前页(口径=mod13 当前位置%,往回翻会降、翻回首页空)。换成极简模板 ProgressBar 单值 `Value` 绑定后刷新可靠。

**⚡ 17-ui(2026-06-07)· 柱状图悬浮提示改为 NeeView 深色风格小卡片**:原本柱子悬浮是默认**浅色** ToolTip(跟深色界面不搭),改为深色卡片——`MakeBarTip(date,dur)` 造 `ToolTip`:背景 `Menu.Background`(#222)、上行日期 `Panel.Note`(灰)、下行时长 `Panel.Foreground`(粗体白、15px)、`#33FFFFFF` 细边框、`HasDropShadow` 系统阴影。并按视图给日期补单位:`BarDateLabel(range,label)` 月→「N 日」/年→「N 月」/总→「YYYY 年」/周→保持 MM/dd(为此 `BuildBars` 加 `range` 形参、调用处与 `ToolTip` 行同步改)。只改自家 `StatisticsView.cs`(`BuildBars` + 两个新 helper),不碰上游;补丁仍 **111 条**,整文件括号配平(181/181·468/468),干净 `6c4b43c48` 上 111/0 零失配。

**🆕 17-hide / 16·17-hd(2026-06-15)· 统计排行 隐藏/删除/解除隐藏 + 已读完·统计封面改 2048 高清**:三件事一批做(只改 mod16/mod17 自有 create 文件的 text,**补丁仍 150 条不新增**)。

**① 封面改 2048 高清(已读完 + 统计 两面板,17-hd/16-hd)**:用户要这两个面板的列表缩略图固定用 mod20 的 **2048 原图缓存**(之前 17-cover 是优先小 base64 → 偏糊)。做法 = **把封面取数优先级从「小封面优先」翻成「SelfPage 优先」**:`StatRankItem.Thumbnail` 改 `SelfPage()?.Thumbnail ?? CoverThumb() ?? History?.Thumbnail ?? EmptyThumb`、`GetPage()` 改 `SelfPage() ?? History?.GetPage()`(去掉 `HasCover?null:` 短路,使懒加载器总去生成);`FinishedItem` 同理 `SelfPage()?.Thumbnail ?? CoverThumb() ?? EmptyThumb`、`GetPage()=>SelfPage()`。**原理**:`SelfPage()` 建的临时 `ArchivePageContent` 走缩略图总管线 → mod20 的 `Thumbnail` 构造按本书路径查 `HiResCoverStore.GetResolution()`,**对预缓存过原图(2048)的书直接命中 2048 缓存**(秒出高清)、没预缓存过的书走全局默认。**文件移动/删除** → `SelfPage()` 为 null → 退回 17-cover 存的持久小封面(保命不空白)。把小封面降为兜底后,`CaptureCoversOnce` 存封面那处的匹配键从 `it.DisplayName` 改 `it.RawName`(见②,DisplayName 现在可能带「(隐藏)」前缀);`StatCover.Encode` 仍缩到 ≤160px,故 `ReadingStats.json` 不膨胀。**取舍**:高清封面常驻面板比小图吃内存(排行长时更明显,可接受);**从没预缓存过 2048 的书在面板里仍是普通分辨率**——要全高清就先对其所在文件夹跑 mod20「预缓存原图封面」。

**② 统计排行 右键加「删除」「隐藏」+「解除隐藏」(17-hide)**:原右键只有「打开」。新增:**删除** = 彻底删该书统计记录(阅读时长 + 在读/读完计数一并移除,带 NeeView `MessageDialog` 确认框,不动原文件);**隐藏** = 只从排行消失,**阅读时长与在读/读完计数仍计入**(无确认);**解除隐藏** = 仅在「显示隐藏的书籍」开着且右键到隐藏态的书时出现,永久取消隐藏。三项在 `rankMenu.Opened` 里按选中项 `IsHidden` 动态显隐(删除恒显、隐藏/解除二选一);对应方法 `DeleteSelectedStat()`(确认后调 `RemoveBook`)/`SetSelectedHidden(bool)`(调 `SetHidden`),均按 `it.RawName`+页数+大小 定位。

**③ 统计「…」菜单加「显示隐藏的书籍」可勾选开关(17-hide)**:勾上 → 隐藏的书重新出现在排行(书名前缀「(隐藏) 」便于右键解除);取消 → 收起。**没有任何隐藏项时该菜单项直接不显示**(不是置灰,在 `RefreshChecks` 里按 `HasHidden()` 设 `Visibility`,菜单每次打开都重算 → 解除最后一本后该项消失)。开关 `_showHidden` **仅本会话有效**(重启回默认 false,与面板其它视图态一致);而每本书的隐藏标志(`BookStat.Hidden`)持久化进 `ReadingStats.json`。原计划的「全部隐藏」按用户要求**砍掉**(只保留这一个开关)。

**数据侧(`ReadingStatsStore.cs`)**:`BookStat` 加 `int Hidden`(旧数据默认 0);`GetRanking` 加 `bool includeHidden=false` 形参 + 返回元组加 `bool hidden`,未开「显示隐藏」时 `Hidden==1` 的书跳过;**`GetSummary`/`GetBars`/`SumAllBooks` 一律不过滤 Hidden**(隐藏书仍计总时长/柱状图/在读·读完计数,只有排行列表过滤);新增 `HasHidden()`/`SetHidden(name,pages,size,hidden)`/`RemoveBook(name,pages,size)`(后两者按 名+页数+大小 用 `Find`/`RemoveAll` 定位,同 `SetCover` 口径)。`StatRankItem` 加 `RawName`(干净名,数据匹配用)+ `IsHidden`(右键菜单显隐用);`DisplayName` 在显示隐藏书时带「(隐藏) 」前缀,故凡数据匹配一律改用 `RawName`。

**验证**:沙箱真实 `build.py --patch-only` 干净 `4dbe593eb` 上 **新打 150、跳过 0** 零失配;三个 create 文件回读 text 与编辑版**逐字节一致**、整文件大括号配平(`StatisticsView.cs` 189/189、`ReadingStatsStore.cs` 159/159、`ReadFinishedView.cs` 132/132)。⚠️ **Linux 沙箱不能编译 WPF,待用户 `build.py --pull`(或直接编译)Windows 实测**:① 两面板封面对已预缓存原图的书显示 2048 高清、移动/删文件后退回小封面;② 统计右键 删除(带确认,时长/计数同步减)/隐藏(从排行消失但概要时长不变)/解除隐藏 正常;③「…」→「显示隐藏的书籍」勾选展开隐藏书(带前缀)、取消收起、无隐藏项时该项消失。

**🆕 17-scan(2026-06-15)· 移动+扫描后统计排行也能打开(配合 mod16-2b)**:用户反馈——文件移动后在设置里扫描,「已读完」能打开但**统计排行里双击仍报「找不到原文件」**。**根因**:扫描只把新路径修进 `ReadProgressStore`(已读完/书架)+ NeeView 历史(`Rename`),**没碰 mod17 的 `BookStat.Path`**;而且 `Scan` 返回的 `changes` 只含「本次 `ReadProgressStore` 真正变了的项」,**用户若已扫过一次(进度库已是新路径),再扫 `changes` 为空** → 单靠「扫描时同步」治不了已扫过的状态。**修法(改 4 个现有 create 文件 text、不新增补丁,仍 150)**:

- **① 读时自愈(主力,治已扫过的状态)**:`ReadProgressStore` 加 `GetCurrentPath(name,size)`——按 身份(去后缀名 + 字节大小,size 从身份 key `…SEP<size>` 解析,口径同 `GetFinishedBooks`)在 `_books` 反查最近已知路径(文件存在才返回)。`StatisticsView.BuildRank` 每行**先判存档路径是否存在,不存在就 `GetCurrentPath(r.name,r.size)` 反查**(扫描后那里已是新位置)→ 命中则改用新路径(`Exists=true`)、`GetProgressText`/历史匹配也用新路径(淡蓝进度条一并恢复)、并 `ReadingStatsStore.UpdatePaths` 回写持久化。**于是只要进度库已被扫描更新过,统计面板下次加载即自愈,无需再扫。**
- **② 扫描时同步(即时,治新移动)**:`ReadingStatsStore` 加 `UpdatePaths(List<(oldPath,newPath)>)`(遍历 `BookStat`,`Path==oldPath` 改 `newPath`,变了才存盘);`ReadScanService.Scan` 在 `RenameThumbnailCacheKeys(changes)` 后顺带 `ReadingStatsStore.Current.UpdatePaths(changes)`(后台线程安全);设置页扫完的 UI 回调里 `ReadFinishedView.Current?.RefreshFromScan()` 之后加 `StatisticsView.Current?.Reload()` → 统计面板当场刷新。

**验证**:`build.py --patch-only` 干净 `4dbe593eb` 上 150/0 零失配;5 个改动文件(`ReadProgressStore.cs` 88/88、`StatisticsView.cs` 196/196、`ReadingStatsStore.cs` 163/163、`ReadScanService.cs` 46/46、`SettingPageReadFinished.cs` 45/45)括号配平、回读字节一致。**前提**:该书读过(故 `ReadProgressStore` 有身份记录)且其 mod17 名(去后缀文件名)与进度库一致——移动不改文件名/大小,故匹配稳。⚠️ 待 Windows 实测:① 你当前已扫过的状态——重编译后重开统计面板,Vol.05 等应能直接双击打开、进度条恢复(不必再扫);② 以后再移动 → 扫描 → 统计面板当场就好。

**🆕 17b(2026-06-15)· 高清封面「统计 + 已读完」都抓 + 导出文件名带日期(改 3 个现有 create 文件、不新增补丁,仍 154)**:用户要求——高清封面要**统计面板和已读完面板都主动抓取**(此前 mod17-hd-db 只在统计面板抓、已读完仅复用 → 若某本只在「已读完」不在统计排行,就没高清);另外导出默认文件名加日期。**改法**:
- **① 高清库改「直存键」(`ReadingStatsStore.cs`)**:`CoverKeyOf(BookStat)`(经 BookStat 派生、需页数)→ `CoverKey(name,size)`(去后缀名 + 文件大小**直存**,不依赖 BookStat);`SaveCoverHiRes` 去掉 `pages` 参数(4→3 参)、`Has/Get/SaveCoverHiRes` 移除 `EnsureLoaded`+`lock`(直存键不再读 stats 数据,`StatCoverDb` 独立)。**理由**:已读完面板的书可能不在统计排行(无 `BookStat`、无页数),直存键才能抓/取;两面板的名都是同一 `StripExt`(`Path.GetFileNameWithoutExtension(TrimEnd('/','\\'))`)、size 都是文件字节,**键完全一致 → 高清封面跨面板共享**。键字符串格式仍是 `name\u0001size`,旧 `ReadingCovers.db` 完全兼容(`ReadingBackup`/`StatCoverDb` 对 covers 表是键格式无关的整表拷贝,不受影响)。
- **② 抓取调用适配 + 导出名加日期(`StatisticsView.cs`)**:`CaptureCoversOnce` 的 `SaveCoverHiRes` 调用去 `pages`;`DoExport` 默认文件名 `NeeView阅读备份.db` → `NeeView阅读备份_" + DateTime.Now.ToString("yyyy-MM-dd") + ".db`。
- **③ 已读完面板加高清抓取(`ReadFinishedView.cs`)**:`UpdateList` 在 `_thumbnailLoader?.Load(true)` 后挂 `ScheduleCoverCaptureHiRes(sorted)`(仿统计延迟多次 `DispatcherTimer`),`CaptureCoversHiResOnce` 对每项——`HasCoverHiRes` 先挡已存 → 读 `it.Thumbnail.ImageSource`(文件在时即走 mod20 的实时 2048,因 `GetPage()` 总返回 `SelfPage`)→ `StatCover.EncodeFull` → `SaveCoverHiRes(it.Name, it.Size, hi)`。全 try 兜底。

**🔧 17b 补修(2026-06-15,用户反馈「已读完 14 本只导出 7 张封面」)**:根因——`EncodeFull` 门槛是 `minLongSide=640`(当初故意"只存预缓存过的 2048、不存默认小图"),而**没跑过 mod20「预缓存原图封面」的书,缩略图是默认分辨率**(`ThumbnailProfile.GetThumbnailSize` 按面积≈`ImageWidth²`=512² 缩放,长边约 512~1024)——大多 <640 被挡。所以只有**预缓存过原图的书(2048,长边~2000+)**能进库,导出数 < 已读完总数。**修(改 2 个现有 create 文件 text、不新增补丁,仍 154)**:① `EncodeFull` 门槛 **640 → 256**——默认分辨率(~512)的封面也备份(仍比 160px 清晰、扛删文件),仅挡掉真正的 160px 兜底小图(`StatCover.Encode` ≤160px;文件没了时 `it.Thumbnail` 退到的那张);② 抓取延迟轮次 `1200/3500/7000` → `1500/4000/8000/15000`(多一档 15s,防大库缩略图还没后台生成完就导出抓不到)。改 `StatisticsView.cs`(EncodeFull 默认值 + 注释 + timer)与 `ReadFinishedView.cs`(timer + 注释)。**验证**:`build.py --patch-only` 干净 `4dbe593eb` 上 154/0,两文件配平(`StatisticsView.cs` 233/233·610/610、`ReadFinishedView.cs` 163/163·361/361)、回注往返一致。**✅ 2026-06-15 用户 Windows 实编实测:已读完 14 本封面全部导出**(此前只导 7 张的问题解决)。**要 2048 全高清**仍需先对其文件夹跑「预缓存原图封面」(mod20)再开面板;不预缓存则按默认 ~512 备份。**注**:文件已移动/删除且从未在面板加载过的书无源可抓,无法补高清(只能靠它在统计里的 160px)。

**验证**:`build.py --patch-only` 干净 `4dbe593eb` 上 **154/0 零失配**;三个生成文件括号配平(`ReadingStatsStore.cs` 170/170·450/450、`StatisticsView.cs` 233/233·607/607、`ReadFinishedView.cs` 163/163·360/360),回注往返逐字节一致,`CoverKeyOf` 残留 0、无 4 参 `SaveCoverHiRes`、无其它 mod 调用这三个方法(`GetCoverHiRes`/`HasCoverHiRes` 签名未变、原调用方仍合法)。**✅ 2026-06-15 用户 Windows 实编实测通过**:① 已读完面板的书移动/删文件后封面仍高清;② 导出文件名带当天日期;③ 配合下方 17b 补修后,14 本已读完封面全部导出(详见 17b 补修)。

---

### 18 · 历史记录只记单个文件(文件夹/盘符不入历史)

**起因**:用户截图发现 NeeView 历史记录里混进了大量「文件夹」项——打开过的盘符(`E:\`)、目录(`APP`)、系列目录(`[某系列][Vol.01-Vol.26]`,里面是一堆 zip)都被当成"打开过的书"记了进去,和真正在读的单本压缩包混在一起,很乱。用户希望历史**只保留单个文件**。

**原理核实**:历史登记的总闸门是 `BookHub/BookMementoControl.cs` 的 `private bool CanHistory(Book book)`——返回 `true` 才 `BookHistoryCollection.Current.Add(...)`。它有两个调用点(`TrySaveBookMemento` 与 `SaveBookMemento`),都走同一个 CanHistory,所以**改它一处、两处都生效**。`book.Path`(= `book.Source.Path`)对"文件夹书"是目录路径、对"单文件书"是文件路径,故用 `System.IO.Directory.Exists(book.Path)` 区分(目录→true,单个压缩包→false)。NeeView 自己已有 `IsInnerArchiveHistoryEnabled`(压缩包内项)、`IsUncHistoryEnabled`(UNC 网络路径)两个守卫,本魔改与它们并列、互不干扰。

**做法**:CanHistory 判定链最后追加一条 `&& !System.IO.Directory.Exists(book.Path)`(单文件 false→记;文件夹/盘符 true→不记)。`Directory.Exists` 是 .NET 内置、用全名,无需新增 using。

**连带效果(已读完面板自动受益)**:mod16「已读完」面板的列表来源是「历史项里被标读完的」(`BookHistoryCollection.Current.Items.Where(h => GetFinishedPaths().Contains(h.Path))`)——历史里没有文件夹项后,已读完面板**自动也不会再出现文件夹**,无需单独改 mod16。

**不影响 / 边界**:① 只管"之后新打开的书",已经记在 History.json 里的旧文件夹项不会被本魔改删除(用户可在历史面板「删除无效项/清空」自行清);② UNC、压缩包内项各有 NeeView 自己的开关,本条不冲突;③ 副作用 = **打开文件夹/盘符浏览不再写入历史记录**(用户要的预期行为)。

**⚠️ 与 mod17 统计的关系(✅ 已实现:统计也已过滤文件夹,详见本节末「★ 最终实现」第 2 条)**:mod17 阅读统计是**独立计时**的(`Tick()` 累加全屏秒数、`NoteProgress()` 记读完),**不经过** CanHistory;其 `ReadingStatsStore` 里还专门写了"文件夹书大小取 0"——即**统计仍会把文件夹的阅读时长记进去**。若希望统计/排行也只算单文件,需在 `Tick()`/`NoteProgress()` 里对"当前路径是目录"(`Directory.Exists(_curPath)`)同样跳过——那是另一处改动,本 mod18 未含。

**状态:✅ 已实测可用(2026-06-06 用户 Windows 编译实测通过;历史=全屏单文件 + 统计 mod17 过滤文件夹 + 已读完 mod16 随历史,三者口径统一)**。干净 `3b62b9c9f` 上 `build.py --patch-only`「新打 110、跳过 0」零失配;CanHistory 末行已含 `!System.IO.Directory.Exists(book.Path) && (MainWindow.Current?.WindowStateManager?.IsFullScreen ?? false)`,stats_store 的 `Tick()`/`NoteProgress()` 已含目录过滤。**实测确认**(三条验证点均通过):① 全屏下打开单个压缩包→进历史,非全屏打开 或 打开文件夹/盘符→不进历史;② 打开文件夹全屏浏览→不计入统计时长/排行;③ 已读完面板无文件夹项。

**★ 最终实现(2026-06-06,已完成并 worktree 验证零失配;补丁仍 110 条,均为改现有补丁内容、未新增条目)**:下面两件事 + 一个确认都已落地,三者口径一致(历史=全屏单文件、已读完=随历史、统计=单文件)。下文「改法」即实现说明:

1. **历史再收紧为「F11 全屏下打开的单文件」才记**(在 mod18 现有"排除文件夹"之上再加一条):用户希望与 mod17「全屏才计时」对齐——只有**全屏阅读**时打开的单文件才进历史,把"在书架里非全屏随手点开预览"也挡在历史外。改法:在 `BookHub/BookMementoControl.cs` 的 `CanHistory(book)` 判定链里、紧挨 mod18 那条 `!System.IO.Directory.Exists(book.Path)` 之后,再加全屏判断:
   `&& (MainWindow.Current?.WindowStateManager?.IsFullScreen ?? false)`
   (`MainWindow.Current.WindowStateManager.IsFullScreen` 是 mod09 已用过的真实全屏属性;`MainWindow.Current` 与 BookMementoControl 同在 `namespace NeeView`、实例方法里可直接访问——接手 AI 编译时确认拼写/可空写法即可,别编造。)
   ⚠️ **副作用须知**:CanHistory 同时管"续读进度写回"(`SaveBookMemento` 第 196 行也走它),所以改成"全屏才记"后,**非全屏窗口模式看的书既不进历史、续读位置也不保存**。用户是全屏阅读者、接受此取舍。若日后想两全:把全屏判断只加到"首次登记"那条路径(`TrySaveBookMemento` 第 122 行的 `if (!_historyEntry && CanHistory(book))`)、而 `SaveBookMemento` 仍照常写进度——但那要把 CanHistory 拆成两份判定,复杂些。

2. **统计(mod17)也不记文件夹**(用户已确认:要):mod17 独立计时、不走 CanHistory,目前打开文件夹全屏浏览仍被计时并进时长排行(其 `ReadingStatsStore` 甚至专门写了"文件夹书大小取 0")。改法在 `ReadingStatsStore` 两处加"路径是目录就跳过":
   · `Tick()`(5 秒采样累加那段):拿到当前书路径后,`if (System.IO.Directory.Exists(path)) return;`(本次不累加);
   · `NoteProgress(path, index, count)`(记读完):方法开头 `if (string.IsNullOrEmpty(path) || System.IO.Directory.Exists(path)) return;`。
   这样文件夹浏览既不计时长也不记读完,统计/排行只剩单文件。(`ReadingStats.json` 里已有的旧文件夹数据可让用户在面板「…」导出清洗,或另加一次性清理;非必须。)

3. **已读完(mod16)无需改 ✓**:它的列表是从历史项里筛"读完的"(`BookHistoryCollection.Current.Items.Where(h => GetFinishedPaths().Contains(h.Path))`),mod18 让历史不再有文件夹后,已读完面板**已自动只剩单文件**——用户也确认过,接手 AI 不必动 mod16。

> 上述 1、2 均已实现,并已同步本节状态、§1 待办块与表格;补丁总数维持 **110**(改现有补丁内容、未新增条目)。

---

### 19 · 海报墙(Poster Wall)—— v4 定型:书架的第五种「样式」(2026-06-10 三轮用户反馈)

**形态(最终)**:海报墙不再是覆盖层,而是**书架面板的第五种样式**——书架「···」菜单:列表/内容/横幅/缩略图/**海报墙样式**(`PanelListItemStyle.PosterWall`)。地址栏(每段可点+换盘)、搜索、排序、前进后退、F11、窗口按钮、右键菜单、双击进入、拖拽 = **全部作者原生**。设置 → 面板 的「默认样式」下拉也会自动出现「海报墙」(AliasName+restext)。

**演进与教训(为什么放弃 v1~v3 覆盖层)**:v1~v3 把墙做成 `MainWindow.Root` 顶层覆盖层,自绘顶栏/导航/按键策略。用户三测暴露整类问题:Win11 **贴靠布局**命中被盖住的系统标题栏热区、**设置窗打不开**、**F11 间歇失灵**(焦点/命中测试都属于"覆盖一切"方案的原罪),且自绘地址栏/搜索/排序是在重造作者已有的轮子。v4 遵用户原话「**能用作者的就用作者的**」:只新增一种样式,其余零自绘。

**样式实现**:
- **瓦片模板 `PosterWallTemplate`**(FolderListBox.xaml 资源区,锚链在 ListBoxItemThumbnailStyle 块后):深底圆角 + `Image Stretch=Uniform`(Fant)整图;悬停 = 白描边 + 底部渐变 `DisplayName`(Trigger SourceName);左上 = **作者 `FolderListIcon`**(文件夹/压缩包/书签角标,与其它样式同款);右下 = **进度徽章直接绑 mod13 给 FolderItem 加的 `ReadProgressText` / `IsReadFinished`**(DataTrigger:null→隐藏、读完→绿底✓;mod13 的 `NotifyIconOverlayChanged` 会 Raise 它,翻页回书架即时刷新,零新代码);`PendingCount` 透明度、`TagsControlStyle` 标签均照抄作者部件。
- **容器 `ListBoxItemPosterWallStyle`**:BasedOn 缩略图容器(=双击/右键/拖拽/键盘 EventSetter 全套作者行为),仅改 Content 对齐为 Stretch 填满槽位。
- **触发块**(锚=Thumbnail DataTrigger 整块,链后):`PosterWall` → 模板/容器/`FixHomeAndEndKeyBehavior`/`MouseWheelSpeedRate` + `VirtualizingWrapPanel ItemSize="{Binding PosterWallItemSize}"`(虚拟化/回收/像素滚动与缩略图同管线)。
- **槽位尺寸 `FolderListBoxViewModel.PosterWallItemSize`**:`(w+12, round(w×1.42)+12)`,w=`SystemConfig.PosterWallTileWidth`(140~400,默认220);构造里 `SubscribePropertyChanged` 该键 → 改宽即时重排(作者 ThumbnailItemSize 同款写法)。
- **Ctrl+滚轮缩放**(FolderListBox.xaml.cs,锚=`PreviewMouseUpWithSelectionChanged` 订阅行后):样式为 PosterWall 时 Handled。**【mod26 v6 改】**原 ±20 写 `PosterWallTileWidth`,现 **±1 写 `PosterWallColumns`(3~12,上滚减列=封面变大)**。
- **分支点补全**:`FolderList.IsThumbnailVisible`+PosterWall→true(缩略图管线开,自动吃 mod02 可见优先+04-N 池);左右键判定两处(FolderListViewModel/FolderListBoxViewModel)、拖放指示方向(InsertDropAssist)均按 Thumbnail 同语义。
- **菜单与文案**:FolderListViewModel 菜单 +1 行(锚=StyleThumbnail 行);restext zh/en 各 +`Word.StylePosterWall`、`PanelListItemStyle.PosterWall`(append,marker 防重)。
- **配置**:`SystemConfig` 6 个海报字段保留(Profile 兼容),v4 仅 `PosterWallTileWidth` 在用;Enabled/Root/Sort/Hotkey 标注弃用。

**旧件清场(机制化,零手工)**:v1~v3 的 `_Mod/PosterWallView|Controller|SettingPagePosterWall.cs` 三个 create **壳化为纯注释占位**——build.py 还原 = 「checkout 改动文件 + 删除 create 文件」,保留这三个路径就能让任何旧树(含 v1~v3 残留)被自动清干净再重建为无代码壳;MainWindow `Attach` 与 SettingWindowModel 注册两条旧 replace 从 PATCHES 移除,还原机制自动 checkout 回原版。**补丁 123 → 135**(19 组 = 3 壳 create + 14 replace + 2 append)。

**v4.1 修订(四测崩溃)**:切样式即崩,根因=漏补 `PanelsConfig.GetPanelListItemProfile` 的中央取档 switch(默认臂 throw;DetailToolTip 在样式变更时必经)。19-15 加 `PosterWall => ThumbnailItemProfile` 修复;并全仓复扫确认这是唯一会 throw 的该枚举 switch。**教训:给枚举加成员,必须全仓搜该枚举的每一个 switch/case,凡默认臂为 throw 的全要补分支,不能只补眼前用到的。**

**机制要点(上游漂移照此放回)**:① 触发块/资源块两条 xaml 锚是多行原文,上游若改缩略图触发块,把 PosterWall 块原样链回其后即可;② mod13 在 19 之前先打(物理顺序),徽章绑定才有属性可用——**勿重排**;③ 槽位高=宽×1.42 只在 `PosterWallItemSize` 一处,改比例改这里;④ 壳化三 create 永远保留(还原清场依赖它们)。

**验证点(v4 四测清单)**:① 书架「···」→ 出现「海报墙样式」,点选即整面海报(地址栏/搜索/排序照常可用);② 贴靠布局/设置窗/F11/拖拽窗口 = 与普通 NeeView 完全一致(问题类消失);③ 双击封面开书、双击文件夹进入、右键菜单/拖出文件 = 与其它样式一致;④ 徽章:未读不显、读过显 %、读完绿✓,翻几页回书架立即更新;⑤ Ctrl+滚轮海报即时缩放(140~400);⑥ 大文件夹滚动流畅、可见优先出图(mod02/04-N);⑦ 左上角标 = 作者线框图标;悬停出书名;⑧ 切回缩略图/列表样式一切照旧;设置→面板 默认样式下拉含「海报墙」;⑨ 升级自 v1~v3 的树:`_Mod` 三文件变成注释壳、主界面无任何覆盖层残留。

**v5 形态定稿:中央宿主(取代 v4.2~v4.4 的「撑满左面板」路线,已废弃)** —— 用户实测「撑满侧栏」三痛(全屏右黑区 / 鼠标入主区整屏黑 / 右缘缝)源于「墙=侧面板」被中央区与自动隐藏摆布,遂把**墙搬进中央显示区**:`PosterWallCenterHost.Attach(MainWindow)`(Loaded 后幂等)把宿主 Border 挂进 `MainViewPanelRect`(作者书页矩形,随面板开合自动避让 → 永远精确填满、零缝零覆盖);样式=海报墙且无书 → 塞原生 `FolderListBox`(`new FolderListBoxViewModel(BookshelfFolderList.Current)`,模型共享双向同步);`BookHub.BookChanged` 开书→Collapsed、关书→回墙;切走样式释放。进入海报墙样式边沿自动 `RequestUnload(null,true)` 合书(「点海报墙却显示书页」违反直觉)。回墙 = 作者「关闭书籍」命令 或 海报墙下 Esc→`RequestUnload(this,true)`(`TextBoxBase` 聚焦/无书时不拦)。

- **v5.5 双渲染 + 目录书→墙转译**:同一 `FolderListBox` 按依赖属性 **`IsPosterWallHost`**(19-19 注册于 FolderListBox 类、默认 False)双渲染——19-9 重写为两个 `MultiDataTrigger`:样式=PosterWall ∧ host=True → 整面海报(模板/`ListBoxItemPosterWallStyle`/`vwp:VirtualizingWrapPanel ItemSize={Binding PosterWallItemSize}`);∧ host=False → 渲染为**内容样式**(`ContentTemplate`+`ListBoxItemBorderStyle`,左面板在墙模式下的形态);宿主实例置 True,19-12 Ctrl+滚轮限 `this.IsPosterWallHost`(只缩中央墙)。**地址栏转译** `TryTranslateDirectoryBookToWall`:海报墙下当前书 `Book.Path` 是磁盘目录且【含子目录 ∨ 含书文件 `ArchiveManager.Current.IsSupported(f,false,true)` ∨ 完全无图片 `PictureProfile.Current.IsSupported(f,false)` 全否】→ `RequestUnload(null,true)` + `BookshelfFolderList.Current.RequestPlace(new QueryPath(path),null,UpdateHistory)`(点地址栏段/外部以文件夹打开均走此);叶子散图夹/压缩包/单册不转译(双击海报阅读零影响);`_lastTranslatedBookPath` 防重、书空复位。**已知小瑕疵**:面板内容样式下 LR 键(19-13)与 DropAssist 仍按 PosterWall 网格语义(VM 层无 view 宿主标志,暂不加复杂度)。
- **★ v5.4 F11 终极真因(屡修不中后逐字读 mod05 恢复链,推翻早期焦点假说)**:F11 在老板键恢复后失灵,与全屏命令无关——**按键根本没进 WPF 键盘路由**。mod05 `BossKeyHotKey.ReengageInputFocus` 只补 **Win32 焦点**(`SetForegroundWindow`/`SetActiveWindow`/`SetFocus(hwnd)`),从未设 `Keyboard.FocusedElement` → WPF 逻辑焦点仍 null/死元素 → `PreviewKeyDown`/`InputBindings` 无路由起点 → F11 等快捷键全失灵(「双击窗口才恢复」=鼠标点击替 WPF 重建逻辑焦点)。**修(mod05 治本)**:`ReengageInputFocus` 的 `_window.Activate()` 后,若 WPF 焦点坏(空/呈现源不属本窗/元素不可见)则 `_window.Focus()`+`Keyboard.Focus(_window)`;mod05 的 ActivateTimer 3 次重试带上。另保双保险:MainWindow 侧 F11 直调 `WindowStateManager.ToggleFullScreen()` 绕过 `WindowStateController` 里 `Application.Current.Windows...SingleOrDefault(IsActive)`(NeeView MainView 可独立浮动 `MainViewWindow`,老板键恢复后两窗口同时 `IsActive` → `SingleOrDefault` 抛异常 → F11 静默失败,这是早期 v5.3 定位的次因)。**两条通用铁律**:① Win32 `SetFocus` ≠ WPF `Keyboard.Focus`,凡用 Win32 抢前台/焦点后要让 WPF 快捷键工作必须显式 `Keyboard.Focus` 重建逻辑焦点;② 任何「跟随 X 自动调 Y」逻辑,X 必须不受 Y 影响否则成振荡环;③ 同组补丁里每条 marker 不得出现在其它条 text 中(16a 曾含 16b 的 marker 致 16b 误跳过,双树「跳过数≠0」即此类串扰报警)。**撑满组(19-16)已删**,其残留改动经 build.py `OBSOLETE_EDITS`(还原阶段 checkout)自动撤干净(与 `OBSOLETE_FILES` 互补)。
- **v5.6 闪屏修复(墙闪)**:老板键带书隐藏→恢复的「中央黑框→整面墙→漫画」三帧闪。根因=mod05 隐藏走作者 `AppState.SuspendAsync()`(内 `RequestUnload`+`RequestPlaceClear` 卸书 → `BookChanged(null)` → 宿主判「墙样式+无书」→ 墙在隐藏期间即 Visible)。**修(两端)**:① mod05 带书隐藏置 `PosterWallCenterHost.SuppressWallUntil=Now+6s`(无书复位 `MinValue`);② 宿主 Update 判定加 `!suppressed`,抑制命中挂一次性 `DispatcherTimer` 到期重查(书载回→无事;极端超慢→到期亮墙不卡黑;`_requeryQueued` 单飞)。删 19-17 须同步摘 mod05 置位行。
- **v5.7 Normal 黑框零帧化**:作者 `ResumeAsync` 序列=`RestoreWindowPlacement()`(还原 Normal 态,故「Show 前提前设全屏」会被覆盖)→`Collapsed`→100ms+双 Render Yield→`Activate`→`Visible`。正解=mod05 在 `ShowWindow()` 前挂一次性 `Root.IsVisibleChanged`,显形瞬间同布局批次 `SetFullScreen(true)` → 首帧即全屏、Normal 黑框零帧;钩子自摘 +5s `DispatcherTimer` 兜底,原 ShowWindow 后全屏调用降级幂等兜底。剩余:书装载期全屏深色底一瞬(装载耗时非闪框)。

- **v5.8 书名设置 + 独立设置页(2026-06-20)**:海报墙书名从「仅悬停浮现」升级为「可选常显 + 行数可调」,并新增作者原生风格独立设置页。**新文件 `_Mod/PosterWallSettingPage.cs`**(create;**与废弃旧 `SettingPagePosterWall.cs` 避开同名**,文件名与类名都叫 `PosterWallSettingPage`;注册于 `SettingWindowModel` 页列表):两 `SettingItemSection`——「书名」(显示书名 CheckBox→`PosterWallShowName`、行数 Slider 1-5→`PosterWallNameLines`,带「N 行」标签)、「海报」(海报大小 Slider 140-400→`PosterWallTileWidth`,带「N px」标签);全程 `SafeGet*`/try 兜底,绝不拖垮设置窗。**`SystemConfig` 新增** `PosterWallShowName`(bool 默认 ON)/`PosterWallNameLines`(int 1-5 默认 2)+ 计算属性 `PosterWallNameAreaHeight`(关=0、开=`行数×16+8`,setter 用 `OnPropertyChanged(nameof(PosterWallNameAreaHeight))` 通知,供模板绑定 + 槽位高度共用)。**模板改造(封面下方独立行)**:`PosterWallTemplate` 根 `Grid`→`DockPanel`(LastChildFill),书名 `Border` 停 `Bottom`、`Height={Binding System.PosterWallNameAreaHeight}`(关时 0=不占空间),内 `TextBlock`(`DisplayName`、`FontSize=12`、`LineHeight=16`+`LineStackingStrategy=BlockLineHeight`、`TextWrapping=Wrap`+`TextTrimming=CharacterEllipsis`、居中);原封面 + 悬停覆盖移入内层 `Grid` 占满剩余;`PosterCap`(悬停浮名)加 `Visibility` 绑 inverse-`ShowName`(常显开时不重复浮名)。**槽位高度** `PosterWallItemSize` 末加 `+ PosterWallNameAreaHeight`;`FolderListBoxViewModel` 构造 +2 条 `SubscribePropertyChanged`(`PosterWallShowName`/`PosterWallNameLines`→`OnPropertyChanged(PosterWallItemSize)` 重排)。改完即时生效。**补丁 233→234**(+1 create;另 6 条既有 text 改:[116][117]`SystemConfig`、[123][122]`FolderListBoxViewModel`、[120] xaml、[172] 注册)。默认 ShowName=ON、2 行——用户要的就是封面下方带书名,首次运行即所见。

**已知限制(取舍)**:贴满/中央宿主只作用于书架默认位置;不再有独立热键/开关/重启(就是个样式,随点随用)。

---
### 26 · 海报墙「无缝布局」—— 封面按真实宽高比变宽的 justified 瀑布流(2026-06-20)

**⚠⚠⚠ v8(2026-06-21)海报墙 = 「**虚拟化版 masonry**(VirtualizingPanel + IScrollInfo)+ 比例防抖」—— 当前实现,取代下方 v7「不虚拟化 Panel」与 v6/v6.1(均作历史)⚠⚠⚠**
> **动机**:v7「不虚拟化」视觉正确但**在 1000 本量级卡爆**——整夹全部实体化:① 加载期逐张封面写比例 → 每张触发整 1000 项重排 = **O(n²)**(开夹「卡到爆、半天才显示、缓一下又卡死」);② **任何宽度/列数/比例变化都要全量重排 1000 项**(F11 进/退、侧栏开合改墙宽、Ctrl+滚轮改列数 = 「超级无敌卡」;窗口态老板键恢复因宽度没变→缓存命中→较顺,F11 态恢复因宽度变过→全量重排→无敌卡)。**布局不能跨宽度复用**,故「卡一次就够了」不成立。根治只有**虚拟化**(只实体化可视 ~30 项)。
> **v8 做法**(`NvPosterWallPanel : VirtualizingPanel, IScrollInfo`,避开 v6 旧坑):
>   · **布局算法对【全部项】**算 x/y/w/h + 完整内容高(`ComputeMasonry`/`ComputeJustified`/`AspectAt` 与 v6/v7 **逐字不变**;O(n) 纯算术、**不实体化**;比例未知项用默认 0.70 估算);
>   · **只实体化可视范围**`[first,last]`(上下各预实体化半屏缓冲),用 **WPF 标准 generator**(`GeneratorPositionFromIndex`/`StartAt`/`GenerateNext`/`PrepareItemContainer`)取数、**清理按容器真实 item 索引**(`IndexFromGeneratorPosition`,绝不靠位置算术)→ **不掉书**;可视范围用**线性扫描**(masonry 的 `_y` 对 index 非严格单调、不能二分),区间退化时**兜底实体化最前若干项**(绝不空、绝不掉到只剩一本);
>   · **`VirtualizationMode=Standard` 关回收**(在面板代码里 `SetVirtualizationMode(this,Standard)`——`IsVirtualizing`/`VirtualizationMode` 是**继承属性**,面板上置本地值即覆盖 ListBox 继承的 `Recycling`)→ **容器不复用** → 不会把 A 书的比例/布局槽串到 B 书(=v6「竖封面变宽」的根因,从机制上焊死);
>   · **`ArrangeOverride`** 把每个已实体化容器经 generator 映回 item 索引,排在 `(_x[i]-offX, _y[i]-offY, _w[i], _h[i])`;**`SetVerticalOffset`→`InvalidateMeasure`**(虚拟化:滚动要按新视口补实体化,再由 arrange 平移);`OnItemsChanged` 处理增删/重置(切夹 Reset 清全部容器+滚动归零);`BringIndexIntoView`/`MakeVisible` 支持键盘滚到离屏项;
>   · **比例防抖(C)**:`MarkLayoutDirty` 不再立即 `InvalidateMeasure`,改用 `DispatcherTimer(Background,150ms)` throttle(攒一批每 ~150ms 重排一次)。**注**:虚拟化后只 ~30 个可见封面会加载/触发 watcher,O(n²) 加载问题其实已基本消失,防抖是额外保险(快速滚动时也压抖)。
> **XAML 不改**:`IsVirtualizing=True`(继承)→ 我的 VirtualizingPanel 即虚拟化;`CanContentScroll=True`(继承)→ ScrollViewer 用我的 IScrollInfo;`VirtualizationMode` 在代码里压成 Standard。
> **固有小瑕疵(已知接受)**:未滚到的封面比例未知(用默认 0.70 估算)→ **宽封面滚入视野时会轻微 reflow**;但多数竖封面=默认值=不跳,故抖动很小。
> **沙箱**:`0ab0c48b0` `--patch-only` **235/0**;`NvPosterWall.cs` 括号 ()/{}/[] 全平衡(251/86/43,diff 全 0)、基类 `: VirtualizingPanel, IScrollInfo`、generator/IScrollInfo/防抖符号齐全、三处拼接缝(CHUNK_A→防抖、CHUNK_B→Measure、IScrollInfo→Watcher)逐行核过。🚧 **沙箱无 WPF 无法编译——这是「自绘虚拟化」那一类、与出过 bug 的 v6 同源、我无法验证,极可能要再迭代 1 轮**;Standard 关回收已把「变宽」焊死。**务必 Windows 实测**:① **1000 本夹开夹快**(不卡爆)、滚动顺、能到底、来回滚不掉书;② **F11 进/退、侧栏开合、老板键恢复、Ctrl+滚轮缩放**全快(只重排 ~30 项、非 1000);③ **竖封面恒竖**(Standard 关回收应焊死);④ Ctrl+滚轮(改列数)封面缩放不裁、无膨胀黑边;⑤ masonry+justified 两模式、书名开关 1-5 行;⑥ 键盘 Home/End/方向键滚到离屏项(`BringIndexIntoView`——若编译报错=签名差异,删该 override,仅失「键盘滚到离屏」、其余不受影响);⑦ **【回归】**双击文件夹/开书是否仍崩(`PosterWallCenterHost` 双实例未改,若崩要堆栈);⑧ 宽封面滚入时轻微 reflow 属预期。**回退路线**:若仍坏或超大夹仍卡 → 方案 A(`VirtualizingWrapPanel` 行式 wrap,成熟/快/可测,牺牲竖向错落 masonry、行尾留小缝)。

**⚠⚠ v7(2026-06-21)海报墙 = 「**不虚拟化** Panel + 极简 IScrollInfo」—— 已被上方 v8 取代,以下作历史 ⚠⚠**
> **动机**:v6 自绘虚拟化(手写 IScrollInfo + 回收 generator + 异步比例重排)首次编译运行后,用户实测仍有四个互相纠缠、且都是「手写虚拟化面板」出了名难搞对/沙箱无 WPF 无法验证的 bug:① **滚动掉书**(往下拉再往上拉,封面越掉越少直到只剩一本且滚不动)② **截断**(只铺前几十本、拉不到后面)③ **正常竖封面偶尔变宽图**(回收期把 A 书 `PosterAspect` 串到 B 书 → 比例错 → 跨列变宽)④ **放大时黑边膨胀**(格子比例错、Uniform 把竖图塞进宽格子露大片深色边,选中框还把整个错格子框为封面)。v6.1 的「无穷高兜底」很可能正是①的祸首(让面板在有限/无穷两种 measure 间反复 churn 了 generator)。
> **根因统一**:全部源于 **虚拟化 + 回收 + generator** 的脆弱衔接。用户拍板:**彻底去掉虚拟化**。
> **v7 做法**(`NvPosterWallPanel : Panel, IScrollInfo`):
>   · 面板改成**普通 `Panel`(非 `VirtualizingPanel`)** → ListBox 一次性把**全部项实体化**为子元素、**永不回收**;ListBox 上的 `IsVirtualizing=True`/`VirtualizationMode=Recycling` 对普通 Panel **自动失效**(无 VirtualizingPanel 可虚拟化)→ **XAML 一字不改**。
>   · **极简 `IScrollInfo`**:只有像素偏移 `_offset` + extent/viewport + 滚动方法 + `MakeVisible`,**没有 generator / RealizeRange / CleanupContainers / OnItemsChanged**。配合 ListBox 原有 `CanContentScroll=True`(SCP 认面板的 IScrollInfo)即工作;万一被无穷高 measure(像素滚动场景)也兜得住(返回 `_extentHeight`、由外层 ScrollViewer 平移)。
>   · **滚动只 `InvalidateArrange`(平移)、不 `InvalidateMeasure`** → 不重排、不触发 PosterAspectWatcher churn;`MeasureOverride` 量全部子元素、`ArrangeOverride` 按 `_x-offset.X, _y-offset.Y` 排全部。
>   · 布局算法 `ComputeMasonry`/`ComputeJustified`/`AspectAt` 与 v6 **逐字不变**,只搬进 Measure/Arrange 对全部子元素生效。
> **→ 没有 generator、没有回收 → 上述①②③④从结构上不可能再发生。** **保留 v6.1 的 `UniformToFill→Uniform`**(比例不再被串 → 格子与封面恒匹配 → Uniform = 精确贴合无边;Uniform 仅作「比例万一不对也绝不裁」的安全网)。**v6.1 的无穷高兜底已被 v7 整段重写删除**(它是①的疑凶)。
> **代价**:超大文件夹(数千+)一次全加载偏重;常规(几十~几百本)无压力。若极大夹卡顿,退路=退回 v5 第三方 `VirtualizingWrapPanel`(虚拟化正确但行式 wrap 有缝)。
> **沙箱**:`--patch-only` **235/0**;`NvPosterWall.cs` 括号 ()/{}/[] 全平衡、无 generator/虚拟化残渣、IScrollInfo 成员齐全、与 PosterAspectWatcher(调 `MarkLayoutDirty`)接口一致。🚧 **沙箱无 WPF 无法编译**,务必 Windows 实测:① 海报墙铺出**全部**书、滚动条可用、能滚到底、来回滚不掉书;② 竖封面恒竖(不变宽);③ Ctrl+滚轮缩放:封面缩放不裁、无膨胀黑边、格子贴合封面;④ masonry+justified 两模式、书名开关/1-5 行;⑤ 键盘 Home/End/方向键滚到离屏项;⑥ **【回归】**双击文件夹/开书是否仍崩(`PosterWallCenterHost` 双实例未改,若崩要堆栈);⑦ 最大夹的性能(全实体化)。

**⚠⚠ v6(2026-06-21)海报墙=「自绘虚拟化面板,支持 masonry 瀑布流 + justified 等高整齐两种排版,设置里自由切换」(下方先讲 masonry 主体机制,justified 布局 A 见 §2 同日最后一条 changelog)—— 本节下方 v5「VWP justified」描述仅作历史,当前实现以此 banner 为准 ⚠⚠**
> **动机**:用户实测 v5 justified(等高行、行内变宽)痛点=为把每排填满、某些排被压小→封面看不清;最终选 **masonry(B)**:封面保持设定大小、宽窄按真实比例、**同一横带高矮不一**、紧密咬合、只底部参差。VWP 是行式 wrap、做不出列式 masonry → **弃 VWP 基类、自写虚拟化面板**。
> **新实现(整体重写 `_Mod/NvPosterWall.cs` 的 `NvPosterWallPanel`)**:`NvPosterWallPanel : VirtualizingPanel, IScrollInfo`(不再继承 VWP、不再用 `IItemSizeProvider`)。
>   · **布局 `ComputeLayout`(纯算术 O(n))**:固定列数 `PosterWallColumns`(3~12);列宽=可视宽/列数(横向严丝合缝、零缝)。每张 `aspect=FolderItem.PosterAspect`(默认0.70、夹[0.35,3.0])→ `span=aspect<1.15?1:aspect<1.9?2:3`(单/双/三图,宽封面跨列);贪心塞进「span 窗口内列底最矮处」;`coverH=spanW/aspect`(封面区比例=真实比例→模板 `UniformToFill` **零裁零黑边**),`tileH=coverH+nameArea`。竖向 masonry 固有零星空隙(用户已接受、换封面保大)。
>   · **虚拟化**:measure 只实体化视口(±半屏缓冲)内项。**关键坑**:跨列 masonry 下 `_y` 对 index **非严格单调**(span 项被抬高、后到窄图回填更矮空列 → 后项 y 反更小),故**不能二分**,用**线性扫描**求可视 `[first,last]`(O(n)/measure;回填造成的少量越界项一并实体化排视口外、有界)。generator 用 WPF 标准「先 `StartAt`/`GenerateNext` 生成、后 `CleanupContainers` 清理」;`MeasureOverride` 先访问 `InternalChildren` 再用 generator(基类硬性次序)。
>   · **滚动**:自实现 `IScrollInfo`(像素纵向;`ExtentHeight`=内容总高);`SetVerticalOffset`/`MakeVisible`/`BringIndexIntoView` 支持滚轮 + 键盘 Home/End/方向键滚到选中项。**绝不在 `MeasureOverride` 内调 `InvalidateMeasure`**(避 v5 同类递归);滚动改偏移→`InvalidateMeasure`(延迟、非同步重入)。布局缓存键(count/宽/列数/nameArea/`_layoutDirty`)→ 滚动不重排、只重实体化。
>   · **比例回填**:`PosterAspectWatcher` 改为上溯找 `NvPosterWallPanel` 祖先、调其 `MarkLayoutDirty()`(置脏 + `InvalidateMeasure`)。
> **配套改动**:① `SystemConfig` 新增 `PosterWallColumns`(int 3~12 默认5,`SetProperty` 可观察)〔并入 mod19 的 `_isPosterWallEnabled` 字段块 + `IsPosterWallEnabled` 属性块两条既有 text、不增条〕;② Ctrl+滚轮(FolderListBox.xaml.cs)从「±20 写 `PosterWallTileWidth`」改为「±1 写 `PosterWallColumns`(上滚减列=封面变大,夹3~12)」(marker `PosterWallTileWidth = Math.Min`→`PosterWallColumns = cols;`);③ `PosterWallTemplate`(FolderListBox.xaml)`Margin="6"`→`"0"`、`CornerRadius="6"/"0,0,6,6"`→`"0"`(无缝方块贴合)。`PosterWallTileWidth` 字段/属性保留(now 仅死代码 `PosterWallItemSize` 读,无害)。
> **沙箱**:纯净 `0ab0c48b0` `--patch-only` **235/0 零失配**;`NvPosterWall.cs` 括号 ()/{}/[] 全平衡;nullable 已对齐(`ScrollOwner` 非空型 + 去冗余判空)。🚧 **沙箱无 WPF 无法编译**,务必 Windows 实测:① **【最关键·回归】海报墙模式下双击文件夹/开书是否仍崩**(v5 历史有 StackOverflow,根因疑在双实例 host 同步或旧 VWP;本版已换面板,若仍崩查 `PosterWallCenterHost`);② 滚动流畅、千张不卡、Ctrl+滚轮调列数即时生效;③ 键盘 Home/End/方向键能滚到目标(若 `BringIndexIntoView` 编译报错=该 API 签名差异,删该 override 即可);④ 封面无裁无黑边、横向无缝、竖向少量空隙(masonry 预期);⑤ 书名开关 `PosterWallShowName` 仍生效(关=纯封面无缝、最贴近选定效果)。

> **v6.1 运行期修复(2026-06-21,首次成功编译运行后用户实测两 bug)** —— **① 截断**(masonry/justified 两模式都只铺约 2~3 行后大片黑、且滚不动):症状在代码上唯一对应「面板被外层**无穷高 measure**」——`MeasureOverride` 收到 `availableSize.Height=∞`(虽然 NVListBox 基样式明设 `ScrollViewer.CanContentScroll=True`、**为何仍无穷高待查**)时,回退到偏小的旧 `_viewport.Height` 来实体化可视项、却按 `Min(_extentHeight, 小视口)` 汇报自身高 → 外层 ScrollViewer 以为内容就这么矮、不给滚动条、内容下方全黑。**修**:`MeasureOverride` 加 `unboundedH` 标志——被无穷高 measure 时**实体化全部项(first=0..count-1)+ `measuredH=_extentHeight`(汇报完整内容高)**,保证所有书都铺出、外层可像素滚动到底;**有限视口时零影响**(原虚拟化路径完全不变,安全)。代价:无穷高分支下超大文件夹会一次实体化全部(书夹通常有界,可接受;若卡再优化)。**② Ctrl+滚轮裁剪封面**:封面 `<Image Stretch="UniformToFill">` 会「填满格子并裁掉溢出」,仅当「格子宽高比 == 图片真实比例」时不裁;resize/容器回收期 `FolderItem.PosterAspect` 可能暂不准 → 格子比例错 → 裁掉封面下半。**修**:[120] 封面 Image `UniformToFill`→`Uniform`(只缩放适配、**绝不裁**;比例对时与原来完全一样无边,比例暂不对时露极细深色边 `#1A1A1E` 而非裁内容)。**🚧 沙箱无 WPF,均待 Windows 实测**。若①仍截断,关键回报:墙右侧有无竖滚动条 / 滚轮(不按 Ctrl)能否带出下面更多书 —— 用以区分「无穷高 measure」与「extent 塌/实体化坏」等其它路径。


**问题**:mod19 海报墙固定等宽格子(每格 宽:高 = 1:1.42),双页/三页宽封面以 `Stretch=Uniform` 显示 → 贴宽缩小、上下大片留白=扁条夹在竖封面里难看;**单图封面也有左右黑边**——格子高宽比锁死 1.42 与封面真实比例对不上,露出深色底 `#1A1A1E`。用户否决「自动裁剪」(裁哪部分因书而异),最终方向 **A(justified 整齐瀑布流)**:封面按真实宽高比占不同宽度格子、统一高度、宽封面自然占宽、每排尽量填满、零裁剪零黑边。本条先落地「单图无缝去黑边 + 宽封面按比例横向占宽」的核心机制(精确「重排提图填满空位」的 packing 留作后续)。

**实现(新建 `_Mod/NvPosterWall.cs` 两类 + 改 3 处既有 text)**:
- `NvPosterWallPanel : VirtualizingWrapPanel, IItemSizeProvider`(命名空间 `NeeView`,XAML `local:`):**这些开关 `AllowDifferentSizedItems=true`/`StretchItems=false`/`SpacingMode=Uniform`/`ItemSizeProvider=this` 必须在「首次 `MeasureOverride`」里设、不能在构造函数设**——⚠ VWP 基类 `VirtualizingPanelBase` 的 `Items => ItemContainerGenerator.Items`、而 `ItemContainerGenerator` getter「在首次访问 `InternalChildren` 之前为 null、访问即抛 `InvalidOperationException`」;`AllowDifferentSizedItems` 的 changed-handler 会访问 `Items.Count`,故构造函数里设(面板尚未挂到 ListBox)**必崩**(2026-06-20 用户实测:启动恢复海报墙样式实例化此面板 → splash 阶段闪退、主界面没出来)。修法=ctor 只留 `RecomputeMetrics()`+`Loaded/Unloaded` 订阅,四个开关延后到 `EnsureConfigured()`(`_configured` 标志只设一次),由两处调用:① 首次 `MeasureOverride` 的 **`base.MeasureOverride` 之后**(基类已建好 generator),配置完 `InvalidateMeasure()` 请求重测、下一轮即用 provider;② `OnLoaded`(面板已连接)。**不在「measure 进行中、base 之前」设**——在自身 measure 中改 AffectsMeasure 属性会让本轮状态不一致、provider 不生效(2026-06-20 实测踩坑,首版如此 → 布局塌)。`EnsureConfigured` 内先 `_ = InternalChildren`(防御性,确保 generator 已建)再设开关。`GetSizeForItem(item)`:`aspect=FolderItem.PosterAspect>0?该值:0.70`,夹 `[0.35,3.0]`,返 `Size(H×aspect+12, H+nameArea+12)`(H=`round(PosterWallTileWidth×1.42)`、12=四周留白对应模板 DockPanel `Margin=6`)。H/nameArea **缓存为字段**(`RecomputeMetrics`),仅 Loaded/缩放/书名设置变化时重算 → provider 内只读字段+1 类型检查=O(1),12 万本逐项调用仍流畅;**绝不在 provider 里读 `Thumbnail.ImageSource`**(其 getter 触发异步加载)。Loaded 幂等订阅(先 `-=` 再 `+=`)`Config.Current.System.PropertyChanged`,监 `PosterWallTileWidth/NameAreaHeight/NameLines/ShowName` → `RecomputeMetrics`+`InvalidateMeasure`(缩放即重排;因 `ItemSize` 绑定已不能用,见下)。Unloaded 退订防泄漏。
- `PosterAspectWatcher`(static,附加属性 `Source` 类型 `ImageSource`):挂在封面元素上、绑 `{Binding Thumbnail.ImageSource}`。`OnSourceChanged`:`DataContext is FolderItem fi` + `fi.Thumbnail`(`IThumbnail`)`IsValid&&IsUniqueImage`(占位图标跳过)+ `e.NewValue is BitmapSource bs`(`PixelW/H>0`)→ `aspect=PixelW/PixelH` 夹 `[0.35,3.0]`,变了才写 `fi.PosterAspect` + 上溯找 `VirtualizingWrapPanel` 祖先 `InvalidateMeasure`。**只挂可见项、封面已由 ImageBrush 触发加载=无额外开销**。
- [120] `FolderListBox.xaml` 封面区:保留暗底占位 `<Border #FF1A1A1E CornerRadius=6/>`,把 `<Image … Stretch=Uniform Margin=3 …/>` 换成 **`<Image Stretch="UniformToFill">`**(`Source="{Binding Thumbnail.ImageSource}"` + `…Fant…` + `local:PosterAspectWatcher.Source="{Binding Thumbnail.ImageSource}"` + `Opacity=…`)。⚠ **必须用 `<Image>` 元素、不能用 `ImageBrush`/`<Border Background>`**:变尺寸 VWP 靠容器 DesiredSize 与 provider 尺寸匹配来定位/排列,`<Image>` 有源图固有尺寸(measure 时撑出容器尺寸)、ImageBrush 无固有尺寸→容器 DesiredSize 塌→封面塌成横条+行距错乱(2026-06-20 实测踩坑)。`UniformToFill`+格子按比例匹配=填满不裁不留黑(子像素失配只裁微丝、绝不 letterbox=安全网);`ImageSource` null 时透明露暗底=加载占位;图标/`PosterCap` 是 Grid 兄弟在上、不受影响。**圆角暂失**(Image 矩形;原 ImageBrush 版有圆角,待布局确认 OK 后用 clip/OpacityMask 给 Image 加回)。
- [121] `FolderListBox.xaml` 海报墙面板:`<vwp:VirtualizingWrapPanel … ItemSize="{Binding PosterWallItemSize}" SpacingMode="None" StretchItems="True"/>`→`<local:NvPosterWallPanel IsItemsHost="True"/>`(其余设置在 ctor)。
- [87] `FolderItem.cs`:`DisplayName` 块后(`ReadProgressText/IsReadFinished` 之后)追加 `public double PosterAspect { get; set; }`(简单 auto-property,0=未知用默认 0.70;provider 直读=快、watcher 写、靠 InvalidateMeasure 刷新故不需 PropertyChanged)。

**VWP v2.5.1 关键事实(逐一核对 `sbaeumlisberger/VirtualizingWrapPanel` tag v2.5.1 源码)**:① 设了 `ItemSizeProvider`,`GetUpfrontKnownItemSizeOrEmpty`/`GetItemSizeOrFallback` **直接调 `GetSizeForItem`、不走 itemSizesCache** → 改比例只需 `InvalidateMeasure` 即重排、无脏缓存;② **measure/arrange 子容器用 provider 尺寸**(`container.Measure(!upfrontKnownItemSize.IsEmpty ? upfrontKnownItemSize : InfiniteSize)`、arrange 同)→ DockPanel(ListBoxItem `HorizontalContentAlignment=Stretch`)撑满 provider 分配、封面 Grid 正好 coverW×H、ImageBrush 填满**不塌缩**;③ `if (!itemSize.IsEmpty) return itemSize` — **`ItemSize`(原绑定)非空会让 VWP 忽略 provider/AllowDifferentSizedItems** → 必须不设 `ItemSize`,故移除 [121] 的 `ItemSize` 绑定(`PosterWallItemSize` 定义[123]留着=死代码、不编译报错、不删〔删中间补丁会偏移索引〕;[122] 仍对它发通知=now no-op 无害);④ `StretchItems=True` 在变尺寸下给每项加等量宽度=横向变形 → 必须 `False`;⑤ `SpacingMode=Uniform` 把每排剩余空间均分成内/外间距=尽量填满每排(**末排会均匀摊开/居中**,想左对齐改 `None`)。

**事实核对(源码 verbatim)**:`IThumbnail` 接口直接有 `IsValid/IsUniqueImage/ImageSource`(不用 cast 到具体 `Thumbnail`);真封面 `ImageSource`=`DecodeFromImageData` 返回 frozen `BitmapImage`(=`BitmapSource`,有 `PixelWidth/Height`);占位图(Empty/Media/Folder/NoEntry)`IsUniqueImage=false`→watcher 跳过、保持默认竖比例;`FolderItem.Thumbnail` 是 `IThumbnail?`(3 子类 override);`PosterWallTileWidth` 在 `SystemConfig`(`SetProperty`=可观察,故面板 hook PropertyChanged 即得缩放通知)。

**沙箱验证**:纯净 `0ab0c48b0` `build.py --patch-only` **235/0 零失配**、`[新建] NvPosterWall.cs` 落盘 `./NeeView/_Mod/NvPosterWall.cs`、生成的 FolderListBox.xaml(283/284/393)+FolderItem.cs(172)改动正确;`NvPosterWall.cs` 状态机括号 ()/{}/[] 全 0;`_pack.py` 整包断言过(235 条/37 create)。🚧 **沙箱无 Windows/.NET/WPF 无法编译**,WPF 运行时/API 细节须 Windows 实测(见 §2 同日条四项)。

**后续(已记录未做)**:精确「重排提图填满空位」packing(用户早先 N=4 例:三图占1-3、单图填第4、双图去第二排);单/双/三页阈值;封面比例加载前预存(避免加载边跳——现默认 0.70 对单图基本不跳、宽图加载后 reflow 一下)。`SpacingMode=Uniform` 已「够用」近似填排,精确 reorder 看用户是否仍要。

### 21 · 末页页码显示(双页模式:跨页尾页 → 末页显示总页数)

用户反馈:双页(跨页)模式翻到最后,顶部标题和底部滑块页码显示 `145 / 146` 而非 `146 / 146`(怀疑作者 bug)。**实质**:NeeView「当前页号」取当前跨页的**前一页**(leading),双页末跨页 [145,146] 的 leading 是 145 → 显示 145/146。这是作者设计(滑块按 leading 定位)、非随机 bug,但确实让人以为"没到底"。

**做法(3 条 replace,纯显示、不碰导航/滑块拇指/翻页逻辑;补丁 150→153)**:让页码显示"当前跨页中页号最大的那页"(末跨页=总页数):
- **`TitleStringFormatter.GetPageWord`(标题 `{Page}`)**:`{Page}`(空后缀)改取 `source.Contents.Max(e => e.Page.IndexPlusOne)`(当前帧里页号最大者),只动 `{Page}` 这一个 token;`{NameL}/{NameR}/{Part}` 等带 L/R/1/2 后缀的不受影响(`GetContent` 未动)。
- **`PageSelector` 加 `SelectedIndexMax`**:= `BookOperation.Current.Control.SelectedRange.Max.Index`(夹在 `[_selectedIndex, MaxIndex]`),即当前显示范围的末页 index。
- **`PageSlider.SelectedIndexRaw` 的 getter**:从 `PageSelector.SelectedIndex`(leading)改成 `PageSelector.SelectedIndexMax`(尾页)。**关键安全点**:底部 `SliderTextBox` 的**数字**绑 `SelectedIndexRaw`,而**滑块拇指**(`SmartSlider`)绑的是另一属性 `SelectedIndex`——两者分开,所以只改 `SelectedIndexRaw` getter 仅改数字、拇指/导航完全不动;`SelectedIndexRaw` 的 setter(文本框输入页号跳转)不变;`SliderTextBox.ValueChanged` 只在用户提交输入时触发(翻页的程序性显示更新不触发),故不会因显示尾页而误跳页。`SelectedIndexRaw` 全工程仅此一处文本框使用(已核),改 getter 安全。

**效果**:单页模式不变;双页模式页码显示当前跨页的右(高)页号 → 首跨页 `2/146`、末跨页 `146/146`。**验证**:`build.py --patch-only` 干净 `4dbe593eb` 上 **153/0 零失配**;`PageSelector.cs` 大括号25/25·圆括号54/54、`PageSlider.cs` 35/35·58/58、`TitleStringFormatter.cs` 20/20·76/76 配平。⚠️ 待 Windows 实测:双页模式末跨页,标题与底部页码都显示 146/146(且滑块拖动、文本框输入跳页仍正常)。

### 魔改23:WebDAV / Alist 流式阅读(zip/cbz 真流式;pdf 后期)🚧 开发中

> **进度(2026-06-16)**:需求已定、可行性已实测、架构已定稿。**Stage A 引擎 + Stage B 接线 + Stage C 书架挂载/浏览/设置页均已交付**。Stage A=`_Mod/RemoteRangeStream.cs` + `_Mod/WebDavClient.cs`(已编译通过)。Stage B=`_Mod/NvDavZipArchive.cs`(流式 archiver + `NvDavRootEntry` 合成根条目 + dav:// URL 解析)+ 8 处 replace(路由 3 处 + 路径放行 5 处,详见下方「Stage B 已交付」)。**接通后地址栏粘 `dav://[user:pass@]host[:port]/path/x.zip` 即可流式打开**;待用户 Windows 编译实测。Stage C/D 见「分阶段」。
>
> **⚠️ 测试状态(务必照实读)**:Stage A 两个引擎文件**用户已 Windows 编译通过 ✅(2026-06-16)**。**Stage B(9 条)+ Stage C(7 条 + 细化补丁 C)沙箱已验证**:`build.py --patch-only` 在 `4dbe593eb` 与 HEAD `764fea1a7` **双基准均 173/0 零失配**、新文件生成、7 个被插入文件 + `NvDavZipArchive.cs` 括号全配平、9 个 replace anchor 对真实源码逐一**唯一命中**。但 **Stage B 尚未由用户编译、更未功能测试**——「粘 dav:// → 流式打开/出封面/翻页」还没在真实 115 链路跑过一次。**接手 AI 切记:沙箱零失配 ≠ 能编译、更 ≠ 逻辑正确**——块缓存、302/Range/过期重解析、dav:// 穿过 BookHub→QueryPath→ArchiveEntryUtility→ArchiveManager 全链都待 Windows 实测。

#### 1. 需求(用户原话提炼)
用户用 **Alist** 挂载了 **115 网盘**(本机 `http://127.0.0.1:5244`,WebDAV 根 `/dav/`,直链 `/d/…?sign=`)。要让 NeeView:
- 浏览并打开 115 上的漫画(`.zip`/`.cbz` 为主)与 `.pdf`;
- **流式阅读**:不把整包下载下来也能逐页看;
- **不下整包也能出封面**;
- PDF 流式**后期再单独改核心**,本期先把 zip 做成真流式(PDF 暂可"下载到缓存再打开");
- UI 由 AI 自行设计。

#### 2. 可行性(已用用户真实链接实测 ✅)
`curl -r 0-1023` 测 Alist `/d/` 链接:先 **302** 跳到 115 CDN(`*.115cdn.net`,后端 `Server: AliyunOSS`),CDN 返回 **`206 Partial Content`** + **`Accept-Ranges: bytes`** + **`Content-Range: bytes 0-1023/<总字节>`**(zip 实测 338565844 字节、pdf 234233929 字节均支持)。即**传输层完整支持 HTTP Range**,流式成立。三个已知事实写死在设计里:① 走 302、客户端要自己跟跳并在跳转后重发 Range(且 **不要把 Alist 的 Basic 认证泄露给 CDN**);② 115 CDN 直链带时间签名(`t=…`)**会过期**,取字节失败要**回 Alist 重解析新直链**;③ OSS 对随机分段/并发友好。

#### 3. 各格式结论
- **zip / cbz → 真流式(本期目标)**:NeeView 的 `ZipArchive` 底层是 .NET `System.IO.Compression.ZipArchive`,**唯一绑死本地文件的只是 `new FileStream(Path)` / `ZipFile.Open(Path)`**。把流换成"远程 Range 流",.NET ZipArchive 的 seek 式读取天然只取**尾部中央目录** + **被访问条目**的字节 → 出封面/翻页只下几十~几百 KB。
- **7z / rar → 不流式**:7-Zip(SevenZipSharp)远程随机读会拉很多(固实压缩尤甚),建议这类"下载后打开"。
- **pdf → 本期不流式**:NeeView 用 **PdfiumViewer**,加载是 `PdfDocument.Load(stream)`,而该库会**把整份 PDF 读进内存**——喂远程流等于下整本。要真流式得改用 Pdfium 的 `FPDF_LoadCustomDocument`(自定义读取回调),且只对"网页优化版"PDF 快;列为**后期单独任务**。

#### 4. 架构(分层 + 接入点,全部基于已读真实源码)
**引擎(新 `_Mod` 文件,纯/近纯 .NET)**
- `RemoteRangeStream : Stream`(✅已交付)——可随机定位的只读流,`CanSeek=true`、`Length` 已知、`Read` 按 256KB 块对齐缓存(LRU,默认 48 块)。取字节委托给 `IRangeFetcher`。
- `WebDavClient` + `WebDavRangeFetcher : IRangeFetcher`(✅已交付)——`PROPFIND`(Depth:1)列目录;`ResolveAndProbe` 发 `Range: bytes=0-0`、**不自动跳转**地解析直链并从 `Content-Range` 取总大小;`FetchRange` 对直链发 Range(自处理 302/auth);取字节失败清缓存**回 Alist 重解析一次**。只用 `System.Net.Http`/`System.Xml`,不引第三方。
- `NvDavZipArchive : Archive`(Stage B)——照搬现成 `ZipArchive`,把 `FileStream(Path)` 换成 `RemoteRangeStream`;实现抽象四法 `IsSupported / GetEntriesInnerAsync / OpenStreamInnerAsync / ExtractToFileInnerAsync`;持有一个 `System.IO.Compression.ZipArchive(remoteStream, Read, false, enc)` + `SemaphoreSlim` 串行化;条目用 `ZipArchiveEntryIdent`、`Id=索引`、目录用 `CreateDirectoryEntries`;`OpenStreamInnerAsync` 用 `_zip.Entries[entry.Id].Open()` 拷进 `MemoryStream` 返回。v1 编码先按 UTF8(`Config.Archive.Zip.Encoding=Auto` 时不跑 ZipAnalyzer,避免额外远程读),不调 `ReadZoneIdentifierAsync`(远程无 Zone.Id)。
**路由(小补丁,3 处,Stage B)**
- `Archiver/ArchiveType.cs`:枚举加一项(如 `NvDavArchive`)。
- `Archiver/ArchiveManager.cs::GetSupportedType`:在按扩展名判定**之前**拦一道——路径以自定义 scheme(拟用 `dav://`)开头则返回该类型(因为远程 zip 扩展名仍是 `.zip`,不拦会落到本地 `ZipArchive`)。
- `Archiver/ArchiveManager.cs::CreateArchive` 的 `switch` 加 `case NvDavArchive: archive = new NvDavZipArchive(path, source, hint);`。
**浏览(Stage C)**
- 自定义 `FolderCollection`(NeeView 书架按来源分多种 FolderCollection 子类),用 `WebDavClient.ListAsync` 列目录,接进书架地址栏/书架树。
- 封面**免费获得**:缩略图管线打开 archive 第一项 → `NvDavZipArchive.OpenStreamInnerAsync` → Range 只取那张图 → 出封面只下封面字节(契合"不下整包也出封面")。
**配置/UI(Stage C,自行设计)**
- 设置页新增「WebDAV / Alist」:服务器地址 + 账号 + 密码(明文存本地 JSON,同 mod01 密码池口径),可勾"加为书架位置";支持多服务器条目。地址栏可直接粘 `dav://…/x.zip` 打开单本(Stage B 的最小入口)。

#### 5. 关键风险与对策
- **115 直链过期/绑 IP**:`WebDavRangeFetcher` 取字节失败 → 清直链缓存、回 Alist `/dav` 重解析新直链重试一次(Alist 在本机,重解析快)。
- **115 对频繁小段随机请求可能限速**:256KB 块缓存 + 顺序翻页;块大小/缓存数后续按实测调。

---

## 📌 设计草案·待实现：dav 缓存扣改名（现按路径存 → 改按「内容身份」存）

> 用户 2026-06-20 提出、先记录晚点再做。下面是已理清的全部要点，接手 AI 可直接照这个设计干。

**目标**：dav 文件夹/文件在网盘（Alist/115）改名后，已缓存的封面 + 内容仍能命中（不重拉）。

**现状（代码事实，都已核）**：所有 dav 缓存 key = `Hash(dav 路径)`，路径含名字 → 改名即未命中。具体：封面 `covers/Hash(PathPart(davUrl)).<分辨率>.jpg`、内容块 `pages/Hash(PathPart(davUrl))/<块号>.blk`、目录树 `tree/Hash(serverPath).json`；每挂载隔离（`MountDir` 按 scheme+authority）；**无任何内容身份**（不存 115 文件 ID / sha1 / etag）。❗ 关键障碍：`WebDavEntry`（在 [155]）**只有 `Name/Path/IsDirectory/Length`——连 mtime 都没存**（PROPFIND 取了 `getlastmodified` 但解析器丢弃、`getetag` 根本没请求）；解析器在 [155] `ListAsync` 用 `XmlNode`/`SelectSingleNode`。所以任何身份都得先扩数据管道。

**身份候选（优先级）**：① **etag**（加 `<d:getetag/>` 到 PROPFIND；若 Alist 返回稳定/内容派生的 etag——**不确定，需用户实测**。Alist WebDAV 的 etag 常是 sha1 或 `modtime-size` 派生，两者都扣改名）> ② **size + "_" + mtime**（改名/移动都不变、现有数据几乎能凑出，但**有撞键风险**）> ③ 路径（回退=当前行为，零回归）。

**关键不对称**（决定设计）：
- **封面**显示时（浏览中）**不开档**、只有列目录拿到的 size+mtime → 封面 key 只能用 **size+mtime**。撞键=显示错封面（**纯美观、可接受、极少**）。
- **内容块**开档时**已拉首块**（读 zip 中央目录/pdf 结构本就要）→ 内容 key 可加 **首块 hash**或用 **etag**（内容派生、**不撞**）。⚠ **内容块撞键=读出乱码（严重）**，所以内容绝不能用裸 size+mtime，必须强身份（etag 或首块 hash）。如果只有 size+mtime、拿不到强身份，内容就**仍按路径存**（改名重拉、但不会乱码）。

**文件夹**：无可靠身份（etag/size/mtime 对 collection 不可靠）→ 保持路径 keying；但文件夹自动封面=夫内首本书封面，首书封面身份 keying → 改名后从缓存的书封面瞬间重建（不联网），所以文件夹**实际也扣改名**（只重列一次目录=一次便宜 PROPFIND）。

**实现面（大改、深）**：① PROPFIND 加 `<d:getetag/>`；② [155] 解析器补 parse `getlastmodified`+`getetag`；③ `WebDavEntry` 加 `LastModified`+`ETag` 字段（改构造）；④ 树缓存 `SaveTree`/`LoadTree` 序列化这两个字段（否则重启后拿不到身份=回退路径）；⑤ 内存 `ConcurrentDictionary<规范化davUrl, 身份>` 映射，列目录时（`ListAsync`+`LoadTree` 都有 size/mtime）填、缓存访问时查；⑥ [186] `CoverFile`/`BookDir`/`SaveCoverImage`/`LoadCoverImage`/`HasCover`/`ClearCover`/`GetBlockStore` + 调用方都改成用身份算 key（`davUrl` → 查映射 → 有身份用 `Hash(身份)`、无则 `Hash(PathPart)` 回退）。**优雅降级**：拿不到身份一律回退路径 key=零回归。注意顺序：列目录（填映射）必在封面访问之前发生（封面项本就来自列表），顺序天然成立。内容块开档时可直接从 HTTP 响应头/首块派生身份（不依赖映射）。

**风险/待定**：· etag 稳定性需用户实测（改名一个文件看缓存是否存活）；· 内容用弱身份会乱码→必用 etag 或首块 hash；· 改动深、面广（PROPFIND→解析→WebDavEntry→树序列化→身份映射→key 函数 + 全部调用方）；· 可分阶：先只做封面扣改名（size+mtime、低风险、价值最高），内容等 etag 实测可靠再上。

---

- **`Archive` 基类构造坑**:`source==null` 且路径非空时基类会对路径做 `FileInfo`,而 `dav://…` 会让 `FileInfo` 抛异常 → 接入时**构造带一个 source 入口**走另一分支跳过该检查,或在 `FileIO` 处加 scheme 守卫(Stage B 解决)。
- **zip 内文件名编码**:v1 先 UTF8(现代 CBZ 多为 UTF8;名称错了页仍能按 Id 开),后期再接 `Config.Archive.Zip.Encoding`。
- **`dav://` 路径穿过 NeeView 的路径校验/书加载链**(LoosePath/地址栏/历史)不被当"文件不存在"拒掉 → Stage B 需追 `BookHub`/书加载入口并按需放行。

#### 6. 分阶段交付计划
- **Stage A 引擎**:`RemoteRangeStream` + `WebDavClient` + `WebDavRangeFetcher`(✅均已交付)。纯 .NET,可单独编过、不影响现有功能。下一步进 Stage B 接线。
- **Stage B 打通(首个可测)**:`NvDavZipArchive` + 3 处路由补丁 + 路径放行 + 地址栏粘 `dav://…zip` 打开。验收:粘一条 115 的 zip 链接能开、能出封面、能翻页,且抓包确认只下了目录+所看页(非整包)。
- **Stage C 书架浏览**:WebDAV `FolderCollection` + 书架接入 + 封面 + 设置页/凭据 UI。验收:在书架里像本地盘一样逐级浏览 115、批量见封面、点开即读。
- **Stage D 打磨 + PDF**:过期/错误 UX、缓存调参、（可选)预取下一页;之后单独做 PDF 的 Pdfium 自定义读取回调。

#### 7. UI 设计(AI 定)
入口=**设置→新「WebDAV / Alist」页**管理服务器(地址/账号/密码/勾选"加入书架"),仿 mod17「阅读统计」页的 SettingPage 做法。挂上后该服务器作为**书架的一个根位置**出现,逐级浏览=原生书架体验(地址栏分段可点、缩略图网格、封面)。临时打开单本=地址栏直接粘 `dav://主机/路径/x.zip`。读取时底部状态栏可显示"流式:已取 X / 总 Y"(Stage D)。整体目标:**像浏览本地盘一样浏览 115,封面按需出、点开即流式读**。

#### 8. 源码调查已得结论(给接手 AI:写 Stage B 前**免重查** NeeView 源码)

> 本会话已把 Archiver 相关源码读透,结论钉在这里;下一个 AI(可能在新沙箱里重新 clone)**不必再翻一遍**,照此写 `NvDavZipArchive` + 3 路由补丁即可。涉及文件都标了真实路径。

- **`Archive` 抽象基类** `NeeView/Archiver/Archive.cs`:构造 `Archive(string path, ArchiveEntry? source, ArchiveHint archiveHint)`。子类**必须实现 4 个抽象法**:`public abstract bool IsSupported()`;`protected abstract Task<List<ArchiveEntry>> GetEntriesInnerAsync(bool decrypt, CancellationToken token)`;`protected abstract Task<Stream> OpenStreamInnerAsync(ArchiveEntry entry, bool decrypt, CancellationToken token)`;`protected abstract Task ExtractToFileInnerAsync(ArchiveEntry entry, string exportFileName, bool isOverwrite, CancellationToken token)`。可用工具:`protected List<ArchiveEntry> CreateDirectoryEntries(IEnumerable<ArchiveEntry> entries)`(从条目集合生成目录项)。**⚠️ 构造坑(最重要)**:当 `source == null && !string.IsNullOrEmpty(Path)` 时,基类构造会执行 `FileIO.CreateFileSystemInfo(Path)`(即 `new FileInfo/DirectoryInfo`),`dav://…` 这类 URL 会抛 `NotSupportedException`(路径格式不支持)。→ **接入时务必让 `NvDavZipArchive` 拿到一个非 null 的 `source` ArchiveEntry**(走 `source != null` 分支、从 source 取元数据、跳过 FileInfo 检查),或在 `FileIO` 加 scheme 守卫。`Length/CreationTime/LastWriteTime` 是 `private set`(子类改不了,由基类按 source 或文件填)。

- **现成 `ZipArchive`** `NeeView/Archiver/ZipArchive.cs`(**照它改 `NvDavZipArchive`**):
  - `GetEntriesInnerAsync`:`new FileStream(Path, Open, Read, Read)` → `CheckSignature(stream)`(读前 4 字节,需等于 `50-4B-03-04`)→ `GetEncoding(stream)` → `using var z = new System.IO.Compression.ZipArchive(stream, ZipArchiveMode.Read, false, enc)` → `for (int id=0; id<z.Entries.Count; id++)`:造 `new ArchiveEntry(this){ IsValid=true, Id=id, Instance=new ZipArchiveEntryIdent(e), RawEntryName=e.FullName, Length=e.Length, CreationTime=default, LastWriteTime=e.LastWriteTime.LocalDateTime }`,目录项 `Length=-1`,最后 `list.AddRange(CreateDirectoryEntries(list.Concat(directories)))`。
  - `OpenStreamInnerAsync`:`ZipFile.Open(Path, Read, enc)` → `archiver.FindEntry(entry)` → `rawEntry.Open()` → 拷进 `new MemoryStream()` 返回。
  - **唯一绑死本地的两处 = `new FileStream(Path)` 与 `ZipFile.Open(Path)`**。`NvDavZipArchive` 把它们换成:**持有一个** `System.IO.Compression.ZipArchive(remoteStream, ZipArchiveMode.Read, leaveOpen:false, enc)` + 一个 `SemaphoreSlim` 串行化(.NET ZipArchive 非线程安全),`OpenStreamInnerAsync` 在锁内用 `_zip.Entries[entry.Id].Open()`(`Id` 即遍历索引,免 `FindEntry`)拷 `MemoryStream`。`remoteStream = new RemoteRangeStream(client.CreateFetcher(path), length)`,`length` 由 `WebDavRangeFetcher.GetLength()` 给。v1 编码先 UTF8(`enc=null`),不跑 `ZipAnalyzer`(省远程读)、不调 `ReadZoneIdentifierAsync`(远程无 NTFS Zone.Id)。`Dispose` 里 dispose `_zip` 与 `remoteStream`。

- **路由** `NeeView/Archiver/ArchiveManager.cs`:`GetSupportedType(fileName, hint, ...)` 按**扩展名**判定(`_supportedFileTypes[type].Contains(ext)`,`.zip`→`ZipArchive`);`CreateArchive(ArchiverIdentifier id, path, source, hint)` 是 `switch (id.ArchiveType) { case ArchiveType.ZipArchive: archive = new ZipArchive(path, source, hint); break; … default: throw new NotSupportedFileTypeException(ext); }`。**Stage B 三处补丁**:① `Archiver/ArchiveType.cs` 枚举加一项(拟 `NvDavArchive`,带 `[AliasName("Archiver.NvDav")]` 之类);② `GetSupportedType` 在 ext 判定**之前**加:`fileName` 以 `dav://` 开头 → `return new ArchiverIdentifier(ArchiveType.NvDavArchive)`(否则远程 zip 因扩展名 `.zip` 会落到本地 `ZipArchive`);③ `CreateArchive` 的 switch 加 `case ArchiveType.NvDavArchive: archive = new NvDavZipArchive(path, source, hint); break;`。

- **`ArchiveType` 枚举** `NeeView/Archiver/ArchiveType.cs`:`None / FolderArchive / ZipArchive / SevenZipArchive / PdfArchive / SusieArchive / MediaArchive / PlaylistArchive`(各带 `[AliasName("Archiver.X")]`)。

- **`ArchiveEntry`** `NeeView/Archiver/ArchiveEntry.cs`:`ArchiveEntry(Archive archiver)` 构造;可写 `Id(int) / Instance(object?) / IsValid(bool) / RawEntryName(string) / Length(long) / Attributes(ArchiveEntryAttributes)`;`IsDirectory => Length == -1`;`enum ArchiveEntryAttributes { Duplicate = 1<<0, … }`。

- **`ZipArchiveEntryIdent`** `NeeView/Archiver/ZipArchiveEntryIdent.cs`:`ZipArchiveEntryIdent(ZipArchiveEntry entry)`(内部取 FullName/Length/LastWriteTime)。**`IsDirectory` 扩展** `NeeView/Archiver/ZipArchiveExtensions.cs`:`public static bool IsDirectory(this ZipArchiveEntry entry)`。

- **PDF 为何本期不流式** `NeeView/Archiver/PdfPdfiumArchive.cs`(及 `PdfWinRTArchive.cs`):用 **PdfiumViewer**,加载是 `PdfDocument.Load(stream)`,该库会把整份 PDF 读进内存 → 喂远程流 = 下整本。真流式要改 Pdfium 的 `FPDF_LoadCustomDocument`(自定义读取回调),且只对「网页优化版」PDF 快 → 列 Stage D 后期单独做。

- **✅ 已调查(原"尚未调查")= Stage B 已完成**:NeeView「一个路径怎么变成打开的书」这条链已读透。`dav://…zip` 从地址栏到流式打开的**完整闸点 + 放行方案**如下(均基于真实源码,anchor 在 4dbe593eb / HEAD 双基准唯一命中):
  - **`BookHub.RequestLoad`(BookHub/BookHub.cs)**:无 `File.Exists` 前置闸,但开头做 `new QueryPath(path).Normalize()` + `FileResolver.ResolveArchivePath` + `query.ResolvePath()`。其中 **`FileResolver.ResolveArchivePath` 对 dav:// 返回 null**(查不到→跳过该块,Release 安全;首行 `Debug.Assert(IsPathFullyQualified)` 仅 Debug 构建可能触发,用户编 Release 无碍)、**`ResolvePath()` 对 dav:// 走 shortcut 检查(`FileExists`=false)→ 原样返回**。
  - **致命闸 ①——`QueryPath`(SidePanels/Bookshelf/QueryPath.cs)**:dav:// 非已知 scheme → 当 File scheme。`GetValidatePath` 里 `LoosePath.NormalizeSeparator`=`Replace('/','\\')` 会把 `dav://host` 毁成 `dav:\\host`;`Normalize()` 里 `FileIO.GetNormalizedPath` 含 `Path.GetFullPath`,对 `dav:\\127.0.0.1:5244\\…` 的 `:5244` 冒号**抛异常**。→ **补丁 G**(GetValidatePath 顶部 `if (IsDavPath) return source;` 原样放行)+ **补丁 H**(Normalize 顶部 `if (IsDavPath(SimplePath)) return this;` 跳过)。此后 dav:// 作为 File-scheme 路径、值=完整 dav:// 串,`SimplePath`/`SimpleQuery` 原样保留。
  - **中心闸 ②——`ArchiveEntryUtility.CreateAsync`(Archiver/ArchiveEntryUtility.cs)**:`InitializeAsync` 先调它把路径变 rootEntry;dav:// 因 `EntryExists`/`FileExists` 全 false 落到末尾 `throw FileNotFoundException`。→ **补丁 F**(顶部 `if (IsDavPath) return new NvDavRootEntry(path);`)。`NvDavRootEntry`(在 NvDavZipArchive.cs)覆盖 `SystemPath=>davUrl`、`IsFileSystem=>false`、`IsArchive()=>true`、`Length=0`(非目录),于是 `ArchiveEntryCollection.InitializeAsync` 走 `else→if(IsArchive())` 分支 → `CreateArchiveAsync(rootEntry)`。
  - **致命闸 ③——`ArchiveManager.CreateArchiveAsync(ArchiveEntry source)`**:原生两分支都不行——`source.IsFileSystem==true` 走 `CreateArchive(path,null,…)`(source=null → 基类 `FileIO.CreateFileSystemInfo` 在 dav:// 上抛);`false` 则 **`ExtractAsync` 把条目解压成本地临时文件(=下整包,毁流式)**。→ **补丁 E**(在 IsFileSystem 检查**之前**加 dav:// 直通:`CreateArchive(new ArchiverIdentifier(NvDavArchive), targetPath, null, hint)`,**source=null + 不解压**)。
  - **基类闸——`Archive` 构造(Archiver/Archive.cs)**:`source==null && Path 非空` 的 else 分支执行 `FileIO.CreateFileSystemInfo(Path)`(`new DirectoryInfo/FileInfo`),dav:// 抛 `NotSupportedException`。→ **补丁 I**(else 分支里把 FileSystemInfo 块包进 `if (!IsDavPath(Path)) { … }`,只保留 `EntryName=GetFileName(Path)`)。配合补丁 E 传 source=null → `Parent==null` → **`IsRoot=true`**(远程 zip 是根档)。
  - **路由——`ArchiveType.cs` / `ArchiveManager.GetSupportedType`+`CreateArchive`**:**补丁 B**(枚举加 `NvDavArchive`,**不带 `[AliasName]`**:`ToAliasName` 缺映射回退枚举名,避免缺 restext 资源)+ **补丁 C**(`GetSupportedType` null 检查后插 `if (IsDavPath(fileName)) return new ArchiverIdentifier(NvDavArchive);`,在扩展名判定之前,否则远程 `.zip` 落到本地 ZipArchive)+ **补丁 D**(`CreateArchive` switch 加 `case NvDavArchive: archive = new NvDavZipArchive(path, source, hint);`)。
  - **流式核心——`NvDavZipArchive : Archive`(_Mod/NvDavZipArchive.cs)**:照搬 ZipArchive,持**一个**懒打开的 `System.IO.Compression.ZipArchive(RemoteRangeStream, Read, leaveOpen:false, null/*UTF8*/)` + `AsyncLock` 串行化;`EnsureOpen` 里 `new WebDavClient(origin,user,pass)` → `new WebDavRangeFetcher(client, client.BuildUrl(serverPath)).GetLength()` → `new RemoteRangeStream(fetcher, len)`;`GetEntriesInnerAsync` 枚举(`ZipArchiveEntryIdent`、`Id=索引`、目录走 `CreateDirectoryEntries`、重名 `ArchiveEntryAttributes.Duplicate`,**无 ZipAnalyzer / 无 ReadZoneIdentifier**);`OpenStreamInnerAsync` 锁内 `_zip.Entries[entry.Id].Open()` 拷 `MemoryStream`;`Dispose` 释放 `_zip`(leaveOpen:false 级联 `_stream`)。`NvDavSupport.Parse` 解析 `dav://[user:pass@]host[:port]/path`(dav→http、davs→https,路径 `Uri.UnescapeDataString` 后交 `BuildUrl` 逐段重编码)。
  - **dav:// 打开闭环**:粘 `dav://[user:pass@]host:port/path/x.zip` → QueryPath(G/H 原样保留)→ RequestLoad → ArchiveEntryCollection → CreateAsync(F 返回 NvDavRootEntry)→ InitializeAsync 走 `CreateArchiveAsync(rootEntry)` →(E)dav:// 直通 → `CreateArchive(NvDavArchive, davUrl, null, hint)` →(I)基类跳 FileInfo + IsRoot=true →(D)switch → `NvDavZipArchive` → 解析 dav:// → WebDavClient → RemoteRangeStream → **流式**。封面=缩略图管线打开第一项 → `OpenStreamInnerAsync` → Range 只取那张图。
- **已知 v1 限制 / 待实测项**:① `NvDavRootEntry.Length=0` 占位(不影响打开;若有"空文件跳过"启发式再于 Stage D 改成探测真实大小);② 编码先 UTF8(非 UTF8 zip 文件名可能乱码,Stage D 加 `ZipAnalyzer` 远程探测);③ `WebDavClient` 未实现 `IDisposable`,每开一本 archive 漏一个 `HttpClient`(单本测试无碍;长会话多本累积 → Stage D 让其可释放);④ Debug 构建下 `FileResolver.ResolveArchivePath` 的 `Debug.Assert(IsPathFullyQualified)` 可能对 dav:// 触发(用户编 Release 无碍);⑤ **history/bookmark 对 dav:// 未测**(mod18 只记 F11 全屏单文件,dav:// 单本可能写历史 → BookMementoControl 的路径操作未验);⑥ 嵌套压缩包(远程 zip 内再套 zip)未优化(会走 ExtractAsync 解压);⑦ PDF 仍不流式(本期 zip/cbz)。
- **【当前状态汇总(2026-06-19)——以下取代原逐次「Stage 交付 / 各 dav 修复」长篇;完整逐条改法见 §2「近期变更历史」对应日期 + 代码注释 + `git`】**

  **当前能力**:经 Alist(挂 115 网盘)对远程压缩包/PDF **真流式**阅读(HTTP Range,不下整包即出封面/逐页翻)——
  - **zip/cbz**:原生 `NvDavZipArchive`(照搬上游 `ZipArchive`,把 `FileStream`/`ZipFile.Open` 换成挂在 `RemoteRangeStream` 上的远程流);明文 + 加密(复用 mod01 密码池)都支持。
  - **rar/cbr**:`NvDavRarArchive` 用 **SharpCompress 0.48.1**(纯 C#、本项目唯一 NuGet 依赖,`NeeView.csproj` 引);非固实可流式,**固实(solid)RAR 明确拒绝**(`EnsureOpen` 检 `IsSolid`);加密 rar 也支持。
  - **pdf**:`NvDavPdfiumArchive` 直接 P/Invoke `pdfium.dll`(`FPDF_GetPageCount` 只读页树、逐页 `FPDF_GetPageSizeByIndex`、按需 `FPDF_LoadPage`/`RenderPageBitmap`),与本地 PDF 共用 `string.Intern(GUID)` 全局锁串行(PDFium 非线程安全)。
  - **离线缓存(C2/C3)**:`NvDavCache` 持久化「目录结构 + 封面」(封面在 `WebDavCache/covers/`、按分辨率分文件 `<hash>.<res>.jpg`);`RemoteRangeStream` 的 256KB 页块走**每挂载独立的持久磁盘缓存**(C3,看过的页落盘跨重启)→ **Alist 离线/115 风控时能离线翻看过的页**;每挂载上限默认 **5GB**(256MB–200GB,按 `dav://host:port` 持久化)、超限 **LRU 自动淘汰**。
  - **dav 文件夹/书封面**:支持自定义封面(右键→下钻选页/裁剪,详见 mod24)、预缓存原图封面(2048 高清 / 512 小图按分辨率隔离)、dav 目录项 `NvDavDirFolderItem` 命中缓存即显。
  - **dav 书纳入 进度%/已读完/统计**:身份用服务器字节 `NvDavCache.LoadCachedLength`(与本地同套 (名,size) 口径),面板封面回退 `DavThumb`。
  - **其它**:dav 重命名(右键→改 Alist/115 真实名)、dav 独立右键菜单(WebDAV 设置里按挂载各编一套)、文件夹右键「清除缓存」(清夹内所有文件封面+内容块、先关开着的书、递归子目录、清后刷新书架);**dav 书架搜索框**(原灰=基类 `IsSearchEnabled` false;`WebDavFolderCollection` 覆写 `IsSearchEnabled=>true` + `BuildItems` 按 `Place.Search` 客户端过滤「当前文件夹已列出项」、搜索时跳过后台刷新 → 零额外网络/不递归/防风控;`FolderCollectionFactory` 的 dav 分支拦在递归搜索引擎之前,故永不触发引擎递归搜);**dav 单击只选中·双击才进文件夹/开书**(`ClickToLoadBook` 对 dav 提前 return、`FolderListItem_MouseDoubleClick` 让 dav 经 `LoadBook` 不论全局「双击打开」开关、并跳过 `MoveToSafety` 避免目录双重导航;本地行为不变)。
  - **直链不支持 Range 兜底(2026-06-19)**:个别文件的 Alist/115 直链会**忽略 Range、对非零偏移回 200 整包**(=旧版"大文件 End of Central Directory record could not be found"的真因——`ZipArchive` 读尾部中央目录,`FetchRange` 却把文件**开头**当成目标段返回)。现 `WebDavClient.FetchRange` 区分 206/200:非零偏移收到 200 即判直链不支持 Range → 抛 `RangeNotSupportedException`,`RemoteRangeStream` 改走 `DownloadAll` **整文件下载一次、逐块写满该书磁盘块缓存**(每挂载 5GB 上限内,684MB 远未触顶、跨重启复用),之后 EOCD/中央目录/翻页全本地命中。206 直链的逐块流式快路径完全不变。

  **关键设置(设置→「WebDAV/Alist」)**:加挂载(名称 / host:port / WebDAV 根默认 `/dav` / 账号密码)、测试连接、按挂载「格式」白名单(缺省 `zip,cbz,pdf`,要 rar/cbr 须手动加;白名单外远程文件从源头不显示/不取 115 直链以降风控)、按挂载「内容缓存」上限滑块+占用+清除、「清除封面」(单挂载:删封面 + 复位该挂载 2048 标记)。书架地址栏根下拉 / 「此电脑」可见挂载、与本地盘符同列浏览;也可地址栏直接粘 `dav://[user:pass@]host:port/path/x.zip` 流式打开。

  **关键文件**(create 在 `_Mod/`;逐文件归属另见 §1 表格 mod23 行):引擎 `WebDavClient.cs` / `RemoteRangeStream.cs`;格式 `NvDavZipArchive.cs` / `NvDavRarArchive.cs` / `NvDavPdfiumArchive.cs`;缓存与封面 `NvDavCache.cs` / `HiResCoverStore.cs`(后者与 mod20/24 共用);挂载与浏览 `NvDavMountStore.cs` / `WebDavFolderCollection.cs`;设置页 `SettingPageWebDav.cs`;右键菜单 `BookshelfMenuDavDefault.cs`;重命名 `DavRename.cs`。**接线(replace 改上游)**:路由 `ArchiveManager.cs` / `ArchiveType.cs`、开书闸 `QueryPath.cs` / `ArchiveEntryUtility.cs` / `ArchiveEntryCollection.cs`、`NeeView.csproj`(SharpCompress)、进度/统计/已读完 `ReadProgressStore.cs` / `ReadingStatsStore.cs` / `ReadFinishedView.cs` / `StatisticsView.cs`、`FolderListBox.xaml` 等。

  **已知局限 / 未做**:① 固实 RAR 不流式(拒绝);② RAR 错误密码检测不可靠(弱口令自动试可能不稳、手动框兜底;zip 可靠抛 `CryptographicException`);③ dav PDF 暂无 TOC/书签(写死 cast);④ 内容缓存目前**每本各自一份内存+磁盘块缓存、关书释放**,跨书全局 LRU + 内存不足落 temp **暂未做**;⑤ `NvDavRootEntry.Length=0` 占位(不影响打开)。

  **交付历史(一句话)**:Stage A 引擎(`RemoteRangeStream`/`WebDavClient`,用户已编译通过)→ Stage B 接线(zip 流式打开)→ Stage C 书架挂载/浏览/设置页/根下拉/测试连接 → C2 离线目录+封面缓存 → C3 持久内容缓存(✅ 用户实测成功)→ 此后多轮 dav 体验修复(Issue A/B/C、方案A 正反斜杠、自定义封面系列、格式白名单、流式 RAR/CBR、加密 RAR/ZIP、dav 进度·已读完·统计、重命名、独立右键菜单、防风控等);各次均沙箱(新旧双基准)零失配,大部分已 Windows 实测,逐次见 §2「近期变更历史」。
### 魔改24:自定义封面(右键文件夹/单本书 → 弹窗下钻选页设封面)🚧 已交付待实测

**需求**:右键书架里的文件夹或单本书 →「自定义封面」→ 弹窗。① 若是**书**:直接把这本书所有页以缩略图铺开,点一张 →「设为封面」;② 若是**文件夹**:列出夹内子文件夹/书(双击进入),逐级下钻直到进入一本具体漫画,再以缩略图铺开它所有页,选一张作为这个文件夹的封面。最终被右键项在书架显示选中的图。

**关键洞察——NeeView 已有完整「封面覆盖」体系,本功能只补一个选图弹窗**:
- **持久化**:`FolderConfig`(`FolderConfig/FolderConfig.cs`)有 `Thumbs: Dictionary<string,string>`(子项名→缩略图 target 路径)。入口 `FolderConfigTools.SetThumbnailTarget(string bookPath, string? thumb)`:`place=GetDirectoryName(bookPath)`、`name=bookPath-place`,存 `FolderConfigCollection.Current.SetThumbnail(place,name,thumb)`(发 `FolderChanged` 事件、无需手动 Save)。**对文件夹与书都适用**(name 是父目录下任意子项名)。
- **渲染**:`ArchivePageUtility.SelectAlternativeEntry`(`Page/ArchivePageUtility.cs` L31-55):对目录或书先 `FolderConfigTools.GetThumbnailTarget(entry.EntryFullName)`,有则 `ArchiveEntryUtility.CreateAsync(target,...)` 用作封面,否则取首图。**对文件夹与书都生效**。
- **target 格式**=`ArchiveEntry.EntryFullName`(= `LoosePath.Combine(Archive.SystemPath, EntryName)`,如 `C:\…\book.zip\inner\page.jpg`),与既有「将当前页设为缩略图」命令(`FolderListBox.xaml.cs` L618,用当前打开书的当前页 `page.EntryFullName`)存的同源。**本功能 = 去掉「必须先打开书翻到那页」的笨重前提**。

**实现(1 create + 9 wiring,仿 mod20 PrecacheFolder 模板)**:
- **`_Mod/CustomCoverPicker.cs`(create,312 行,纯代码 WPF 窗口无单独 XAML)**:两个类。`CustomCoverItem : INotifyPropertyChanged`(Entry/IsContainer/`FullPath`=EntryFullName/DisplayName/FolderVisibility/可绑 `Image`)。`CustomCoverPickerWindow : Window`:DockPanel(顶=「返回上级」按钮+路径;底=状态+取消/「设为封面」;中=WrapPanel ListBox 缩略图网格,`ItemsPanel`/`ItemTemplate` 用 `XamlReader.Parse` 内嵌 XAML 串)。导航栈下钻:`ReloadAsync` 用 `new ArchiveEntryCollection(path, ArchiveEntryCollectionMode.CurrentDirectory, CurrentDirectory, ArchiveEntryCollectionOption.None, ArchiveHint.None).GetEntriesAsync(false, token)` 列当前层 → 分**容器**(`IsDirectory||IsBook()||IsArchive()||IsArchiveDirectory()`,双击进入,显 Segoe MDL2 文件夹 glyph `&#xE8B7;`)与**页面**(`IsImage(false) && !IsMedia()`,逐张异步 `OpenEntryAsync`→MemoryStream→BitmapImage `DecodePixelWidth=220`→Freeze,可被导航 cts 取消、顺序解码避并发开包不安全)。双击容器→下钻;双击页面/选页+「设为封面」→`SelectedTarget=entry.EntryFullName`、`DialogResult=true` 关窗。`TextResources.GetString` 取 UI 串(**需 `using NeeView.Properties;`**,TextResources 是 `internal class`、同程序集可见)。
- **`FolderListBox.xaml.cs`×4**:`CustomCoverCommand` RoutedCommand(L161)+ binding(L198)+ `CustomCoverCommand_Execute`(L661:取选中 FolderItem,`var path=item.TargetPath.SimplePath; new CustomCoverPickerWindow(path,path){Owner=MainWindow.Current}`,`ShowDialog()==true && SelectedTarget!=null` → `FolderConfigTools.SetThumbnailTarget(path, SelectedTarget)` + `item.ClearThumbnailCache()` + `_thumbnailLoader?.Load(true)`,**仿既有 SetThumbnailCommand_Execute 的刷新**)+ `case "CustomCover"`(L824:门控 `item.CanThumbnail()`=`!IsEmpty&&!IsDrive&&!IsBookmark`,**文件夹与单本书都显示**,区别于 Precache 的 IsDirectory-only)。
- **`_Mod/BookshelfMenuCommandTable.cs`**:加 `new("CustomCover","CustomCover.Menu",false)`。**`_Mod/BookshelfMenuDefault.cs`**:默认菜单加 `BookshelfMenuItem.Command("CustomCover")`。**`Config/BookshelfConfig.cs`**:`ContextMenuItems` getter 加迁移(历史持久化菜单缺 CustomCover 则 `Add` 到末尾、幂等;锚在 mod20 PrecacheFolder 迁移块尾,故该 getter 现注入 PrecacheFolder + CustomCover 两项)。**zh-Hans/en restext**:CustomCover.Menu/Title/Up/OK/Cancel/Loading/Empty/PickHint(含 `{0}`=页数)/BrowseHint。

**这些 mod24 补丁全部追加在 PATCHES 末尾、最后应用**,故 wiring 的 anchor 都打在 mod20 PrecacheFolder 的输出文本上(RoutedCommand/binding/execute 尾/case/命令表行/默认菜单行/迁移块尾),改最终产物即改「最后发出者」=这些新补丁本身。

**验证**:沙箱 `build.py --patch-only` 双基准(`4dbe593eb` / `764fea1a7`)**185/0 零失配**;`FolderListBox.xaml.cs`/`BookshelfConfig.cs`/`BookshelfMenuCommandTable.cs`/`BookshelfMenuDefault.cs`/`CustomCoverPicker.cs` 打补丁后括号全配平;新引用 API(`ArchiveEntryCollection` 5 参 ctor `Archiver/ArchiveEntryCollection.cs` L29 / `GetEntriesAsync` L47 / `ArchiveEntryNode.ArchiveEntry` / `ArchiveEntry.EntryFullName` L134·`IsImage` L478·`IsMedia` L471·`IsBook` L434·`IsArchive` L448·`IsArchiveDirectory` L461·`OpenEntryAsync` L319 / `ArchiveHint.None` `Archiver/ArchiveHint.cs` L10 / `FolderConfigTools.SetThumbnailTarget` / `LoosePath.GetFileName` `Archiver/LoosePath.cs` L85 / `FolderItem.CanThumbnail` L333·`ClearThumbnailCache` / `MainWindow.Current` / `ToastService.Current.Show`/`Toast`/`ToastIcon.Error` / `_thumbnailLoader.Load(bool)`)逐一对 HEAD 核实存在。

**待用户编译实测**:① 右键一本书→自定义封面→缩略图选一页→书架封面变为该页;② 右键一个文件夹→弹窗里双击下钻进某本书→选一页→该文件夹封面变。**纯代码 WPF 窗口 + 异步解码、沙箱不能编译,可能需 1-2 次编译修复**。**dav(115)项**:理论上 `ArchiveEntryCollection`+`OpenEntryAsync` 对 dav **书**可能直接可用(未专门测);但 dav **文件夹**枚举或受 mod23「对目录 GET→405」影响,本期不保证,以本地为主。

**后续完善与修复(2026-06-17 起;均已实现,完整逐条改法见代码注释 + §2「近期变更历史」;✅=已实测、🚧=待测)** —— 多数只改 `_Mod/CustomCoverPicker.cs` 内容、不增条:

- **选图窗视觉(第二轮 2026-06-17 🚧)**:套暗色窗体样式 `SetResourceReference(StyleProperty,"ChromeDialogStyle")` + 主题画刷/原生按钮;修「右侧大片空白」= `ScrollViewer.SetCanContentScroll(_listBox,false)` + `HorizontalScrollBarVisibility=Disabled`(WrapPanel 作 ItemsPanel 必须按像素滚动,否则列数算错只铺几列);去底部黄字提示;容器条目显其代表封面(`ResolveCoverEntryAsync` 镜像 `ArchivePageUtility.SelectAlternativeEntry`)+ 左上文件夹角标;**随老板键隐藏/恢复**(订阅 `AppState.Current.PropertyChanged`)。
- **选择器看不到 dav 子目录自定义封面修(2026-06-18 ✅)**:`ReloadAsync` 缩略图循环里原 `if(item.IsDavDirectory) continue;` 把 dav 目录无条件跳过、没查缓存;改为把 `NvDavCache.LoadCoverImage(item.FullPath)` 命中检查**统一提到 continue 之前**(覆盖 dav 目录 + dav 压缩包),命中即显、零网络(修「书架能看到、选择器看不到」)。
- **选择器四连(2026-06-18 🚧)**:① 排序按阅读顺序——页面改按 `x.FullPath`(含子文件夹名)用 `NaturalSort.Comparer`(修铺平多文件夹 zip 的「001 001 002 002」乱序);② 选中容器(文件夹/书)直接用其封面 = `UpdateOkState` 增 `containerWithCover`、`Confirm()` 加容器分支 `SelectedCoverImage=item.Image`、命令端 dav 走 `SaveCoverImage` 复制封面(本轮**撤销**了误做的「列散图」功能);③ 去两个编译 warning(`BookshelfPrecacheRunner.cs:266` CS4014 加 `_ =`、`SettingPageWebDav.cs:166` CS8602 改 `Items!.Add`);④ 答「开书卡一下」= dav 首开网络往返固有延迟、非 bug(加载在后台线程、加密探测净增≈0、缓存后流畅)。
- **裁剪/自定义封面落盘改无损 PNG(2026-06-19 ✅,改 `NvDavCache.cs` + mod24 那条 `FolderListBox.xaml.cs`)**:`NvDavCache` 加 `EncodePng`/`SaveCoverImagePng`,`CustomCoverCommand_Execute` 落盘从 q95 JPEG 换 PNG,消除 JPEG 在水彩/网点高频肌理上的色块伪影。**设计**:文件名仍 `<hash>.<res>.jpg` 而内容是 PNG 字节——`LoadCoverImage` 用 `BitmapImage`+`StreamSource` 按**字节头 magic** 识别编码、与扩展名无关,故 `ClearCover`/`HasCover` 等按通配照常命中;**仅自定义封面/裁剪走 PNG**(数量少),预缓存/自动封面仍 q88 JPEG 控体积。
- **悬浮预览 Fant 缩放(2026-06-19,220→221,新增 1 条 replace `NeeView\Controls\HoverPreviewService.cs`)✅**:才是「悬浮比海报墙更糊/有色斑」的真正修复(纯缩放不能解释「小图反而更糊」)。**根因**:书架悬浮大预览的 `<Image>`(`Generic.xaml` 68/104/139 行,经 `HoverPreview.Content`)**未设 `RenderOptions.BitmapScalingMode`** → WPF 默认线性/盒式下采样对高频肌理产生混叠(色斑)+ 发糊、图越小越重;海报墙(`FolderListBox.xaml` 262 行)用 `Fant`、格子用 `HighQuality` 故干净。**修**:`HoverPreviewService.Show()` 的 `_content.Content = content;` 前插 `if (content is Image hoverImage) RenderOptions.SetBitmapScalingMode(hoverImage, BitmapScalingMode.Fant);`（单点全覆盖书架/播放列表/页列表;改 `Service.cs` 而非 `Generic.xaml` 三处，因 `BitmapScalingMode` 非继承属性）。与 PNG 正交(PNG 去落盘重编码伪影、Fant 去悬浮下采样混叠,各修一层)。
- **预缓存原图放大到 2048 + 清缓存修两 bug + q95 落盘(2026-06-18 六续,🚧;实现锚点级,改代码按此定位)**:① **放大 2048** = mod20 `ThumbnailProfile.GetThumbnailSize`(**PATCHES[139]**)把防放大钳制改 `if (scale>1.0 && (overrideRes??0)<1024) scale=1.0;`——「预缓存原图封面」走 `Run(path,2048)` → override=2048 → 不钳 → 小图也插值撑满 2048²;512/普通档仍钳制不放糊(总闸 = `PageThumbnail.LoadAsync` 生成期设/复原 `OverrideResolution`)。⚠ 放大是插值、不增真实细节。② **清缓存修两 bug** = mod23 **PATCHES[193]** `ClearDavCacheCommand_Execute`:(a) 清前若 `BookHub.Current.Address` 命中该目录则 `RequestUnload(this,true)` 先关开着的书(否则持续预读把刚清的写回);(b) `BookshelfPrecacheRunner.CollectDavRecursiveAsync` 加 `folders` 形参收子目录 URL 一并清(修内层子文件夹封面残留)+ 清后 `foreach FolderItem.ClearThumbnailCache()` 刷新可见 dav 封面。③ **q95 落盘** = mod24 **PATCHES[179]** 自定义封面分支传 95,编码链 `EncodeJpeg`/`SaveCoverFrom`/`SaveCoverImage` 全加 `quality` 形参默认 88(预缓存/自动封面仍 q88,仅自定义封面 95)。**⚠ 编辑提示**:`patches.py` 里 **PATCHES[193] 用双引号、PATCHES[179] 用单引号定界**——改它们的 text 须按各自引号 serialize(或用 §6 的 ast-span 技术)。

## 5. NeeView 出新版后怎么办(更新 / rebase)

### 5.0 ★ 接手 AI:如何判断源码是否已更新(开工第一件事)

> **§2 的「补丁基于的 commit」是唯一基准锚。** 它记录的就是**用户本地 `D:\000\NeeView` 当前所在的 commit**(每次 `--pull` 更新后由 AI 同步更新到 §2)。判断"上游有没有新版""用户源码是不是最新",全靠拿这个锚去比。

你(接手 AI,通常在 Linux 沙箱里,会自己 `git clone` 一份干净源码来读)按下面三步判断:

**第 1 步 · 拿到三个 commit**
```bash
# A) 文档基准(= 用户本地当前所在 commit):读 §2「补丁基于的 commit」,当前是 764fea1a7
# B) 你 clone 下来的上游最新 HEAD:
git -C <你的clone> rev-parse --short HEAD
# 注:浅克隆(--depth 1)只有最新一条;要比对中间提交需先 git fetch --unshallow
```

**第 2 步 · 判断有没有更新**
```bash
# 上游是否已超过文档基准?(BASE = §2 那个 commit)
git merge-base --is-ancestor <BASE> HEAD && echo "上游=基准或更新" || echo "情况特殊(分支分叉/基准更新)"
# 列出基准→最新之间到底多了哪些提交(空=没更新;有行=上游有新版)
git log --oneline <BASE>..HEAD
```
- **输出为空** → 源码**没更新**,用户本地已是最新,直接在当前基准上干活即可。
- **输出有提交** → 上游**有新版**,进入第 3 步评估影响。

**第 3 步 · 评估更新对补丁的影响(决定要不要提示用户 `--pull`)**
```bash
# 上游新提交改了哪些文件
git diff --name-only <BASE>..HEAD | sort -u
```
把这个文件清单和**补丁涉及的那些文件**(数量见 `python build.py` 启动概览末行『合计 N 条补丁 · M 个文件』,或解析 `patches.py` 提取;当前约 100 个文件)取交集:
- **无交集** → 补丁绝对不受影响,放心让用户 `python build.py --pull`。
- **有交集** → 重点看交集那几个文件:`git diff <BASE>..HEAD -- <文件>` 看上游改的位置是否动到补丁的 anchor/语义。多半不冲突(补丁是定位锚点插入,上游常在别处加东西);若可能冲突,按 §5.1 全面核查。

> **一句话**:`git log --oneline <§2基准>..HEAD` 一跑便知有没有更新;`git diff --name-only <§2基准>..HEAD` 跟补丁涉及的文件清单(数量见 `build.py` 概览末行)取交集便知影响面。**这就是判断"源码是否更新"的标准动作。**
>
> **更新完别忘**:真的执行了 `--pull` 把用户源码推进到新 commit 后,**务必把 §2 的「补丁基于的 commit」改成新的那个**(并在 §2.x 追加一条核查记录),否则下一个 AT 的基准锚就过期了。(本项目已发生两次:6464291 → 8200c60 见 §2.1、8200c60 → 3b62b9c9f 见 §2.2。)
>
> **★ 同步沙箱环境(接手 AI 必做 · 2026-06-08 立规)**:如果用户**在对话过程中途**执行了 `build.py --pull`(或手动 `git pull`)把本地源码推进到新 commit,接手 AI **必须立刻把自己沙箱里的源码也同步到同一个 commit**,再继续干活:`git -C <clone> fetch origin` → 把主克隆和**所有验证用的 worktree**(本项目是 `wt_head`,还有对照用的 `wt_base`)都 `checkout` 到那个新 commit(worktree 先 `git checkout -- . && git clean -fdq` 清干净再 checkout)→ 在新基准上重跑 `build.py --patch-only --src <wt_head>` 确认仍零失配。**否则你验证补丁用的源码和用户实际编译的源码不是同一个版本,锚点/接口的核对结果就不可信,可能给出在用户那边打不上、或语义错位的补丁。** 同步完照上一条更新 §2 基准 + 追加 §2.x 核查记录。(本项目已发生一次:2026-06-08 用户 `build.py --pull` 到 `f2e269702`,AI 随即把沙箱 `NeeView` / `wt_head` / `wt_base` 全部同步到 `f2e269702`、在新基准重验「新打 113、跳过 0」零失配,见 §2.5。)

---

**一条命令搞定**:在源码目录跑 `python build.py --pull`。它会自动:还原成干净原版 → `git pull` 拉上游新版 → 重新打补丁 → 编译。
- **锚点还在** → 自动打好。✅
- **某处锚点变了** → 脚本**明确报出是哪一处**;照 §4 的「机制要点」在新版对应位置把逻辑放回去(改 `patches.py` 的锚点),再跑一次即可。

> 原理:魔改存在 `patches.py` 里,源码每次被自动还原成干净基线,所以 `git pull` 永远顺畅、魔改也不会丢。**唯一要珍藏的是 `patches.py`(和 build.py);源码丢了能 clone,patches.py 没备份才麻烦。**

**稳定性数据**(生成补丁时统计,最近 200 次提交 / 约 5 个月):涉及的核心文件改动极少(多为 1–3 次)——**绝大多数更新,补丁能原样自动打上**。

> ⚠️ 另注意:别让 NeeView 自带的更新器(若有)用官方包覆盖你的自编版,否则魔改会被抹掉。正确姿势:新版出来 → `python build.py --pull` 重新生成魔改版。

### 5.1 更新上游后 · 接手 AI 必做的全面冲突核查(重要)

**`git pull` 之后,补丁"能打上"不等于"还正确"。** 上游可能改了某段逻辑的语义、字段默认值、调用时机或周边代码,导致补丁虽然 anchor 还在、能打进去,但**行为已经不对或会编译失败**。所以每次更新上游后,接手 AI **必须主动逐项核查全部魔改**,不能打完补丁就交差。检查清单:

1. **先看 build.py 的报告**:有没有 `[锚点失配]`?有 → 按 §4 该条「机制要点」把逻辑放到新位置(改 `patches.py` 的 anchor),直到全部能打上。
2. **逐条比对 anchor 上下文有没有"语义漂移"**:对每条 replace 补丁,去新版源码看 anchor 周围的代码——上游是否改了这段的逻辑、变量名、调用顺序?anchor 没变但**周围语义变了**时,补丁可能插错位置。重点复查这几条"逻辑型"补丁:
   - **01 密码池**(`ArchiveKey.cs` 的取密码流程、`ArchiveConfig.cs`):上游若重构了密码/解密流程,要确认插入点仍在"要手动输密码之前"。
   - **02 封面预生成**(`ListBoxThumbnailLoader.cs` 的 `Load()`):确认上游没改 `CollectPageList` / `PageCollectionListBox.Items` 的语义。
   - **03 加密ZIP转7z**(`ArchiveManager.cs` 的 `CreateArchive`):确认 `GetSupportedType` 返回类型、`ArchiverIdentifier.SevenZipArchive` 仍在,且注入点仍是"实例化前的单点"。
3. **核查"默认值"类(魔改04 各子项)有没有被上游改动**:上游可能调整了这些字段的默认值或 getter。对 04-A~04-K 逐个确认:① 字段/构造函数签名没变(否则 anchor 失配会提示);② **上游的新默认值是不是已经和我们想要的一致了**——若上游自己也改成了我们要的值,该子项就**冗余了可删**;若上游改成了别的值,要确认我们的覆盖仍生效。
4. **特别复查 04-H 补译**:上游若补了简体中文(那两行不再空),anchor 会失配报错 → 确认后**删除 04-H**(见该条标注)。其它 `.restext` 补丁同理:上游若改了 key 名或增删条目,要跟着调整。
5. **C# 能否编译**:`stackalloc`/`Span`/新 API 等若上游改了依赖或语言版本,注意编译报错。务必在 Windows 上真编译一次确认。
6. **运行时抽查**:编译后逐个验证 §4 每条的"验证点"——尤其密码池能不能命中、加密 zip 能不能自动转 7z、封面预生成、各项默认值是否如预期。**补丁打上 ≠ 功能正确,必须实跑验证。**
7. **把核查结果反馈给用户**:明确告诉用户"哪些补丁原样生效、哪些因上游变动调整了、哪些已冗余建议删除、哪些需要用户在 Windows 上实测确认"。

> 一句话给接手 AI:**更新上游后,不要默认补丁还对。逐条对照本清单核查 anchor 语义、默认值是否被上游改动、能否编译、运行是否正确,有问题主动修并告知用户。**

---

## 6. 给接手 AI 的工作约束(重要)

- **你很可能编译不了。** NeeView 是 **WPF / .NET 10**,WPF 在编译期就是 **Windows-only**(标记编译器 `PresentationBuildTasks` 不能在 Linux 跑);沙箱里也装不了 .NET 桌面工具链、连不上 NuGet。所以**你的产出是"补丁 / 改好的代码",由用户在他的 Windows + Visual Studio 2026 上用 `build.py` 编译**。**别试图自己产 exe。**
- **复现用户源码状态**:`git clone` 上游 → `git checkout <§2 的 base commit>` → 跑 `build.py` 的"仅打补丁"步骤(或按其中 edit 手动应用)。这样你的代码树和用户本地一致。
- **想知道改了什么**:读对应的 `build.py` edit(锚点 + 插入内容)或 §4 详情。**不要从干净的 GitHub 源码去猜用户改了什么。**
- **加新功能的约定**:能用免编译的四层(脚本 / 主题 / 文字 / 设置)解决的,就**别动源码**;非改源码不可时,改动尽量**小、定向、加在稳定锚点**。新补丁一律**追加到 `patches.py` 的 `PATCHES` 列表末尾**(每条带唯一 `marker` 以便幂等),**不要新建脚本、不要动 `build.py`**;然后在 §1 表格和 §4 各登记一条。
- **★ 预设/默认值类改动的归类约定(务必遵守)**:凡是"改默认值、开关默认状态、性能预设"这类改动,**一律并入魔改 04「默认预设(合集)」作为新子项**(04-F、04-G…),**不单开新的魔改序号块**;§1 表格也不新增行,直接在第 04 行的描述里补上该项。**新序号块(05、06…)只留给"真正的新功能"**(改代码逻辑那种,如密码池/预生成/加密zip转7z)。这样序号块不膨胀、预设集中一处,便于阅读和维护。
- **读取/复现 `build.py` edit**:文中提到的 "`build.py` 里的 edit / PATCHES" 现已外置到同目录 `patches.py`,以它为准。
- 编译时 NuGet 还原需联网,用户那边走 Clash 代理(`127.0.0.1:7897`);命令行 git/dotnet 不自动走系统代理。
- **【铁律 · 没拿到原版源码必须明说,严禁猜锚点/接口】**(2026-06-05 用户硬性要求):
  - **改/修"已有魔改"**:代码与锚点都在 `patches.py` 里,**无需** GitHub 源码,放心改(如老板键、超分这类我们自己写的 mod)。
  - **碰 NeeView "原版未改动过的"代码**(写新的 `replace` 补丁要对锚点、要调 NeeView 现有 API、要确认某符号/命名空间是否已存在):**必须基于真实看到的源码**。AI 的 `web_fetch` 只能抓"已在搜索结果里出现过的链接",**GitHub 单文件 raw 链接通常抓不到**。若所需的 NeeView 原版源文件 ① 抓不到、且 ② 用户没上传 —— **必须明确告诉用户:"我没拿到 〈具体文件名〉,在不猜的前提下无法安全完成这步,请上传该文件"**,然后停下等文件。**严禁凭印象编造锚点或 API 硬上**(锚点对不上 → 补丁打不上;API/符号猜错 → 编译失败)。
  - **教训实例**:曾在 `namespace NeeView` 里写 `Environment.NewLine`,因不掌握原版符号环境、不知道 NeeView 自带 `NeeView.Environment` 类,编译报 `CS0117`。**不掌握原版的命名空间/符号环境,就容易踩同名冲突这类坑** —— 所以"碰原版代码"时务必先要到真实源码。
  - **另:AI 无法在本地编译验证**(沙箱无 .NET/Windows)。交付的补丁只做了"Python 结构 / C# 括号配平 / API 凭知识核对",**真正的编译与运行测试只能在用户机器上做**。因此每次交付都要请用户编译+按"验证点"实测并反馈。
- **改了补丁后直接重跑即可(自动还原)**:`build.py` 现在默认**自动还原**——源码是 git 仓库时,每次运行会先把补丁涉及的文件 `git checkout` 回原版、再整体重打,所以改了 `patches.py`(无论新增还是修改已存在条目)直接 `python build.py` 即可,无需再手动加 `--reset`。非 git 的纯源码目录会自动跳过还原(干净源码本就无需还原)。逃生口 `--no-reset` 仅当你手动改过源码、想保留时才用(本项目约定不手改源码,基本用不到)。
- **更新上游且保持魔改**:`python build.py --pull`(自动 还原→git pull→打补丁→编译)。魔改存在 `patches.py` 里、源码每次被还原成干净基线,所以 pull 永远顺畅、魔改不会丢。
- **【铁律 · 每次改动必须同时交付两样】**:任何一次新增 / 修改功能,都必须**同时**给用户:① 编译要用的 `patches.py`(以及必要时的 `build.py`);② 更新好的接手包 `NeeView_魔改包.zip`(内含本清单 + `build.py` + `patches.py` + `新机环境检验.py` + `README.txt`)。**缺一不可——这是用户的硬性要求,务必遵守。**

### 6.1 ★ 完工自检清单(每次改完代码,逐条过一遍再发布)

> 设这份清单的目的:**防止对话太长、AI 忘记同步更新 MD**,导致下一个 AI 接手时"代码和文档对不上"。改完一个功能、准备交付前,**照下面逐条确认,并在回复里明确勾掉**。这是仪式性的强制核对,别跳过。
>
> 配套有一道**自动保险**:`build.py` 每次运行开头会打印【改动概览】(每个魔改几条补丁、碰了哪些文件)。**拿这份概览和本清单 §1/§4 对照**——若某魔改概览里显示的文件/条数和 MD 记的对不上,就是漏更 MD 了。这道自动概览不依赖记忆,是比本清单更硬的兜底。

每次改动后必须确认(建议直接复制这段,逐项打 ✅ 回给用户):

```
完工自检(本次改动:______):
[ ] 1. 补丁已追加到 patches.py 的 PATCHES 末尾,每条有唯一 marker(create 模式 marker 留空)
[ ] 2. §1 表格:已加/改对应行(功能描述、状态、★改动文件清单要列全、应用方式)
[ ] 3. §4 详情:已加/改对应小节(目的、实际改动逐条、机制要点、验证点)
[ ] 4. 若属"预设/默认值/开关默认"类 → 已并入魔改04 子项(04-x),没单开新序号块
[ ] 5. §2 基准 commit:本次若执行了 git pull 更新源码 → 已把基准 commit 改成新值 + §2.x 追加核查记录 + **已把沙箱克隆与所有 worktree(wt_head/wt_base)同步到同一 commit 并在新基准重验零失配**;没更新源码则不动
[ ] 6. 跑过 build.py(或 --patch-only)看【改动概览】,确认每个魔改的文件/条数与 MD §1/§4 一致
[ ] 7. 已重新打包 NeeView_魔改包.zip(含最新 MD + build.py + patches.py + 新机环境检验.py + README),并交付给用户(铁律)
```

> 第 6 项是关键:概览是 `build.py` 自动生成的"代码真相",MD 是"人写的描述",**两者一比就知道有没有漏**。今天(2026-06-04 这次核对)就是靠这种"概览 vs MD"的对照,抓出了魔改05 的 05c/05d 在 patches.py 里有、却没写进 MD 的问题。

---

## 7. 交给下一个 AI 的开场白(复制粘贴用)

把 §3 那几个文件一起发给新会话,然后贴这段(末尾填上你这次的新需求):

```
我在魔改开源软件 NeeView(MIT,Windows / WPF / .NET 10 的图片漫画阅读器)。

现状:
- 完整源码已 git clone 到 D:\000\NeeView(4 个子模块已按锁定 commit 填好)。
- 编译环境已就绪并验证过:VS2026 Community 18.5.2 +「.NET 桌面开发」+「使用 C++ 的桌面开发」工作负载,MSBuild 可用。
- 已实现的魔改(逐条详情见《补丁清单》§1 表格 + §4,这里只列名):① 压缩包密码池 ② 封面预生成 ③ 加密ZIP自动转7z ④ 默认预设合集(04-A…04-N 子项) ⑤ 清缓存显体积+全删自动重启 ⑥ 手动隐藏 ⑦ 书架右键菜单编辑器 ⑧ 完整版预缓存(递归封面+浮条进度窗) ⑨ 老板键(全局热键 Alt+X) ⑩ 加密包封面修复 ⑪ 设置窗 F11 全屏 ⑫ 全屏 Esc 退出 ⑬ 书架阅读进度% ⑭ 文件大小智能单位 ⑮ 隐藏 Dev 水印 ⑯「已读完」侧栏面板 ⑰ 阅读统计侧栏面板 ⑱ 历史只记全屏单文件(mod16/17 口径统一) ⑲ 海报墙(书架第五种样式) ⑳ 预缓存原图封面(2048/512 隔离) ㉑ 双页末页页码 ㉒ 高清封面备份(`ReadingCovers.db`) ㉓ WebDAV/Alist 流式阅读 zip/cbz/rar/pdf(经 Alist 挂 115,HTTP Range·含离线缓存) ㉔ 自定义封面(右键文件夹/书→下钻选页/裁剪设封面) ㉕ 顶部地址栏=文件夹导航地址栏(本地/dav 输入跳转·自动跟踪书架当前文件夹·←→↑ 改书架后退/前进/上一层) ㉖ 海报墙无缝布局(封面按真实宽高比变宽=单图去黑边、双/三页宽封面横向占宽) ㉗ 书签双击跳书架(书签面板双击磁盘条目→书架定位选中/进入文件夹)+去两颗书签星(顶部地址栏★+书架列表项★)+菜单编辑器动态项正常色 ㉘ 预设调整(默认书架样式=海报墙·无缝·不显示书名 + WebDAV 新挂载默认限速 目录列举1/下载地址3)。**当前 282 条**(replace 230 / append 13 / create 39),基准 commit `32d892c19`;**近期变更史见 §2、各魔改实现见 §4、Windows 实测状态见 §2「用户实测确认」块与 §1 表格状态列**。
- 引擎 build.py + 补丁数据 patches.py + 环境体检 新机环境检验.py 都在 mods/ 里。

我附了《NeeView 魔改 · 补丁清单》——这一份就自包含了项目总览、技术栈分层、已改了什么、怎么继续。
请先读它,尤其 §0(为什么)/ §3(结构)/ §4(改了什么)/ §6(工作约束)。

重要约束(见补丁清单 §6):你大概率自己编译不了(WPF 只能在 Windows + VS 编),
所以你的产出是"补丁 / 改好的代码",由我在本机用 build.py 编译。
想看现有改动改了哪几行,直接读 patches.py(里面是补丁数据)。

★ 如果我这次是来做"更新上游源码(git pull 到新版)"的:请务必走补丁清单 §5.1 的
  「更新后全面冲突核查清单」——逐条核查每个魔改的 anchor 语义有没有漂移、默认值是否被
  上游改动(可能已冗余可删)、能否编译、运行是否正确,有问题主动修并明确告诉我结果。
  补丁"能打上"不等于"还正确"。

我这次想做的新功能是:____________________________(写清楚具体效果)

请告诉我:① 属于哪一层(脚本 / 主题 / 文字 / 设置 / 改源码);② 要动哪些文件;
③ 给我能追加进 patches.py 的补丁条目(追加到 PATCHES 末尾,别新建脚本、别动 build.py),并在补丁清单 §1 表格 + §4 各登记一条。
   注:若属于"预设/默认值/开关默认"类改动,请并入魔改 04 合集作为新子项(04-F…),不要单开新序号块(见补丁清单 §6 约定)。
```

---

*本清单自包含接手所需信息,无需任何外部配套文档。一切以 §2 记录的基准版本为准。*
