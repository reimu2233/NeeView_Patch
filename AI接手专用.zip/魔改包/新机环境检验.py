#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
NeeView 魔改 · 编译环境体检(只读,不改任何东西)
=================================================
在装了 VS2026 的 Windows 上跑:
    python 新机环境检验.py
    python 新机环境检验.py --src D:\\000\\NeeView

它会逐项检查 build.py 编译所需的东西,给出 ✅/⚠️/❌,
最后告诉你"能不能直接编译"。跑完把整段输出贴给 AI,可帮你诊断。
"""

import os
import sys
import glob
import argparse
import subprocess

DEFAULT_SRC = r"D:\000\NeeView"
SUBMODULES = ["SevenZipSharp", "NeeLaboratory.IO.Search", "Vlc.DotNet", "AnimatedImage"]

OK, WARN, BAD = "✅", "⚠️ ", "❌"
results = []   # (level, title, detail)


def add(level, title, detail=""):
    results.append((level, title, detail))
    line = f"{level} {title}"
    if detail:
        line += f"\n      {detail}"
    print(line, flush=True)


def run(cmd):
    """运行命令,返回 stdout(失败返回 None)。"""
    try:
        out = subprocess.run(cmd, capture_output=True, text=True, timeout=60)
        if out.returncode != 0:
            return None
        return (out.stdout or "").strip()
    except Exception:
        return None


def find_vswhere():
    pf86 = os.environ.get("ProgramFiles(x86)", r"C:\Program Files (x86)")
    p = os.path.join(pf86, "Microsoft Visual Studio", "Installer", "vswhere.exe")
    return p if os.path.isfile(p) else None


def vswhere_query(vswhere, extra):
    return run([vswhere, "-latest", "-prerelease", "-products", "*"] + extra)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--src", default=DEFAULT_SRC)
    args = ap.parse_args()
    src = os.path.abspath(args.src)

    print("=" * 64)
    print("NeeView 编译环境体检")
    print("=" * 64)

    # --- 0. 操作系统 ---
    if os.name == "nt":
        add(OK, f"操作系统: Windows ({sys.platform})")
    else:
        add(BAD, f"操作系统: 不是 Windows ({sys.platform})",
            "WPF 只能在 Windows 编译。本脚本的 VS 检查在非 Windows 上无意义。")

    # --- 1. Python ---
    add(OK, f"Python: {sys.version.split()[0]}")

    # --- 2. git ---
    g = run(["git", "--version"])
    add(OK if g else WARN, f"git: {g or '未找到(更新源码时需要)'}")

    # --- 3. 源码目录 ---
    print("-" * 64)
    if os.path.isdir(src):
        add(OK, f"源码目录存在: {src}")
        sln = os.path.join(src, "NeeView.sln")
        add(OK if os.path.isfile(sln) else BAD,
            f"解决方案 NeeView.sln: {'有' if os.path.isfile(sln) else '缺失!目录可能不对'}")
        # 子模块
        missing = []
        for m in SUBMODULES:
            d = os.path.join(src, m)
            filled = os.path.isdir(d) and any(os.scandir(d))
            if not filled:
                missing.append(m)
        if not missing:
            add(OK, f"4 个子模块已填好: {', '.join(SUBMODULES)}")
        else:
            add(BAD, f"子模块为空: {', '.join(missing)}",
                "在源码根目录执行: git submodule update --init --recursive")
    else:
        add(BAD, f"源码目录不存在: {src}", "用 --src 指定正确路径")

    # --- 4~9. VS / MSBuild(仅 Windows 有意义)---
    print("-" * 64)
    if os.name != "nt":
        add(WARN, "跳过 VS/MSBuild 检查(非 Windows)")
        verdict(); return

    vswhere = find_vswhere()
    if not vswhere:
        add(BAD, "vswhere.exe 未找到",
            "说明 Visual Studio 没装,或装得不完整。请装 VS2026。")
        verdict(); return
    add(OK, "vswhere.exe 已找到")

    # VS 实例
    vs_path = vswhere_query(vswhere, ["-property", "installationPath"])
    vs_name = vswhere_query(vswhere, ["-property", "displayName"])
    vs_ver = vswhere_query(vswhere, ["-property", "catalog_productDisplayVersion"])
    if vs_path:
        add(OK, f"Visual Studio: {vs_name or '?'}  {vs_ver or ''}".strip(),
            vs_path)
    else:
        add(BAD, "没检测到任何 Visual Studio 实例")
        verdict(); return

    # 工作负载:.NET 桌面开发
    managed = vswhere_query(vswhere, ["-requires", "Microsoft.VisualStudio.Workload.ManagedDesktop",
                                      "-property", "installationPath"])
    add(OK if managed else BAD,
        f"工作负载「.NET 桌面开发」: {'已装' if managed else '缺失!'}",
        "" if managed else "在 VS 安装器里勾上「.NET 桌面开发」(ManagedDesktop)。编译 WPF 必需。")

    # 工作负载:C++ 桌面开发(最容易漏)
    native = vswhere_query(vswhere, ["-requires", "Microsoft.VisualStudio.Workload.NativeDesktop",
                                     "-property", "installationPath"])
    add(OK if native else BAD,
        f"工作负载「使用 C++ 的桌面开发」: {'已装' if native else '缺失!'}",
        "" if native else "在 VS 安装器里勾上「使用 C++ 的桌面开发」(NativeDesktop)。NeeView 的原生依赖需要它,漏了编译会报错。")

    # MSBuild
    mb = vswhere_query(vswhere, ["-requires", "Microsoft.Component.MSBuild",
                                 "-find", r"MSBuild\**\Bin\MSBuild.exe"])
    mb = mb.splitlines()[0].strip() if mb else ""
    if mb and os.path.isfile(mb):
        ver = run([mb, "-version", "-nologo"])
        ver_last = ver.splitlines()[-1].strip() if ver else "?"
        add(OK, f"MSBuild 可用 (版本 {ver_last})", mb)
    else:
        add(BAD, "找不到 MSBuild.exe", "VS 缺 MSBuild 组件。")

    # --- 10. .NET SDK(信息项)---
    print("-" * 64)
    sdks = run(["dotnet", "--list-sdks"])
    if sdks:
        has10 = any(l.strip().startswith("10.") for l in sdks.splitlines())
        sdk_list = ", ".join(l.split()[0] for l in sdks.splitlines() if l.strip())
        add(OK if has10 else WARN,
            f".NET SDK (dotnet 命令可见): {sdk_list}",
            "" if has10 else "命令行没看到 10.x;但 VS2026 通常自带 .NET 10 SDK,MSBuild 能用就行,这条仅供参考。")
    else:
        add(WARN, ".NET SDK: dotnet 命令不在 PATH",
            "不一定有问题——VS 自带的 SDK 由 MSBuild 调用即可。仅供参考。")

    # --- 11. 代理 / NuGet(信息项)---
    print("-" * 64)
    add(WARN, "提醒:编译会还原 NuGet 包,需联网。校园网请确保 Clash(127.0.0.1:7897)开着。")

    verdict()


def verdict():
    print("=" * 64)
    bad = [t for lv, t, _ in results if lv == BAD]
    if not bad:
        print("结论:✅ 关键项齐全,可以直接跑 `python build.py` 编译。")
        print("     (第一次编译若卡在 NuGet 还原,多半是代理/网络,确保 Clash 开着。)")
    else:
        print("结论:❌ 还差这些,补齐后再编译:")
        for t in bad:
            print(f"   - {t}")
    print("=" * 64)
    print("把以上完整输出贴给 AI,可帮你进一步诊断。")


if __name__ == "__main__":
    main()
